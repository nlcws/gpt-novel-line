# SP00 Image Boundary / ナル

SP00 remains the text-side writer-ready story-pack lane.

Image-side rule:
- `099_*` = text/story-pack namespace handled by the existing SP00 role when applicable.
- `019_作品_イベント_日付_版` = temporary IMAGE event/reference pack.
- SP00 MUST NOT reinterpret, normalize, cut out, or convert `019_*` as a story pack.
- When an `019_*` image pack is present, SP00 only recognizes the namespace boundary and leaves image interpretation to IM80.
- Absence of `019_*` is normal and must not create a HOLD.
