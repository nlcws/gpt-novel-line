# IMT00 Resident Contract / ヌル

`000_IC` resident transfer lane.

- image control shelf: `000_IC`
- persistent image semantic shelves: `011_G`, `012_CA`
- temporary image pack: `019_作品_イベント_日付_版`
- `019` is never created empty or retained after the event solely for convenience.
- finished event/one-shot images are external deliverables and are not collected into the mount.
- README / manifest files are not placed loose at transfer-container root.
