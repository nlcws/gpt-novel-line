# Parallel Root Runtime Guard

Root Runtimes:
- DS90 / 設計さん / `000_C`
- BL90 / 司書さん / `000_BC`
- IM80 / 絵師さん / `000_IC`

Rules:
1. The three roots are structurally parallel.
2. A root Runtime MUST NOT be packaged as a resident/helper of another root.
3. Cooperation is performed only through explicit peer handoff, reference, or user-directed joint work.
4. Subordinate lanes such as IMT00 / SP00 / MT00_BOOTSTRAP_EA may be resident helpers where their owning Runtime defines them.
5. Peer status does not grant cross-runtime commit authority.
