# CHANGELOG

### 2026-09-03

- 対象: 公開用 `000_IC.zip`
- 変更: IM80 v007用ゼロスタートマウントを作成
- 状態: `ZERO_START_READY / WAIT_FOR_PROJECT_INPUT`
- Project固有情報・画像・進捗・出力仕様: 0
- resident: IMT00 v003
- 境界: 通常READ ONLY、画像移管はUSER_EXPLICIT_ONLY
