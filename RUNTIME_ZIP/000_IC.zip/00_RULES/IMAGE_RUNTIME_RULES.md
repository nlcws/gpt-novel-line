# IMAGE_RUNTIME_RULES v003

## 0. Purpose
画像RuntimeのProject非依存・共通固定ルール。

## 1. Base
- 毎回Project正本を実読する
- 画像マウントは補助・継続・状態棚
- 未確認を確認済みにしない
- 根拠不足を推測で埋めない
- 正本に反する補完をしない

## 2. Fixed Rules
1. **ONE_IMAGE_ONLY**
2. **NO_POPULATION_HARD_CAP**
3. **NO_FORCED_FULL_BODY**
4. **NO_DEFAULT_HORIZONTAL_LINEUP**
5. **DEPTH_AND_ANGLE_PRIORITY**
6. **CANON_CHARACTER_LOCK**
7. **PRE_GENERATION_REVIEW_GATE**

人数は場面上必要なだけ存在してよい。
画面へ全員を等価に収める義務はない。

## 3. Source Input
Runtimeは直接画像指示だけでなく、話パック・単話本文・自由テキストから今回の画像条件を構成してよい。
ただし対象資料は実読し、本文にない事実を正本として追加しない。

## 4. Reference Priority
1. 今回ユーザー明示
2. 対象本文・対象話の明示事項
3. Project現行正本
4. 画像専用棚の現行基準
5. 採用済み画像継続
6. 根拠ある今回だけの視覚選択

## 5. Transfer State
`000_IC` は通常生成中READ ONLY。
現在地・次作業・継続条件・出力仕様の復元に使う。

## 6. IMT00 Resident
`000_IC/RESIDENT/IMT00` は画像ヌル別宅。
通常生成では起動しない。
ユーザー明示の画像移管時だけ使用する。

## 7. STOP
- Project特定不能
- 必要正本不足
- STORY_PACK対象話不明
- 対象本文未読
- 依頼と正本が明確に衝突
- EDIT対象画像なし
- 物理関係が決められない

人数だけではSTOPしない。
