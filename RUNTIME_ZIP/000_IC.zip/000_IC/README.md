# 000_IC / ZERO-START IMAGE CONTROL

画像マウント `000_IC.zip` の固定制御棚。内部位置は常に `000_IC/`。

- `CURRENT_STATE/`: ゼロ状態またはProject画像ラインの現在地。IM80はREAD ONLY。
- `TRANSFER_STATE/`: inventory / disposition / restart / audit / validation。
- `RESIDENT/IMT00/`: 画像移管専用ヌル。通常はDORMANT。

初期状態は `ZERO_START_READY / WAIT_FOR_PROJECT_INPUT`。作品意味を持たない。
