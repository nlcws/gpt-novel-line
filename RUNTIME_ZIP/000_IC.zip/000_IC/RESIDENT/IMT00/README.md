# IMT00 RESIDENT

`000_IC.zip` 内の画像移管専用ヌル別宅。通常生成ではDORMANT。ユーザー明示の画像移管時だけ起動する。
