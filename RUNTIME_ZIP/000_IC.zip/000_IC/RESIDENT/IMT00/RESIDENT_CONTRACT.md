# IMT00 RESIDENT CONTRACT / 000_IC

## IM80 side
- `000_IC.zip` は通常READ ONLY
- `000_IC/CURRENT_STATE` から現在地を復元
- `000_IC/TRANSFER_STATE` は移管証跡として読む
- resident IMT00は通常DORMANT
- 画像生成・編集を担当
- 移管を書かない

## IMT00 side
- ユーザー明示の画像移管時だけ起動
- inventory / disposition / current state / restart / audit / manifest / validation / packagingを担当
- 出力ファイル名は常に `000_IC.zip`
- 画像を生成・編集しない
- Project本文 / 設計 / `000_C` / 他laneを書き換えない
