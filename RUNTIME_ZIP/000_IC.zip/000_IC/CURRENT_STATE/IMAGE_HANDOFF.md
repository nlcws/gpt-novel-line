# IMAGE HANDOFF / ZERO START

STATUS: READY

- 現在地: `ZERO_START_READY`
- Project: 未設定
- 完了画像: 0
- 次作業: `WAIT_FOR_PROJECT_INPUT`
- 出力サイズ: 未設定
- 継続条件: なし

ユーザー入力またはProject正本を実読するまで、Project名・話数・キャラクター・画風・サイズ・継続条件を補完しない。
