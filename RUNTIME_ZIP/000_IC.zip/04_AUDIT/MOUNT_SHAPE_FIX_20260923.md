# MOUNT SHAPE FIX 2026-09-23

- removed outer `000_IC/` directory wrapper from inside `000_IC.zip`
- moved helper homes to ZIP root, matching the control-shelf resident style used by `000_C`
- moved state/handoff/audit into numbered control directories
- removed loose root README/manifest files
- kept DS90 and BL90 as external peer roots
