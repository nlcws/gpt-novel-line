# IM80 START GATE / 000_IC

`000_IC` is the fixed IM80 control shelf. It is parallel to `000_C` (DS90) and `000_BC` (BL90).

Read order:
1. `02_CONTROL_STATE/IMAGE_PROGRESS.json`
2. `02_CONTROL_STATE/IMAGE_CONTINUITY.md`
3. `03_HANDOFF/IMAGE_HANDOFF.md`
4. `02_CONTROL_STATE/RESIDENT_INDEX.json` when helper dispatch is required
5. `011_G_v000` local image gate during ZERO START
6. `012_CA_v000` empty reusable visual canon shelf during ZERO START
7. task-bound `019_*` only when explicitly supplied

Resident helper homes:
- `IMT00/` = ヌル / image mount transfer
- `SP00/` = ナル / story-pack native, image 019 boundary only
- `MT00_BOOTSTRAP_EA/` = エーア / bootstrap resident core

Root boundary:
- DS90 / 設計さん = external peer root (`000_C`)
- BL90 / 司書さん = external peer root (`000_BC`)
- IM80 / 絵師さん = this root (`000_IC`)

Do not embed DS90 or BL90 inside `000_IC`.

## ZERO START
- `ZERO_START_READY` is a normal boot state.
- Project identity/canon is intentionally unbound.
- Empty `012_CA_v000` is not a failure.
- Do not create `019_*` until the user supplies an event/special/collab pack.
