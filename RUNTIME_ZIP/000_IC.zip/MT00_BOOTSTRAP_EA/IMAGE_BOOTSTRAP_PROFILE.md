# Ea Image Bootstrap Profile / エーア

Image-side minimum construction:

1. `000_IC` — IM80 control/state/resident shelf.
2. `011_G` — image local gate, locator and read-order shelf.
3. `012_CA` — persistent reusable accepted image canon.
4. `019_*` — NEVER pre-created. It exists only when the user supplies a temporary event/special/collab image pack.

Do not create 013–018 merely to make numbering look complete.
Do not place finished illustrations into persistent image shelves.
