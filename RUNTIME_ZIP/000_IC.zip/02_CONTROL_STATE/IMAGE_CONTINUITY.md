# IMAGE_CONTINUITY / ZERO START

continuity_bound: false
project: UNBOUND
state: ZERO_START_READY

No project-specific identity, character canon, costume canon, event state, or finished artwork is mounted.

Persistent image architecture:
- `000_IC`: IM80 control/state/resident helpers
- `011_G_v000`: project-neutral image gate
- `012_CA_v000`: empty reusable canon shelf
- `019_*`: absent until explicitly supplied

Wait for grounded project input. Do not infer a project or promote rough output to canon without user acceptance.
