# IMAGE_HANDOFF / ZERO START

active_handoff: NONE
project_state: ZERO_START_READY
current_location: WAIT_FOR_PROJECT_INPUT
next_state: BIND_GROUNDED_PROJECT_INPUT

Read order:
1. `000_IC/00_READ_FIRST/IM80_START_GATE.md`
2. `011_G_v000/00_START/PROJECT_READ_ORDER.md`
3. `012_CA_v000/10_CANON/CURRENT_STATE/CANON_ASSET_INDEX.json`
4. user/project supplied grounded sources
5. linked text canon only after a real locator exists

`019_*` is absent unless explicitly supplied for an active image task.
