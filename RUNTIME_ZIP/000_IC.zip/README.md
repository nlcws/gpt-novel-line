# 000_IC / ZERO-START IMAGE MOUNT

**固定ファイル名: `000_IC.zip`**

画像生成Runtime `IM80 v007` 用の新規Projectゼロスタートマウント。

- Project固有情報: 0
- 採用画像・参照画像: 0
- キャラクター・衣装・イベント資料: 0
- 現在話・次話: 未設定
- 出力サイズ: 未設定
- 次状態: `WAIT_FOR_PROJECT_INPUT`
- 通常生成時: `READ_ONLY`
- 画像移管: `USER_EXPLICIT_ONLY`

作品条件を推測して初期化しない。ユーザー入力またはProject正本の実体が来るまでゼロ状態を保つ。

## 起動時の入口

1. `MANIFEST.json`
2. `000_IC/TRANSFER_STATE/VALIDATION_REPORT.json`
3. `000_IC/CURRENT_STATE/IMAGE_HANDOFF.md`
4. `000_IC/CURRENT_STATE/IMAGE_PROGRESS.json`
5. `000_IC/CURRENT_STATE/IMAGE_CONTINUITY.md`
6. `00_RULES/`

## Runtime boundary

- 生成: IM80 v007
- 移管: resident IMT00 v003
- IM80は通常、本ZIPをREAD ONLY
- ユーザー明示の画像移管時だけIMT00が起動
- 本文・設計・Project `000_C`・他laneは変更しない
