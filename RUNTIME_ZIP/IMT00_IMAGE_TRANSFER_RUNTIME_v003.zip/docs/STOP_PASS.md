# STOP / PASS

## PASS
- 入力が `000_IC.zip`
- `000_IC/CURRENT_STATE` が成立
- `000_IC/RESIDENT/IMT00` が成立
- inventory がある
- 全 inventory ID が exactly once で disposition 済み
- restart entrypoint / read order / current location / next work がある
- unresolved STOP が空
- manifest が実体と一致
- resident runtime が `IMT00_IMAGE_TRANSFER_RUNTIME_v003.zip`
- validator PASS

## STOP
- 現行 `000_IC.zip` 不在
- 未分類素材
- 判断不足
- manifest/sha不一致
- restart情報不足
- unresolved STOP残存
- resident不整合
- validator failure
