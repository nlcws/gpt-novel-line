# ROLE BOUNDARY

## IM80
- 画像生成・画像編集を担当
- `000_IC.zip` を通常READ ONLY
- 移管を書かない

## IMT00
- ユーザー明示の画像移管時だけ起動
- `000_IC.zip` の inventory / disposition / state / audit / validation / packaging を担当
- 画像生成・画像編集をしない
- Project本文・設計・`000_C`・他laneを書き換えない
