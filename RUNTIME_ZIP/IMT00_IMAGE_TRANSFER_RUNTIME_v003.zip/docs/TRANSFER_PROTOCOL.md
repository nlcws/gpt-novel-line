# TRANSFER PROTOCOL

1. 現行 `000_IC.zip` を実読する。
2. `000_IC/CURRENT_STATE` と現行画像棚を読む。
3. 追加素材を読む。
4. inventory を作る。
5. 全 inventory item を reflected / held / discarded へ一度だけ分類する。
6. reflected のみ現行棚へ反映する。
7. `000_IC/CURRENT_STATE` を次回再開状態へ更新する。
8. `000_IC/TRANSFER_STATE` に inventory / disposition / restart memo / audit / validation を置く。
9. `MANIFEST.json` と sha256 を更新する。
10. 同名の `000_IC.zip` を作る。
11. `tools/validate_000_ic.py 000_IC.zip` を実行する。
12. PASSのみ移管完了として提出する。

分類不能は推測せずSTOP。
