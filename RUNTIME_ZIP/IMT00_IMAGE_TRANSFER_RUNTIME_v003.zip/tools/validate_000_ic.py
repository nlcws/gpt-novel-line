#!/usr/bin/env python3
from pathlib import Path
import zipfile, json, hashlib, sys

def h(b): return hashlib.sha256(b).hexdigest()
def stop(msg): print('STOP:',msg); return 1

def main(path):
    p=Path(path)
    if not p.exists(): return stop('000_IC.zip missing')
    if p.name!='000_IC.zip': return stop('mount filename must be 000_IC.zip')
    try:
        z=zipfile.ZipFile(p)
    except Exception as e: return stop('invalid zip: '+str(e))
    with z:
        names=[n for n in z.namelist() if not n.endswith('/')]
        required=[
          'README.md','MANIFEST.json','000_IC/README.md',
          '000_IC/CURRENT_STATE/IMAGE_HANDOFF.md','000_IC/CURRENT_STATE/IMAGE_PROGRESS.json','000_IC/CURRENT_STATE/IMAGE_CONTINUITY.md',
          '000_IC/TRANSFER_STATE/INVENTORY.json','000_IC/TRANSFER_STATE/DISPOSITION.json','000_IC/TRANSFER_STATE/RESTART_MEMO.txt',
          '000_IC/TRANSFER_STATE/TRANSFER_AUDIT.json','000_IC/TRANSFER_STATE/VALIDATION_REPORT.json',
          '000_IC/RESIDENT/IMT00/CURRENT_RESIDENT.json','000_IC/RESIDENT/IMT00/RESIDENT_CONTRACT.md',
          '000_IC/RESIDENT/IMT00/IMT00_IMAGE_TRANSFER_RUNTIME_v003.zip']
        for r in required:
            if r not in names: return stop('missing '+r)
        for d in ['00_RULES/','01_CHARACTER_BASE/','02_COSTUME_BASE/','03_EVENT_VARIANTS/','04_GROUP_REFERENCE/','05_ARCHIVE/','000_IC/']:
            if not any(n.startswith(d) for n in names): return stop('missing dir '+d)
        m=json.loads(z.read('MANIFEST.json'))
        entries={x['path']:x for x in m['files']}
        actual=[n for n in names if n!='MANIFEST.json']
        if set(entries)!=set(actual): return stop('manifest path set mismatch')
        for n in actual:
            b=z.read(n); e=entries[n]
            if h(b)!=e['sha256']: return stop('sha mismatch '+n)
            if len(b)!=e.get('bytes',len(b)): return stop('byte mismatch '+n)
        resident=json.loads(z.read('000_IC/RESIDENT/IMT00/CURRENT_RESIDENT.json'))
        if resident.get('runtime_package')!='IMT00_IMAGE_TRANSFER_RUNTIME_v003.zip': return stop('resident runtime mismatch')
        if resident.get('state')!='DORMANT_UNTIL_USER_EXPLICIT_TRANSFER': return stop('resident state mismatch')
        inv=json.loads(z.read('000_IC/TRANSFER_STATE/INVENTORY.json'))
        disp=json.loads(z.read('000_IC/TRANSFER_STATE/DISPOSITION.json'))
        ids=[x['inventory_id'] for x in inv['items']]
        all_disp=[]
        for k in ['reflected','held','discarded']: all_disp += disp.get(k,[])
        if sorted(ids)!=sorted(all_disp): return stop('inventory/disposition mismatch')
        if len(all_disp)!=len(set(all_disp)): return stop('disposition duplicate')
        audit=json.loads(z.read('000_IC/TRANSFER_STATE/TRANSFER_AUDIT.json'))
        if audit.get('operation')!='000_IC_TRANSFER': return stop('audit operation mismatch')
        if audit.get('unresolved_stops'): return stop('unresolved STOP exists')
        report=json.loads(z.read('000_IC/TRANSFER_STATE/VALIDATION_REPORT.json'))
        if report.get('status')!='PASS': return stop('validation report is not PASS')
        if report.get('validator_runtime')!='IMT00_v003': return stop('validation runtime mismatch')
        memo=z.read('000_IC/TRANSFER_STATE/RESTART_MEMO.txt').decode('utf-8','replace')
        for token in ['entrypoint:','read_order:','current_location:','next_work:','unresolved_stops:','required_inputs:']:
            if token not in memo: return stop('restart memo missing '+token)
    print('PASS: 000_IC mount validated')
    return 0
if __name__=='__main__': raise SystemExit(main(sys.argv[1]))
