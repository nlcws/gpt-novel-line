#!/usr/bin/env python3
from pathlib import Path
import zipfile, sys
root=Path(sys.argv[1]); out=Path(sys.argv[2]) if len(sys.argv)>2 else Path('000_IC.zip')
if out.name!='000_IC.zip': raise SystemExit('output filename must be 000_IC.zip')
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
    for p in sorted(root.rglob('*')):
        if p.is_file(): z.write(p,p.relative_to(root).as_posix())
print(out)
