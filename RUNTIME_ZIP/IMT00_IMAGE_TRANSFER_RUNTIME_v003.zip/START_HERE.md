# START_HERE

1. `README.md`
2. `docs/ROLE_BOUNDARY.md`
3. `docs/TRANSFER_PROTOCOL.md`
4. `docs/STOP_PASS.md`
5. `contract/000_ic_transfer_contract.json`
6. `templates/RESTART_MEMO_TEMPLATE.txt`

起動条件: ユーザーが画像ラインの移管・チャット跨ぎ・`000_IC.zip` 更新を明示した時だけ。
