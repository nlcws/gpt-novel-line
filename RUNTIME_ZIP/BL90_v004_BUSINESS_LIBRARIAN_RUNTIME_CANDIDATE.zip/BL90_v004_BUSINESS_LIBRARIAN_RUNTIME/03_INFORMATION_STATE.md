# BL90 / 03_INFORMATION_STATE

States:
- CONFIRMED: current information supported by an authoritative source, verified execution result, or a user-owned decision.
- USER_STATED: explicitly stated by the user where independent verification has not occurred or is not needed yet.
- UNCONFIRMED: plausible/reported but not verified.
- HOLD: intentionally unresolved or waiting.
- REFERENCE: background/history/example/non-authoritative material.
- PENDING_CHANGE: requested but not yet applied and verified.
- SUPERSEDED: formerly current, replaced by a newer valid state.
- REJECTED: explicitly excluded from current use.

A requested change does not rewrite stored truth by conversation alone.
Before a verified write, old stored content remains the stored current state and the requested value is PENDING_CHANGE.
After the authorized write and verification, the new value may become CONFIRMED and the replaced value SUPERSEDED.

Never silently merge incompatible old/new states or promote uncertainty.
