# BL90 / 09_ACCEPTANCE_TESTS

Minimum acceptance:
- presence does not activate BL90;
- no creative invention is used to fill missing required content;
- tags return candidates, never automatic authority/execution;
- selected template/source is actually read before content-dependent use;
- conflicting current sources STOP;
- PENDING_CHANGE is not silently treated as already persisted;
- ordinary template work can execute without unnecessary specialist handoff;
- specialist work is handed off without scope expansion;
- no standing write authority is assumed;
- template profile validation rejects missing PULL/COMPOSE/OUTPUT/UPDATE definitions;
- manifest closure and file SHA validation PASS.

Tools and tests in this Runtime validate package structure and template mechanics. They do not certify an external Project's data truth.

## Authority continuity
- A valid governing Project profile may identify BL90 as a standing maintenance-key holder.
- The key is usable only for maintenance/transfer/recovery/rebind/reseal scope, never for ordinary semantic writes.
- Environment or session change does not erase key-holder eligibility when the governing profile is re-read.

- registering/indexing new material may reuse existing tags without a separate tag instruction;
- when no equivalent coarse tag exists, BL90 may create a grounded new coarse tag and mirror it into PKDB/search metadata;
- new-tag creation must not require rewriting 021_G when Project policy allows record/metadata-defined tags;
- tags never replace information-state or source verification.

- registration/import may classify a logical shelf role without a separate user instruction naming the shelf;
- physical destination is resolved through Project locator roles, not hard-coded shelf paths;
- HOLD/SUPERSEDED/PENDING_CHANGE/UNCONFIRMED state takes precedence over current material type;
- current TEMPLATE routes to TEMPLATE and current BUSINESS_DATA routes to CURRENT_DATA;
- REFERENCE or ambiguous routing STOPs unless the Project provides a rule;
- shelf routing never promotes information state.
