#!/usr/bin/env python3
import hashlib, json, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()

def stop(code,msg): print(f'STOP[{code}] {msg}'); return 2

def main():
    mp=ROOT/'MANIFEST.json'
    if not mp.exists(): return stop('MANIFEST_MISSING','MANIFEST.json missing')
    m=json.loads(mp.read_text(encoding='utf-8'))
    expected={x['path']:x for x in m.get('files',[])}
    actual={p.relative_to(ROOT).as_posix():p for p in ROOT.rglob('*') if p.is_file() and p.name!='MANIFEST.json'}
    if set(expected)!=set(actual): return stop('MANIFEST_CLOSURE',f'expected={len(expected)} actual={len(actual)}')
    for rel,p in actual.items():
        e=expected[rel]
        if p.stat().st_size!=e['bytes'] or sha(p)!=e['sha256']: return stop('MANIFEST_HASH',rel)
    req={'schema','template_id','title','tags','applicability','pull','compose','output','update'}
    for p in (ROOT/'examples').glob('*.json'):
        d=json.loads(p.read_text(encoding='utf-8'))
        if d.get('schema')=='BL90_TEMPLATE_PROFILE_v001' and not req.issubset(d): return stop('TEMPLATE_SHAPE',p.name)
    print('PASS_BL90_CORE')
    return 0
if __name__=='__main__': raise SystemExit(main())
