#!/usr/bin/env python3
import argparse, json
from pathlib import Path

def load_profiles(root):
    out=[]
    for p in sorted(Path(root).rglob('*.json')):
        try: d=json.loads(p.read_text(encoding='utf-8'))
        except Exception: continue
        if d.get('schema')=='BL90_TEMPLATE_PROFILE_v001': out.append((p,d))
    return out

def main():
    ap=argparse.ArgumentParser(description='Return BL90 template candidates by coarse tags; never auto-select.')
    ap.add_argument('profiles_dir'); ap.add_argument('tags', nargs='+')
    a=ap.parse_args(); q=set(a.tags)
    rows=[]
    for p,d in load_profiles(a.profiles_dir):
        tags=set(d.get('tags',[])); score=len(q & tags)
        if score: rows.append({'template_id':d.get('template_id'),'title':d.get('title'),'matched_tags':sorted(q&tags),'score':score,'path':str(p)})
    rows.sort(key=lambda x:(-x['score'],x['template_id'] or ''))
    print(json.dumps({'result':'CANDIDATES_ONLY','candidates':rows},ensure_ascii=False,indent=2))
if __name__=='__main__': main()
