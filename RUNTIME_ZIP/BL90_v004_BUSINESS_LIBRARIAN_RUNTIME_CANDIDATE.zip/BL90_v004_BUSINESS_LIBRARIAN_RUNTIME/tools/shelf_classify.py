#!/usr/bin/env python3
import argparse, json
from pathlib import Path

STATE_TO_ROLE={
    'HOLD':'HOLD',
    'SUPERSEDED':'SUPERSEDED',
    'PENDING_CHANGE':'PENDING_CHANGE',
    'UNCONFIRMED':'UNCONFIRMED',
}
CURRENT_STATES={'CONFIRMED','CURRENT'}
TYPE_TO_ROLE={'TEMPLATE':'TEMPLATE','INDEX':'INDEX','BUSINESS_DATA':'CURRENT_DATA'}

def stop(code,msg):
    print(json.dumps({'result':'STOP','code':code,'message':msg},ensure_ascii=False,indent=2))
    return 2

def main():
    ap=argparse.ArgumentParser(description='Classify BL90 material into a logical shelf role, then resolve via Project LOCATOR_ROLES.')
    ap.add_argument('locator_roles_json')
    ap.add_argument('--material-type',required=True)
    ap.add_argument('--information-state',required=True)
    a=ap.parse_args()
    mt=a.material_type.strip().upper(); st=a.information_state.strip().upper()
    if st in STATE_TO_ROLE:
        role=STATE_TO_ROLE[st]
    elif st in CURRENT_STATES:
        role=TYPE_TO_ROLE.get(mt)
        if role is None: return stop('MATERIAL_TYPE_UNSUPPORTED',mt)
    elif st=='REFERENCE':
        return stop('REFERENCE_ROUTE_UNRESOLVED','REFERENCE needs Project/user routing policy')
    else:
        return stop('INFORMATION_STATE_UNSUPPORTED',st)
    p=Path(a.locator_roles_json)
    d=json.loads(p.read_text(encoding='utf-8'))
    roles=d.get('roles',{})
    if role not in roles: return stop('LOCATOR_ROLE_MISSING',role)
    print(json.dumps({'result':'SHELF_CLASSIFIED','material_type':mt,'information_state':st,'logical_role':role,'destination':roles[role]},ensure_ascii=False,indent=2))
    return 0
if __name__=='__main__': raise SystemExit(main())
