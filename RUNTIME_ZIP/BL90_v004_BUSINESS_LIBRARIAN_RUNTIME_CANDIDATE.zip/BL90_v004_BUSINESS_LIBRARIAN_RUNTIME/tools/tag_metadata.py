#!/usr/bin/env python3
import argparse, json
from pathlib import Path

def uniq(xs):
    out=[]
    for x in xs:
        x=str(x).strip()
        if x and x not in out: out.append(x)
    return out

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('json_file')
    ap.add_argument('tags', nargs='+')
    ap.add_argument('--write', action='store_true')
    args=ap.parse_args()
    p=Path(args.json_file)
    d=json.loads(p.read_text(encoding='utf-8'))
    before=uniq(d.get('tags',[]))
    after=uniq(before+args.tags)
    d['tags']=after
    result={'result':'TAG_METADATA_READY','before':before,'after':after,'created':[x for x in after if x not in before]}
    if args.write:
        p.write_text(json.dumps(d,ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf-8')
        result['persisted']=True
    else: result['persisted']=False
    print(json.dumps(result,ensure_ascii=False,indent=2))
if __name__=='__main__': main()
