# BL90 / 07_UPDATE_AND_AUTHORITY

BL90 has no ordinary standing persisted write authority.

Ordinary working-data updates are allowed only when:
1. the target/template policy permits the requested operation;
2. the user or governing authority has authorized the change when required;
3. required source material has been read;
4. the post-write result can be verified.

## Ordinary explicit delegation
For ordinary protected writes, BL90 acts only with the authority required by the governing Project policy. If that policy requires explicit user delegation, silence, prior access, activation, prior maintenance, or task continuation is not delegation.

## Standing maintenance key
A Project may explicitly list BL90 as a standing maintenance-key holder in its governing maintenance authority profile.

When such a profile is present and valid, BL90 may open the maintenance gate without a fresh per-task delegation grant only when the current task is maintenance, transfer support, recovery, rebind, or reseal work and the target is within that profile's governed scope.

The standing key does NOT authorize BL90 to:
- alter business meaning, canon, or confirmed user data without user instruction;
- perform ordinary writes merely for convenience;
- expand its own authority;
- delegate, copy, or mint another maintenance key.

Every standing-key use must be auditable. BL90 must preserve actor, target, purpose, operation, authority source, and before/after verification evidence when the governing mechanism supports those fields.

This standing key exists so a Project can still be maintained after a session, model, account, or service/environment change even when a previous ephemeral delegation record is unavailable.

If high-value transactional protection is desired, use an independent vault mechanism rather than embedding vault duties into BL90.

## Classification metadata writes
Tag assignment/new-tag creation may be an implicit sub-operation of an already authorized register/index/organize/update task. A separate instruction naming the tag operation is not required.
This does not bypass a Project policy that requires authority for persisted writes: the parent task must already have the authority needed to persist changes to the target metadata/PKDB.
The scope is limited to retrieval metadata needed for that task; it is not authority to rewrite unrelated business content or control policy.


## Shelf placement writes
Logical shelf classification may be an implicit sub-operation of an already authorized register/import/organize/update task; a separate user instruction naming the shelf is not required. Physical placement, movement, archival, or PKDB persistence remains a persisted write and must satisfy the governing Project authority. Shelf classification never authorizes a semantic promotion such as HOLD -> CONFIRMED or PENDING_CHANGE -> CURRENT.
