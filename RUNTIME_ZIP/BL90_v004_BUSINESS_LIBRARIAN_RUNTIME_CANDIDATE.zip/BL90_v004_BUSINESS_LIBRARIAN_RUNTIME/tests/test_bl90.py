from pathlib import Path
import json, subprocess, sys, tempfile
ROOT=Path(__file__).resolve().parents[1]
val=subprocess.run([sys.executable,str(ROOT/'tools'/'validate_bl90.py')],capture_output=True,text=True)
assert val.returncode==0 and 'PASS_BL90_CORE' in val.stdout, val.stdout+val.stderr
with tempfile.TemporaryDirectory() as td:
    p=Path(td)
    base=json.loads((ROOT/'examples'/'BL90_TEMPLATE_EXAMPLE.json').read_text(encoding='utf-8'))
    (p/'a.json').write_text(json.dumps(base,ensure_ascii=False),encoding='utf-8')
    other=dict(base); other['template_id']='OTHER'; other['title']='別候補'; other['tags']=['月次','報告','店舗']
    (p/'b.json').write_text(json.dumps(other,ensure_ascii=False),encoding='utf-8')
    r=subprocess.run([sys.executable,str(ROOT/'tools'/'template_candidates.py'),str(p),'月次','報告'],capture_output=True,text=True)
    assert r.returncode==0
    d=json.loads(r.stdout); assert d['result']=='CANDIDATES_ONLY' and len(d['candidates'])==2
    rec={'record_id':'R1','role':'DATA','status':'CONFIRMED','data':{},'source_note':'x','tags':['月次']}
    rp=p/'record.json'; rp.write_text(json.dumps(rec,ensure_ascii=False),encoding='utf-8')
    tr=subprocess.run([sys.executable,str(ROOT/'tools'/'tag_metadata.py'),str(rp),'報告','月次','新規分類','--write'],capture_output=True,text=True)
    assert tr.returncode==0, tr.stdout+tr.stderr
    td=json.loads(tr.stdout); assert td['persisted'] is True and td['created']==['報告','新規分類']
    rr=json.loads(rp.read_text(encoding='utf-8')); assert rr['tags']==['月次','報告','新規分類']

    loc={'schema':'BL90_LOCATOR_ROLES_v001','roles':{'CURRENT_DATA':'024_V/current','HOLD':'028_H/hold','INDEX':'PKDB','PENDING_CHANGE':'024_V/pending_change','SUPERSEDED':'028_H/superseded','TEMPLATE':'022_B/templates','UNCONFIRMED':'024_V/unconfirmed'}}
    lp=p/'locator.json'; lp.write_text(json.dumps(loc,ensure_ascii=False),encoding='utf-8')
    def classify(mt,st):
        x=subprocess.run([sys.executable,str(ROOT/'tools'/'shelf_classify.py'),str(lp),'--material-type',mt,'--information-state',st],capture_output=True,text=True)
        return x, json.loads(x.stdout)
    x,d=classify('BUSINESS_DATA','CONFIRMED'); assert x.returncode==0 and d['logical_role']=='CURRENT_DATA' and d['destination']=='024_V/current'
    x,d=classify('TEMPLATE','CONFIRMED'); assert x.returncode==0 and d['logical_role']=='TEMPLATE' and d['destination']=='022_B/templates'
    x,d=classify('BUSINESS_DATA','HOLD'); assert x.returncode==0 and d['logical_role']=='HOLD' and d['destination']=='028_H/hold'
    x,d=classify('TEMPLATE','PENDING_CHANGE'); assert x.returncode==0 and d['logical_role']=='PENDING_CHANGE'
    x,d=classify('BUSINESS_DATA','REFERENCE'); assert x.returncode==2 and d['code']=='REFERENCE_ROUTE_UNRESOLVED'

print('PASS_BL90_TESTS')
