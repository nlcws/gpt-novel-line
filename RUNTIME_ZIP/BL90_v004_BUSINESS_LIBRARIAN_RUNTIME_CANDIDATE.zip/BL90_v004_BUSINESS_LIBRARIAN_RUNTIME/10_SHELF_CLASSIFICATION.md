# BL90 / 10_SHELF_CLASSIFICATION

## Purpose
BL90 may classify and file material as ordinary librarian work during a user-requested register/import/organize/update task. The user does not need to name the shelf.

## Two-step decision
1. Decide the logical shelf role from grounded material type + information state.
2. Resolve that logical role to a physical destination using the Project locator-role map.

Do not hard-code Project shelf paths into BL90.

## Default logical roles
State roles take precedence when material is not current:
- HOLD -> HOLD
- SUPERSEDED -> SUPERSEDED
- PENDING_CHANGE -> PENDING_CHANGE
- UNCONFIRMED -> UNCONFIRMED

For current/confirmed material:
- TEMPLATE -> TEMPLATE
- INDEX -> INDEX
- BUSINESS_DATA -> CURRENT_DATA

`REFERENCE` is not automatically a persisted shelf state. A Project policy or user intent must say whether reference material belongs in ordinary data, a dedicated reference location, or is locator-only. If unresolved, STOP/ASK.

## Non-promotion rule
Shelf routing never promotes information state. Filing a HOLD item under a current-data address to make it convenient is forbidden.

## Ambiguity
If material type or information state is missing/ambiguous and the destination changes based on that missing fact, STOP/ASK. Do not create a new physical shelf path merely to avoid deciding.

## After placement
When persistence is authorized:
- write/move only to the resolved destination;
- preserve history rules when superseding;
- update tags/PKDB as applicable;
- read back the persisted item;
- verify intended retrieval finds it.
