# BL90 / 04_RETRIEVAL

## Principle
BL90 does not memorize an unlimited map of shelf addresses.
It retrieves by intent, tags/search terms, and metadata, then selects from candidates.

## Flow
user goal
-> search terms / coarse tags
-> locator/index/DB search
-> candidate set
-> candidate metadata/applicability comparison
-> BL90 selection
-> actual source/template read
-> currentness/relevance check
-> use

## Tag rule
Tags are coarse retrieval keys, not authority and not final selection.
Do not create one tag per record or one tag per tiny distinction merely to avoid reading candidate metadata.

## Evidence rule
Index, search result, DB record, summary, or locator is support/locator evidence unless the governing system explicitly makes it canonical.
When a claim depends on source bytes/content, read the actual source.

## Tag assignment and creation
BL90 is not read-only with respect to classification metadata.
When the current task includes registering, indexing, organizing, or updating material, BL90 may assign tags without a separate user instruction saying "add tags".

Order:
1. inspect existing coarse tags/search terms that plausibly apply;
2. reuse an existing tag when its meaning is materially equivalent;
3. if no existing tag adequately covers the grounded subject/use, create a new coarse tag;
4. attach it to the target record/template metadata and, when a PKDB/index record exists or is being created, mirror it there for retrieval;
5. verify the resulting item is retrievable by the intended concept.

Creating a tag does not require rewriting 021_G solely to register that tag when the Project tag policy permits metadata/record-defined tags.

Do not:
- create one tag per record or per volatile value;
- duplicate an existing tag merely with a synonym/spelling variant when equivalence is clear;
- encode CONFIRMED/HOLD/PENDING_CHANGE as a substitute for the separate information-state field;
- invent a domain fact merely to justify a tag;
- treat a tag as canonical evidence or authority.

If the material itself does not support a proposed classification, leave the tag uncreated and use UNCONFIRMED/ASK as appropriate.


## Registration path
For new or reorganized material, retrieval classification and shelf classification are separate but adjacent duties:
material read -> information-state determination -> material-type determination -> logical shelf-role classification -> Project locator-role resolution -> persisted placement (when authorized) -> tag/PKDB update -> retrieval verification.

A tag never determines the shelf by itself. The shelf role comes from material type plus information state under the governing shelf-classification policy.
