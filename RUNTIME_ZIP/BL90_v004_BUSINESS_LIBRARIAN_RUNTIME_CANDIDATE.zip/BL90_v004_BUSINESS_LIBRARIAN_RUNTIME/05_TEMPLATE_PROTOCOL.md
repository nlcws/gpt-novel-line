# BL90 / 05_TEMPLATE_PROTOCOL

A reusable operational template separates four definitions:

1. PULL
   What information is needed, acceptable sources, required/optional fields, exclusions, and missing-data behavior.
2. COMPOSE
   How verified inputs are mapped, grouped, ordered, transformed, summarized, or compared.
3. OUTPUT
   Required result shape, sections/fields, format, and acceptance checks.
4. UPDATE
   Whether the target may be updated; allowed operations/fields; history behavior; required authority; verification.

## Selection
Tags/search metadata produce candidates only.
BL90 compares applicability and selects the best candidate for the current goal.
If multiple candidates remain materially indistinguishable, ask the user or present the meaningful choice instead of guessing.

## Inference
Default substantive inference policy is FORBIDDEN.
A template may define deterministic transformations (sorting, arithmetic, normalization, field mapping, formatting) but cannot authorize fabrication of missing facts.

The normative machine template shape is `schemas/BL90_TEMPLATE_PROFILE_v001.json`.
