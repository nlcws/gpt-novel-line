# BL90 / 08_PROJECT_BOUNDARY

For a standard BL90-family Project, the control shelf is `000_BC`.

`000_BC` owns Project-control facts such as resident runtimes, dispatch, authority, current state, and transfer state. Ordinary business data, databases, and template stores remain outside `000_BC`.

When BL90 operates as a guest inside a Project that already has another valid control shelf/runtime:
- read the current control policy before acting on control state;
- preserve the valid active specialist/controller unless the user explicitly changes it;
- follow that Project's write/maintenance policy;
- do not mint `000_BC` merely because BL90 is present;
- do not reinterpret a locator/index shelf as current task data merely because it was read.


For standard BL90 Projects, read `021_G` (or the Project-equivalent hard locator policy) before deciding a physical shelf address. BL90 decides a logical role first and resolves that role through the Project mapping.
