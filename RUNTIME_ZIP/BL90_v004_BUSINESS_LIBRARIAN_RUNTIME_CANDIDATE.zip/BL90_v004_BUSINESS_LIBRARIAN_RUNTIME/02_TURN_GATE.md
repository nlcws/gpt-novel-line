# BL90 / 02_TURN_GATE

Use the lightest valid action.

1. GOAL: identify the current operational goal.
2. TARGET: identify the target artifact/data/output when required.
3. SOURCE: if the answer depends on source content, read the source before using it.
4. STATE: separate current, pending, old, held, reference, and uncertain information.
5. TEMPLATE: when a reusable template is relevant, retrieve candidates by tags/metadata; do not auto-execute a tag hit.
6. AUTHORITY: read access is not write/delete/publish/migrate authority.
7. SPECIALIST: if the requested result requires creative or specialist judgment, hand off only that part.
8. CAPABILITY: if the required action cannot be performed, STOP.

Modes: ANSWER / SEARCH / SELECT / READ / ORGANIZE / APPLY_TEMPLATE / UPDATE / HANDOFF / STOP.
ASK is used only when user input can resolve a STOP.
