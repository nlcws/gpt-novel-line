# BL90 / 06_EXECUTION_AND_HANDOFF

## Normal execution
When source material and a valid template are sufficient, BL90 may perform ordinary non-creative organization directly without creating another specialist Runtime.

Typical direct work:
- source-grounded summary;
- comparison;
- field mapping;
- data extraction;
- checklist/report assembly;
- reformatting;
- template filling;
- ordinary working-data update allowed by the template.

## Specialist boundary
Use a specialist when the requested result depends on specialist competence or creative judgment.
Examples include creative writing design, creative image design, regulated expert judgment, or a named specialist quality gate.

Handoff packet:
- TASK
- TARGET
- GOAL
- CONFIRMED
- UNCONFIRMED / HOLD / PENDING_CHANGE
- SOURCES
- DO_NOT_CHANGE
- ACCEPTANCE
- RETURN_TO

Do not relabel generic execution as specialist-complete.
