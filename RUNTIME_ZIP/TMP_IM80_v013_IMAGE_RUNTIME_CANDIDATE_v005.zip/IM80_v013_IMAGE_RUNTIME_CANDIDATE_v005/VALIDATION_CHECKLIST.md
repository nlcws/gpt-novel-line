# VALIDATION_CHECKLIST / IM80 v013 CANDIDATE

## Static architecture
- [ ] MODE_ROUTING_REQUIRED
- [ ] ROUGH_MODE can start without pre-existing canon
- [ ] ROUGH output is CANDIDATE, never auto-canon
- [ ] CANONIZATION requires evidence per lock
- [ ] canon promotion requires user adoption
- [ ] CANON_ASSET requires canon or routes back to CANONIZATION
- [ ] ILLUSTRATION requires canon for canon characters
- [ ] DIRECT_ASSET_BINDING applies when required canon exists
- [ ] VISIBLE_PART_LOCK applies when required canon exists
- [ ] EXPRESSION_SOURCE separated from identity / parts / style
- [ ] PROMPT_COMPILER does not dump full Runtime into image prompt
- [ ] exact geometry is not considered satisfied by prose alone
- [ ] CANON_ASSET template is immutable by default
- [ ] ruler / bbox / text / clipping handled by Hard Constraint layer
- [ ] PARTIAL_LKG preserves approved regions
- [ ] image failure does not stop unrelated work
- [ ] PRE_GENERATION_REVIEW / approval / preflight preserved for image calls
- [ ] NO_BLIND_REROLL preserved
- [ ] 000_IC READ ONLY during normal generation
- [ ] IMT00 not auto-run
- [ ] mount compatibility is version-decoupled
- [ ] resident generic template is project-neutral and TEMPLATE_ONLY

## Resident asset
- [ ] `ASSETS/TEMPLATES/GENERIC_THREE_VIEW_CHARACTER_SHEET_v001.png` exists
- [ ] template metadata JSON exists
- [ ] image hash matches metadata
- [ ] template has no project-specific identity role
- [ ] template replacement requires new asset version, not silent overwrite

## Regression A / brand-new character
Input: text concept only, no identity image canon.
Expected: ROUGH_MODE. No `STOP_REQUIRED_REFERENCE_BINDING` merely because canon does not exist.

## Regression B / rough adoption
Input: one rough candidate selected by user.
Expected: CANONIZATION_MODE, lock/evidence build, output remains CANON_CANDIDATE until explicit adoption.

## Regression C / canon promotion
User explicitly adopts candidate.
Expected: ACTIVE_CANON. Provenance preserved.

## Regression D / canon sheet build
Input: ACTIVE_CANON + request for three-view sheet.
Expected: CANON_ASSET_MODE. Template stays byte/visual base; image engine only supplies components as needed.

## Regression E / 158cm ruler
Input: physical lock height 158cm + 0..180 ruler.
Expected: `y(158)` computed from actual ruler anchors. Text label `158cm` alone is not PASS.

## Regression F / template redraw attempt
Image engine returns a visually similar but redrawn template.
Expected: FAIL_TEMPLATE_INTEGRITY. Do not promote.

## Regression G / partial LKG
User says left three-view panel is OK, right details are not.
Expected: left region LKG_LOCKED; subsequent work cannot regenerate left region.

## Regression H / prompt compiler
Runtime contains extensive history and contracts.
Expected: image call receives only current target/identity/task/required features/style/camera/prohibitions. History not duplicated.

## Regression I / exact geometry unavailable
Request requires exact coordinates but current tool cannot guarantee them and no compositor is available.
Expected: HOLD, not prompt-only fake exactness.

## Regression J / canonical illustration
Existing character with base + parts requests thumbnail.
Expected: ILLUSTRATION_MODE -> direct binding -> visible part lock -> review -> approval -> one image call -> post check.

## Regression K / contact sheet substitute
Individual identity bases exist but only contact sheet is bound.
Expected: FAIL for canon reproduction.

## Regression L / expression source
Canonical expression sheet exists and matters to face temperature.
Expected: bind as EXPRESSION_SOURCE; never replace IDENTITY_SOURCE.

## Regression M / post-fail isolation
One generated component fails identity check during CANON_ASSET.
Expected: component FAIL; template measurement/text prep and existing LKG remain valid.

## Regression N / same-condition reroll
Post-check FAIL with no changed condition.
Expected: no automatic reroll. Same-condition retry only after user explicit stochastic retry and new review/approval.

## Regression O / edit target missing
Expected: STOP.

## Regression P / manifest
- self excluded
- count correct
- every listed file bytes/SHA256 match
- JSON files parse
- ZIP CRC PASS


## Canon shelf checks
- [ ] If `012_CA_v001.zip` is mounted, manifest matches actual bytes/hashes
- [ ] target character `CANON_LINKS.json` was read
- [ ] required linked text canon was resolved and hash-checked when available
- [ ] accepted `012_CA` visual canon is used before `000_IC` supporting visual references
- [ ] candidate output is not treated as canon before explicit user acceptance/commit
