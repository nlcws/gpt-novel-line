# MOUNT_INTERFACE / IM80 v013 CANDIDATE v005

## Permanent image-side mount
- `000_IC.zip`: fixed control/state/resident shelf
- `011_G_vNNN.zip`: local image semantic gate/index/policy
- `012_CA_vNNN.zip`: accepted reusable visual canon

## Temporary image source pack
- `019_<work>_<event>_<date>_<version>.zip`: mounted only for the active event/special/collab task

## Read order
1. 000_IC current control state
2. 011_G local gate/read order
3. 012_CA accepted base canon
4. active 019 pack, if explicitly mounted/task-bound
5. linked authoritative text shelves/sources

## Scope rule
019 is a scoped override. It may override only fields declared by the pack (e.g. event costume, props, palette, decoration). It does not globally replace identity/body/base canon from 012_CA without explicit user canon promotion.

## Artifact storage
Finished event art, one-off illustrations, and thumbnails are external artifacts (Dropbox/archive) and are not permanent mount content by default.

## Packaging
Do not require loose README at package root. Shelf guidance belongs inside `00_START/` or `99_META/`-style internal locations.


## 000_IC mount shape v005
`000_IC.zip` follows the control-shelf shape used by `000_C`: the ZIP root contains control directories and resident helper homes directly. There is no inner `000_IC/` wrapper directory.
Resident helper paths are `IMT00/`, `SP00/`, and `MT00_BOOTSTRAP_EA/`.
DS90/BL90 remain external peer roots.


## Zero-start mount
For a new project use `000_IC.zip` + `011_G_v000.zip` + `012_CA_v000.zip`. The v000 semantic shelves are intentionally project-neutral/empty. Bind project sources first, then version only shelves that actually gain project state. Do not pre-create `019_*`.
