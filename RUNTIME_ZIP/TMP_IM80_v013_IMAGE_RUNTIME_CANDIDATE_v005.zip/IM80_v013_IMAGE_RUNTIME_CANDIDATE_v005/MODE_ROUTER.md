# MODE_ROUTER / IM80 v013 CANDIDATE

## Purpose
画像案件を「正本が既にある」前提で一括処理しない。案件の成熟度と目的で4モードへ分岐する。

## Modes

### ROUGH_MODE
新規キャラクター、未確定外見、複数案比較、方向探索。
正本画像は不要。出力はCANDIDATEのみで、生成成功だけでは正本にならない。

### CANONIZATION_MODE
採用したラフや既存資料から、本人性・身体・配色・基本衣装・小物等を正本として固定する。
未確定項目はUNRESOLVEDのまま保持できる。推測で埋めない。

### CANON_ASSET_MODE
確定済み正本を、三面図・キャラクターシート・表情シート・衣装パーツ表・サイズ比較等の正本資料へ組版する。
画像モデルは素材生成/局所編集に限定し、テンプレ、寸法、座標、文字、枠、クリップはHard Constraint層で処理する。

### ILLUSTRATION_MODE
確定済み正本から、サムネ、扉絵、イベント絵、通常イラスト等を制作する。
従来IM80のreference binding / visible part lock / composition / reviewを主に使う。

## Routing

```text
new character with no canon
  -> ROUGH_MODE

rough selected for adoption
  -> CANONIZATION_MODE

canon exists + user wants reference/design sheet
  -> CANON_ASSET_MODE

canon exists + user wants scene/thumbnail/illustration
  -> ILLUSTRATION_MODE

edit existing artifact
  -> keep the artifact's current mode unless user changes the goal
```

## Canon absence rule
`CANON_NOT_FOUND` はROUGH_MODEではSTOP理由ではない。
新規キャラで正本が無いならROUGHへ入る。

CANON_ASSET / ILLUSTRATIONで正本が必要なのに存在しない場合は、勝手に補完せずCANONIZATIONへ戻す。

## Mode transition authority
- ROUGH -> CANONIZATION: ユーザーが採用対象を示す、または正本化を明示する
- CANONIZATION -> CANON: ユーザーが採用/確定を明示する。生成成功だけでは昇格しない
- CANON -> CANON_ASSET / ILLUSTRATION: 対象正本が確定済みなら遷移可能

## Invariant
> 正本がないことは、新規設計を禁止する理由ではない。正本が必要な工程へ早すぎて入らない。
