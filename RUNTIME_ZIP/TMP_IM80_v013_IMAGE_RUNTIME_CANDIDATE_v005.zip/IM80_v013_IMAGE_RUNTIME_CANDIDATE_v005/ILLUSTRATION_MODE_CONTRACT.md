# ILLUSTRATION_MODE_CONTRACT / IM80 v013 CANDIDATE

## Purpose
ACTIVE_CANONを使い、サムネ、扉絵、イベント絵、通常イラストを作る。

## Required path
1. source read
2. reference binding
3. visible part lock
4. condition build
5. composition
6. PRE_GENERATION_REVIEW
7. approval
8. tool-call preflight
9. one image call
10. post check

## Prompt scope
画像エンジンへは `PROMPT_COMPILER_CONTRACT.md` で今回1枚に必要な条件だけを渡す。
Runtime全文をそのままpromptへ複製しない。

## Hard geometry
厳密な座標や版面指定が目的の場合はILLUSTRATION_MODE内でもHard Constraintを使う。
普通の構図指示はsoft compositionでよい。
