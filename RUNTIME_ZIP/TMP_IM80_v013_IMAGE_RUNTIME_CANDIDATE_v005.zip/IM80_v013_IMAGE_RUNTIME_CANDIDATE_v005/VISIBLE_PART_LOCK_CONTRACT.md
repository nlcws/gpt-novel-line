# VISIBLE_PART_LOCK_CONTRACT / IM80 v013 CANDIDATE

## 0. Purpose

## 0A. Mode scope

正本が存在するキャラクターの再現工程に適用する。
ROUGH_MODEで未正本の対象へ「正本由来LOCK」を捏造しない。ラフ段階の必須条件は `ROUGH_CONSTRAINT` として別扱いにする。

直接bindしたキャラ正本・パーツ正本から、**今回の画面に出る固有要素を生成条件として明示的にLOCK**する。

参照画像を渡しただけで「モデルが拾うだろう」と期待しない。

```text
DIRECT REFERENCE BINDING
→ VISIBLE PART EXTRACTION
→ PER-CHARACTER PART LOCK
→ PRE_GENERATION_REVIEW
→ GENERATE
```

`REFERENCE_BINDING_CONTRACT.md` が「何を参照へ渡すか」を決め、本契約は「その参照から今回の1枚で何を落としてはいけないか」を決める。

---

## 1. Hard invariants

- `VISIBLE_PART_LOCK_REQUIRED`
- `PART_LOCK_DERIVED_FROM_BOUND_IMAGES`
- `NO_REFERENCE_HOPE_ONLY`
- `NO_CROSS_CHARACTER_PART_TRANSFER`
- `COUNTED_PARTS_KEEP_COUNT`
- `ASYMMETRIC_PARTS_KEEP_SIDE`
- `VISIBLE_COSTUME_SIGNATURE_KEEP`
- `OCCLUSION_IS_NOT_DELETION`
- `CROP_IS_NOT_REDESIGN`
- `STYLE_CANNOT_OVERRIDE_PART_LOCK`
- `UNRESOLVED_PART_CONFLICT_STOP`

---

## 2. Per-character extraction

各人物について、bind済み `IDENTITY_SOURCE` / `PART_SOURCE` / `EVENT_SOURCE` を見て、今回の構図で関係する固有要素を抽出する。

対象例:
- 髪色 / インナーカラー / メッシュ
- 髪型 / 結び位置
- 眼鏡
- 猫耳 / 獣耳
- 尾の本数 / 色 / 形
- 羽
- ピアス / ネックレス / 固有アクセサリ
- 上着 / ハイネック / スカート / パンツ等の衣装シグネチャ
- 固有装備
- 体格差 / 年齢感
- 左右非対称パーツ

人物ごとに別管理し、他人のパーツを移植しない。

---

## 3. Lock classes

### 3.1 REQUIRED_VISIBLE
今回の絵で見えること自体が必要な識別要素。

例:
```text
野良ちゃん:
- white_forelock: REQUIRED_VISIBLE
- cat_ears: REQUIRED_VISIBLE
- two_tails: REQUIRED_VISIBLE
```

### 3.2 MATCH_IF_VISIBLE
構図上、隠れたり画面外になってよい。しかし見えるなら正本と一致必須。

例:
```text
修正刃さま:
- lower_coat_hem: MATCH_IF_VISIBLE
```

### 3.3 REQUIRED_COSTUME_SIGNATURE
今回の衣装を本人の正本衣装として成立させる主要要素。単に配色だけ似せて別服へ置換してはいけない。

例:
```text
設計さん:
- ivory_work_coat: REQUIRED_COSTUME_SIGNATURE
```

### 3.4 REQUIRED_COUNT
複数ある固有部位の数を固定。

例:
```text
野良ちゃん:
- tails: REQUIRED_COUNT=2
```

一部が遮蔽される場合でも、**存在自体を1本へ再設計しない**。

### 3.5 ASYMMETRIC_LOCK
左右差・片耳アクセサリ・特定側メッシュ等を固定。左右を勝手に交換しない。

---

## 4. Lock record

PRE_GENERATION_REVIEW前に、人物ごとに次を作る。

```text
VISIBLE_PART_LOCK
- character: <name>
  derived_from:
    - <bound identity image>
    - <bound part image>
  locks:
    - part: <canonical feature>
      class: REQUIRED_VISIBLE | MATCH_IF_VISIBLE | REQUIRED_COSTUME_SIGNATURE | REQUIRED_COUNT | ASYMMETRIC_LOCK
      value: <canonical value>
      evidence: <which bound image>
  crossover_forbidden:
    - <other character feature>
  lock_status: LOCKED
```

`evidence` がbind済み画像へ結び付かないLOCKを、正本LOCKとして捏造しない。

---

## 5. Composition interaction

VISIBLE_PART_LOCKは全身表示を要求しない。

- `REQUIRED_VISIBLE` を設定した部位だけは、CAMERA/CROPで見える位置を確保する。
- `MATCH_IF_VISIBLE` は自然な遮蔽・フレームアウト可。
- `REQUIRED_COUNT` は、全要素を必ず完全露出させる意味ではない。ただし数が別設定へ変化して見える構図は避ける。
- 人物を全部見せるために横並び・遠景化しない。

構図と `REQUIRED_VISIBLE` が両立しない場合、生成せずレビュー段階で構図を直す。

---

## 6. Generation wording rule

生成条件へは、bind済み画像参照に加えて、VISIBLE_PART_LOCKを短く明示する。

禁止:
- 「正本どおり」だけで済ませる
- 「画像を参考に」だけで済ませる
- 配色だけ列挙して衣装構造を落とす
- 他キャラと共通の美形化・衣装統一で固有要素を消す

文章は**参照画像から抽出したLOCKを強調するため**に使う。

---

## 7. Multi-character anti-crossover matrix

複数人絵では、人物ごとにLOCKを独立させる。

必要に応じて:

```text
ANTI_CROSSOVER
- 司書さん <- 執筆さん hair/costume: FORBIDDEN
- 設計さん <- 司書さん red-hair signature: FORBIDDEN
- 修正刃さま <- 設計さん blue-accent workwear: FORBIDDEN
- 野良ちゃん <- human-only ear/tail state: FORBIDDEN
```

STYLE参照に似た人物がいても、ANTI_CROSSOVERを上書きしない。

---

## 8. PRE_GENERATION_REVIEW gate

既存正本を使うキャラが登場する場合、`REFERENCE BINDING` に加えて `VISIBLE PART LOCK` を必須表示する。ROUGH_MODEで未正本の対象にはcanon lockを要求しない。

一人でも:
- required lock unresolved
- bound imageとlockが衝突
- lockと構図が両立不能
- counted partの扱いが曖昧

なら:

```text
generation_state: STOP_VISIBLE_PART_LOCK_UNRESOLVED
```

生成しない。

---

## 9. Post-generation audit

生成結果は、bind画像＋VISIBLE_PART_LOCKで判定する。

FAIL例:
- 野良ちゃんの白前髪差し欠落
- 野良ちゃんが一尾化
- 設計さんの指定衣装シグネチャ消失
- 修正刃さまの年齢感・固有衣装が他メンバーへ均質化
- 司書さんに別キャラの髪型/衣装が乗る
- STYLE人物の特徴へ全員が寄る

`雰囲気が近い` はPASS条件ではない。
