# PRE_GENERATION_REVIEW_SPEC / IM80 v013 CANDIDATE

## 0. Definition

`PRE_GENERATION_REVIEW` は生成前の確認メモではなく、その1枚の生成仕様書。
ユーザーが「何が、どこで、何をして、どの画角で、**どの実画像正本を直接使って**描かれるか」を確認できる粒度まで具体化する。

---

## 1. Standard Order

```text
## PRE_GENERATION_REVIEW

ACTIVE MODE
SCENE
SOURCE BASIS
TARGET
ACTION
REFERENCE BINDING     # 既存正本を使うキャラでは必須
VISIBLE PART LOCK      # 既存正本を使うキャラでは必須
STYLE LOCK
WORLD / COLOR
CAMERA
PHYSICS
CHARACTER LOCK
TEXT / OUTPUT SPEC
PRESERVE / CHANGE
PROHIBITED
AIM
UNRESOLVED

review_id: IM80-<session-local-id>
generation_state: WAIT_FOR_USER_APPROVAL
```

意味のない項目は省略可。既存正本を使うキャラクターが登場する場合は `REFERENCE BINDING` と `VISIBLE PART LOCK` を省略不可。ROUGH_MODEでまだ正本が存在しない新規キャラは例外。

---

## 2. REFERENCE BINDING

`REFERENCE_BINDING_CONTRACT.md` に従う。

人物ごとに:

```text
- <character>
  identity_image: <個別の実画像正本>
  part_images: <必要な衣装/パーツ実画像> / NOT_REQUIRED
  expression_image: <必要時の表情正本実画像> / NOT_REQUIRED
  event_image: <必要時の実画像> / NOT_REQUIRED
  text_supplement: <画像の何を固定するか>
  binding_status: BOUND
```

STYLEは別枠:

```text
- style_image: <実画像>
  usage: STYLE_ONLY
```

### Binding status
`BOUND` はファイル名を知っているだけでは成立しない。
生成エンジンが参照できる実画像としてmaterialize/bind済みであること。

必要な人物のうち一人でも未bindなら:

```text
generation_state: STOP_REQUIRED_REFERENCE_BINDING
```

として生成しない。

### Multi-character
複数人は全員を個別に記載。contact sheet / group imageを全員分のidentity bindingとして使わない。

---

## 3. VISIBLE PART LOCK

`VISIBLE_PART_LOCK_CONTRACT.md` に従う。

人物ごとに、bind済み画像から今回の画面で落としてはいけない固有要素を示す。

```text
- <character>
  derived_from: <bound image(s)>
  locks:
    - <part>: REQUIRED_VISIBLE = <value>
    - <part>: REQUIRED_COSTUME_SIGNATURE = <value>
    - <part>: REQUIRED_COUNT = <n>
    - <part>: MATCH_IF_VISIBLE = <value>
  crossover_forbidden: <other-character signatures>
  lock_status: LOCKED
```

一人でも `lock_status: LOCKED` でなければWAITへ入らずSTOP。

---

## 4. Required Quality

### SCENE
時間・場所・場面を一文で特定。

### TARGET
主要人物・必要背景人物。画面外の人物は無理に入れない。

### ACTION
静止ポーズではなく、生成する瞬間に何が起きているかを書く。

### STYLE LOCK
画風参照はSTYLE_ONLY。キャラ正本を上書きしない。

### WORLD / COLOR
時間帯、天候、支配色、背景密度、光。

### CAMERA
高さ・距離・前景・中景・奥・遮蔽・見切れ。

### PHYSICS
手、道具、軸、重力、風向、反射、設備、接地等の壊れやすい物理だけ局所LOCK。

### CHARACTER LOCK
画像bindingの補足。文章だけで本人性を再構築しない。
canonical expression sheetを使う場合もIDENTITY_SOURCEを置き換えず、表情温度の補助として扱う。

### TEXT / OUTPUT SPEC
タイトル、吹き出し、ロゴ、印、完成サイズなど。

### PROHIBITED
今回の事故源を具体的に列挙。

### AIM
この絵の狙いを一文で固定。

---

## 5. WAIT Gate / review_id interlock

レビュー提示時は固有 `review_id` を発行し:

```text
review_id: IM80-<session-local-id>
generation_state: WAIT_FOR_USER_APPROVAL
```

とする。

レビュー提示ターンでは画像生成ツールを呼ばない。ユーザーの次入力を待つ。

承認bind後も即tool callせず、`TOOL_CALL_PREFLIGHT_CONTRACT.md` の直前ASSERTを実行する。
画像生成ツールを呼べるのはpreflightが `PASS_TOOL_CALL_ALLOWED` の場合だけ。

preflightでは少なくとも:
- 現在有効なreview_id
- review提示が現在turnより前
- required reference bindings / visible part locks
- review / approval / current request fingerprint一致
- 承認後の条件変更なし

を確認する。

承認は固定語リストで判定しない。review_idの復唱も要求しない。

現在有効review_idが無ければ生成要求が来てもレビューへ戻る。
条件修正時は旧review_id失効 → 新レビュー → 新review_id → WAIT。
context loss時も再レビュー。

---

## 6. Narrative Source Rule

話パック・本文からレビューを作る場合、`SOURCE_TO_IMAGE_CONDITIONS.md` で抽出・解決した条件に限る。
本文にない感情・設定・イベントを絵映え目的で追加しない。


## v013 mode note
ROUGHでは「正本なし」を異常扱いしない。REFERENCE BINDING欄は既存正本が必要な場合だけ必須。
CANON_ASSETでは、画像tool callで生成するcomponentと、deterministic layerで固定するtemplate/geometry/textを分離してレビューへ記載する。
