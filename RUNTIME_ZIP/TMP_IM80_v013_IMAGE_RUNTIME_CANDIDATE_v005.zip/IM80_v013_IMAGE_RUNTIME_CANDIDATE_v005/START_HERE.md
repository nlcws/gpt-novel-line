# START_HERE / IM80 v013 CANDIDATE v005

1. Route request: ROUGH / CANONIZATION / CANON_ASSET / ILLUSTRATION / EDIT.
2. Read `000_IC/00_READ_FIRST/IM80_START_GATE.md`, then `000_IC/02_CONTROL_STATE` when mounted.
3. Read `011_G` local image gate.
4. Read `012_CA` target reusable canon.
5. If a task-bound `019_*` is mounted, read its scope before applying any override.
6. Resolve linked authoritative text canon.
7. Compile only call-relevant semantic constraints.
8. Use hard constraints/deterministic composition for exact geometry/layout/text.
9. Preserve Partial LKG; no blind reroll.

Canon absence is not a global STOP: new characters route through ROUGH -> CANONIZATION.
Finished artwork is not automatically committed to project shelves.

10. If `000_IC` reports `ZERO_START_READY`, read `ZERO_START_CONTRACT.md` and wait for grounded project input; empty 012_CA is normal.
