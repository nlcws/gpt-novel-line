# CANON_ASSET_MODE_CONTRACT / IM80 v013 CANDIDATE

## Purpose
ACTIVE_CANONを、三面図・キャラクターシート・表情シート・衣装分解・サイズ比較などの再利用可能な正本資料へ変換する。

## Core split

```text
CANON INPUT
 -> component extraction / generation
 -> PARTIAL LKG
 -> HARD CONSTRAINT COMPOSITION
 -> text/data rendering
 -> geometry validation
 -> visual/canon validation
 -> CANON ASSET CANDIDATE
```

## Image engine responsibility
画像エンジンへ任せてよいもの:
- 人物本体
- 顔/表情素材
- 衣装/パーツ素材
- 小物素材
- 局所的な見た目修正

原則として任せないもの:
- テンプレ全体の再描画
- ruler / scale
- exact coordinates
- panel borders
- text placement
- fixed typography
- bbox clipping
- output canvas dimensions

## Template immutability
Resident templateを使う場合、テンプレ画像は `IMMUTABLE_BASE`。
画像モデルに再生成・再解釈・装飾変更させない。

## Deterministic composition
座標・寸法・文字・枠・クリップは `HARD_CONSTRAINT_CONTRACT.md` に従って配置する。
ネイティブ画像編集APIでexact constraintを保証できない場合は、後処理/compositorで固定する。

## Partial LKG
ユーザーが一部分を承認したら、その領域を `PARTIAL_LKG_CONTRACT.md` に従い凍結する。
以後の修正は承認済み領域を再生成しない。

## Canon asset promotion
完成シートも生成成功だけではACTIVE_CANONに昇格しない。
ユーザー承認後に正本資産として採用する。


## Canon shelf commit target
`CANON_ASSET_CANDIDATE` remains outside canonical mounts while under review.
After explicit user acceptance, heavy reusable canonical assets are committed to `012_CA`, not duplicated into `000_IC` by default.
The commit record must update the target character's `CANON_LINKS.json` and `CURRENT_STATE/CANON_ASSET_INDEX.json`.
Text canon should be linked by locator/hash to its authoritative source unless an explicit snapshot policy says otherwise.
