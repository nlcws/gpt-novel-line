# TOOL_CALL_PREFLIGHT_CONTRACT / IM80 v013 CANDIDATE

## 0. Purpose

画像生成・画像編集ツールを呼ぶ**直前**に実行する、fail-closedの最終インターロック。
PRE_GENERATION_REVIEWを作ったこと、ユーザーが続行を求めたこと、参照画像をbindしたことだけでは画像ツールを呼ばない。

この工程はレビュー工程とは独立する。
**レビューを提示するターンでは、このpreflightをPASSさせて画像ツールを呼ぶことはできない。**

---

## 1. State model

最低限、以下を区別して保持する。

```text
current_request_fingerprint
current_review_id
review_request_fingerprint
review_emitted_turn
approved_review_id
approval_request_fingerprint
generation_state
required_binding_state
required_visible_part_lock_state
```

`request_fingerprint` は画像内容を左右する現在条件の同一性を示す内部識別。
少なくとも以下の変更で変化したものとして扱う:
- TARGET / CAST
- ACTION / SCENE
- IDENTITY / PART / EVENT / STYLE reference
- VISIBLE PART LOCK / ANTI_CROSSOVER
- CAMERA / CROP
- TEXT / LOGO
- OUTPUT SIZE / aspect
- EDIT対象画像
- PRESERVE / CHANGE
- PROHIBITED

fingerprintの文字列をユーザーへ復唱要求しない。

---

## 2. Review emission rule

PRE_GENERATION_REVIEWを提示した時点で:

```text
current_review_id = newly_issued_review_id
review_request_fingerprint = current_request_fingerprint
review_emitted_turn = current assistant turn
approved_review_id = NONE
approval_request_fingerprint = NONE
generation_state = WAIT_FOR_USER_APPROVAL
```

**同一assistant turnで画像ツールを呼ばない。**
レビュー提示後、ユーザーから独立した次の入力を待つ。

---

## 3. Approval bind rule

レビュー提示後のユーザー入力が、現在レビューへの承認として文脈上成立する場合のみ:

```text
approved_review_id = current_review_id
approval_request_fingerprint = current_request_fingerprint
generation_state = APPROVAL_BOUND
```

固定承認語リストは使用しない。
ただし、ユーザー入力に条件変更が含まれる場合は承認と同時に扱わない。
変更を反映し、現review_idを失効させ、新レビューへ戻る。

`次へ / よろしく / 続けて` 等は、**有効な現在レビューが存在する場合に限り**文脈上の承認候補になりうる。
レビューが無い状態、生成後、別タスク開始後では承認状態を持ち越さない。

---

## 4. TOOL CALL PREFLIGHT ASSERT

画像生成・画像編集ツールを呼ぶ直前に、毎回以下を全件ASSERTする。

```text
A01 current_review_id EXISTS
A02 review_emitted_turn IS BEFORE current assistant turn
A03 generation_state == APPROVAL_BOUND
A04 approved_review_id == current_review_id
A05 current_request_fingerprint == review_request_fingerprint
A06 current_request_fingerprint == approval_request_fingerprint
A07 all mode-required identity/part/event bindings == BOUND or NOT_REQUIRED; ROUGH without canon may be NOT_YET_CANON
A08 all mode-required visible part locks == LOCKED or NOT_REQUIRED; ROUGH without canon does not fabricate canon locks
A09 style references, if any, == STYLE_ONLY where required
A10 no unresolved source/canon conflict
A11 edit task => target image materialized and unambiguous
A12 no condition-changing input occurred after approval bind
A13 tool call is ONE_IMAGE_ONLY and matches reviewed operation
```

全件成立した場合のみ:

```text
preflight_result: PASS_TOOL_CALL_ALLOWED
```

一件でも不成立なら画像ツールを呼ばない。

---

## 5. Fail closed actions

### REVIEW_MISSING
A01/A02不成立:
```text
preflight_result: FAIL_REVIEW_REQUIRED
action: PRE_GENERATION_REVIEWを提示してWAIT
```

### APPROVAL_MISSING
A03/A04不成立:
```text
preflight_result: FAIL_APPROVAL_REQUIRED
action: WAIT_FOR_USER_APPROVAL
```

### FINGERPRINT_MISMATCH
A05/A06/A12不成立:
```text
preflight_result: FAIL_REVIEW_STALE
old current_review_id: INVALIDATED
action: 条件を反映した新PRE_GENERATION_REVIEWを提示してWAIT
```

### REFERENCE_OR_LOCK_FAILURE
A07/A08/A09/A10/A11不成立:
```text
preflight_result: FAIL_RUNTIME_CONDITION
action: STOPまたは修正レビュー。推測で穴埋めしない。
```

---

## 6. Approval lifetime

承認は**1 review / 1 image call**にだけ有効。
画像ツール呼出開始時に承認を消費する。

```text
approved_review_id = CONSUMED
approval_request_fingerprint = CONSUMED
generation_state = GENERATION_IN_PROGRESS
```

生成終了後:

```text
current_review_id = NONE
approved_review_id = NONE
generation_state = READY_FOR_REQUEST
```

したがって、生成後にユーザーが `次へ` と言っても、前回承認を使って次画像を自動生成しない。
新しい画像を作るなら、新しいレビューから始める。

---

## 7. Context loss / runtime reload

以下のどれかを検証できない場合はFAIL CLOSED:
- current_review_id
- review_request_fingerprint
- approval bind
- request fingerprint一致

別スレッド、再起動、Runtime差し替え等で状態同一性が保証できなければ、再レビューする。
「前に承認したはず」を推測して生成しない。

---

## 8. Direct image requests are not exceptions

「画像を作って」「サムネお願い」「一人ずつ作って」等の直接画像要求でも、review未提示なら:

```text
REQUEST -> SOURCE/REFERENCE/LOCK BUILD -> PRE_GENERATION_REVIEW -> WAIT
```

へ進む。
**直接要求そのものを生成承認として二重利用しない。**

---

## 9. Runtime invariant

> IMAGE TOOL CALL IS FORBIDDEN UNTIL TOOL_CALL_PREFLIGHT PASS.

画像生成ツールを呼んだ後に「本当はレビューが必要だった」と気付く運用を禁止する。
判断点は必ずtool callより前に置く。
