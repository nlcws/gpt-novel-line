# IM80 v013 CANDIDATE

画像生成・画像編集・画像正本化Runtime。

v013は、従来の「正本を使って1枚描く」経路に加えて、**正本がまだ存在しない新規キャラクターを起こし、正本化し、正本資料へ変換する生命周期**を追加する。

## Lifecycle
```text
ROUGH_MODE
  -> CANONIZATION_MODE
  -> CANON_ASSET_MODE
  -> ILLUSTRATION_MODE
```

既存正本がある案件は必要な前段を飛ばしてよい。

## Mode roles
- `ROUGH_MODE`: 新規案。正本不要。出力はCANDIDATE
- `CANONIZATION_MODE`: 顔・身体・色・衣装・小物等をLOCKし、ユーザー採用で正本化
- `CANON_ASSET_MODE`: 三面図、キャラシート、表情、衣装パーツ等を正確に組版
- `ILLUSTRATION_MODE`: サムネ、扉絵、イベント絵等

## v013 architecture
```text
Runtime / Canon / State
  -> Mode Router
  -> Reference / Lock resolution
  -> Prompt Compiler (semantic constraints)
  -> Image Engine (visual component generation)
  -> Hard Constraint Layer (geometry/text/template)
  -> Partial LKG
  -> Validator
```

## Important separation
長いRuntime全文をそのまま画像promptへ渡さない。
画像エンジンへは今回のcallに必要な意味制約だけをcompileする。

exact coordinate / ruler / panel / text / clippingはpromptだけで保証しない。
CANON_ASSET_MODEではテンプレを固定し、必要に応じてdeterministic compositionを使う。

## Resident generic template
`ASSETS/TEMPLATES/GENERIC_THREE_VIEW_CHARACTER_SHEET_v001.png`

Project固有要素を持たない、汎用三面図・キャラクター設定シートの原板。
TEMPLATE_ONLY。本人性・画風参照には使わない。

## Preserved v012 protections
- direct reference binding
- expression source separation
- visible part lock
- review_id / approval interlock
- tool-call preflight
- no blind reroll
- mount version decoupling
- `000_IC.zip` read-only during normal generation


## Dedicated canon shelf
Heavy accepted visual canon can be separated from `000_IC` into project shelf `012_CA_v001.zip`.
`012_CA` contains accepted canonical assets and link manifests to authoritative text canon; `000_IC` remains operational/reference imagery.
This avoids bloating image continuity mounts with reusable three-view and character-base sheets.
