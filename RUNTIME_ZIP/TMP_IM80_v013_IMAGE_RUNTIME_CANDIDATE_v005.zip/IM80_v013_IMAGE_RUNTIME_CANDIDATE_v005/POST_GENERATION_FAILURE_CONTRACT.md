# POST_GENERATION_FAILURE_CONTRACT / IM80 v013 CANDIDATE

## 0. Purpose
POST CHECKでFAILした画像を、理由も条件変更もないまま再生成し続けることを禁止する。

画像生成は1 callごとに検品し、FAIL時は**失敗原因と次回変更点を先に確定**する。

## 1. Hard invariants
- `NO_BLIND_REROLL`
- `FAILED_CALL_CONSUMES_APPROVAL`
- `POST_FAIL_REVIEW_INVALIDATED`
- `FAIL_REASON_BEFORE_RETRY`
- `CHANGED_CONDITION_BEFORE_CORRECTIVE_RETRY`
- `STOCHASTIC_RETRY_REQUIRES_USER_EXPLICIT`
- `ONE_REVIEW_ONE_IMAGE_CALL`

## 2. After image call
画像tool callが実行された時点で、そのreview / approvalは消費済み。
生成結果がPASSでもFAILでも再利用しない。

POST CHECKは少なくとも次を確認する。
- bound identity一致
- required costume / part signature一致
- expression temperature（適用時）
- anti-crossover
- required count / asymmetry
- physics / object integrity
- camera / crop
- text / output spec

## 3. FAIL classification
FAIL時は主原因を最低1つ分類する。

- `REFERENCE_BINDING_FAIL` : 必要画像が正しくbindされていない / materialization不明
- `IDENTITY_OR_PART_FAIL` : 顔・髪・体格・衣装・固有部位が正本から外れた
- `EXPRESSION_FAIL` : 表情レンジ・反応温度が正本補助から外れた
- `CROSSOVER_FAIL` : 他キャラ記号が混入
- `COMPOSITION_OR_PHYSICS_FAIL` : 構図・接地・道具・身体・設備関係の破損
- `TEXT_OR_OUTPUT_FAIL` : 文字・ロゴ・サイズ等の出力条件違反
- `TOOL_OR_MODEL_VARIANCE` : 条件・binding・lockに明確な不備がなく生成揺らぎと判断
- `UNRESOLVED_FAIL` : 原因を特定できない

## 4. Retry gate
### Corrective retry
上記FAILの原因が条件・binding・lock・構図で修正可能なら、**何を変えるかを先に決める**。
旧reviewを失効し、新PRE_GENERATION_REVIEWを提示してWAITへ戻る。

### Same-condition retry
同じ条件のまま再生成してよいのは:
1. 条件 / binding / lock / output specに明確な欠陥がない
2. `TOOL_OR_MODEL_VARIANCE` と判断できる
3. ユーザーが同条件retryを明示的に希望する

この場合も旧approvalは再利用せず、新review → 新approval → 1 image call。

### Forbidden
- FAIL直後に自動でもう1枚生成
- 「今度はうまくいくかも」だけをretry理由にする
- 同一review_id / approvalの再利用
- 原因不明のまま回数で解決しようとする

## 5. User-facing fail report
最低限:
```text
POST CHECK: FAIL
fail_class: <class>
failed_items:
- <what failed>
next_change:
- <what will change before next review>
retry_state: STOP_FOR_NEW_REVIEW | WAIT_FOR_USER_EXPLICIT_STOCHASTIC_RETRY
```

## 6. Principle
> 改善点がないなら、同じ条件で回さない。

生成回数ではなく、条件・参照・構図・原因の解像度を上げてから次へ進む。


## 7. Failure isolation / v013
画像tool callのFAILは、そのcallと依存領域へ限定する。

- PARTIAL_LKGを巻き戻さない
- 独立して進められる正本整理、source読込、layout計測、文字データ整理を停止しない
- CANON_ASSETで生成componentだけFAILした場合、template / geometry / text作業までFAIL扱いしない

ただしFAIL原因が正本衝突や必要source欠落なら、その依存工程はHOLD/STOPする。
