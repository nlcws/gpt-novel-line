# PARTIAL_LKG_CONTRACT / IM80 v013 CANDIDATE

## Purpose
成果物の一部分がユーザー承認済みになった後、別部分の修正でその領域を壊さない。

## State
```text
region_id
bbox / mask
source_artifact
source_hash
status: CANDIDATE | LKG_LOCKED
reason / approval context
```

## Promotion
ユーザーが「左はOK」「顔はこれで良い」等、部分採用を明示した場合、その範囲をLKGへ昇格できる。

## Rules
- LKG領域を後続の全体再生成へ巻き込まない
- 修正対象外のLKGはbyte/visual preserveを優先
- toolが局所編集できなければ、LKGを保持したcomposite routeへ切り替える
- LKGを書き換える必要が出た場合は、その領域の承認を改めて取り直す

## Failure isolation
一部分のFAILで、別のLKG領域まで未採用へ戻さない。
