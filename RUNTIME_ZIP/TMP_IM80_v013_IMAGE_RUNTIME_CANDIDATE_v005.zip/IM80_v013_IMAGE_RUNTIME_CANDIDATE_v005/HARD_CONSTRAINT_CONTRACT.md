# HARD_CONSTRAINT_CONTRACT / IM80 v013 CANDIDATE

## Purpose
言語promptでは保証できない寸法・座標・版面・文字・クリップを、実座標/機械処理で固定する。

## Hard constraint classes
- `CANVAS_SIZE`
- `TEMPLATE_BYTES`
- `REGION_BBOX`
- `CLIP_MASK`
- `RULER_MAP`
- `ANCHOR_POINT`
- `TEXT_BOX`
- `FONT_LAYOUT`
- `SAFE_MARGIN`
- `LOCKED_REGION`

## Rule
画像モデルが「158cm」と理解したことは、158cm座標へ一致したことを意味しない。

```text
semantic_value != geometric_constraint
```

## Canon asset policy
CANON_ASSET_MODEでは:
- template bitmapを再生成しない
- rulerを画像モデルに描き直させない
- exact textを画像モデルへ任せない
- generated componentを指定bboxへclipして配置する
- ruler等の数値は実ピクセル座標へ変換して検証する

## Tool strategy
1. native exact edit / mask / layout機能があるなら使用
2. 不足する場合はdeterministic compositorを使用
3. どちらでも保証不能ならHOLD。promptだけで「厳密」と主張しない

## Validation example
身長H cm、ruler 0cm anchor `y0`、ruler max M cm anchor `yM` の場合:

```text
y(H) = y0 - H/M * (y0 - yM)
```

足裏anchorと頭頂anchorを実座標で検証する。

## No fake pass
画像中に `158cm` と文字表示されていても、頭頂がruler 158cmへ一致していなければFAIL。
