# REFERENCE_BINDING_CONTRACT / IM80 v013 CANDIDATE

## 0. Purpose

## 0A. Mode scope

この契約は、**既に本人性/衣装等の正本画像が存在し、それを使う工程**で適用する。

- ROUGH_MODEでまだ正本が存在しない新規キャラ: IDENTITY_SOURCEは `NOT_YET_CANON` としてよく、存在しないbindingを要求しない。
- CANONIZATION_MODE: 既存正本があればbind。採用ラフを正本候補にする場合はCANDIDATE_SOURCEとして扱う。
- CANON_ASSET / ILLUSTRATION: 必要正本が存在するならdirect binding必須。

`UNBOUND_REFERENCE_STOP` は「必要な正本が存在し、今回工程で必要なのにbindできない」場合に適用する。

キャラクター正本画像・衣装/パーツ画像が存在するのに、文章要約・コンタクトシート・STYLE画像だけで人物を再構成する事故を禁止する。

IM80では、**画像正本を主、文章を従**とする。

```text
DIRECT IDENTITY IMAGE
→ DIRECT COSTUME / PART IMAGE
→ optional EXPRESSION image
→ optional EVENT image
→ STYLE image (style only)
→ TEXT SUPPLEMENT
→ GENERATE
```

画像参照が必要な場面で、ファイル名を文章に書いただけでは `BOUND` にならない。
生成エンジンが参照できる実画像として結び付いていることが必要。

---

## 1. Hard invariants

- `DIRECT_ASSET_BINDING_REQUIRED`
- `IDENTITY_IMAGE_BEFORE_TEXT`
- `PART_IMAGE_BEFORE_TEXT`
- `EXPRESSION_IS_NOT_IDENTITY_REPLACEMENT`
- `STYLE_IS_NOT_IDENTITY`
- `CONTACT_SHEET_IS_NOT_PER_CHARACTER_BINDING`
- `GROUP_REFERENCE_IS_NOT_PER_CHARACTER_BINDING`
- `TEXT_SUPPLEMENTS_IMAGES`
- `MULTI_CHARACTER_BIND_EACH_CHARACTER`
- `UNBOUND_REFERENCE_STOP`

---

## 2. Per-character binding

生成対象の各キャラクターについて、生成前に次を解決する。

### 2.1 IDENTITY_SOURCE
顔、髪、体格、年齢感、本人性の正本。

優先例:
1. 今回ユーザーが直接指定した本人画像
2. `012_CA_v001/10_CANON/CHARACTERS/<name>/...` accepted canonical visual asset
3. Project現行正本の個別プロフィール / 立ち絵 / character sheet
4. explicit user-bound or task-mounted supporting visual source
5. Project固定骨の個別visual source

個別正本が存在するなら、コンタクトシートだけで代用しない。

### 2.2 PART_SOURCE
今回見える衣装、髪パーツ、眼鏡、耳、尾、羽、アクセサリ、固有装備などを拘束する画像。

優先例:
1. 今回ユーザー指定パーツ画像
2. `019_*` task-bound costume/part source when mounted
3. Project固定骨のparts design / costume sheet
4. 必要時のみevent variant

今回の画面に見える固定パーツが画像正本として存在するのに、文章だけで代用しない。

### 2.3 EXPRESSION_SOURCE
通常・笑顔・困り・説明中など、キャラクターの表情レンジを示すcanonical expression sheet。

使用条件:
- Project / image mount上で現行の表情正本として扱われている
- 今回の表情・反応温度を拘束する意味がある
- 実画像として生成入力へbindできる

用途は**顔の本人性を再設計することではなく、IDENTITY_SOURCEで固定した本人の表情レンジを補助すること**。
存在しても毎回必須ではない。不要なら `NOT_REQUIRED`。

### 2.4 EVENT_SOURCE
季節衣装・工房衣装・特定イベント差分などが明示され、個別event visualが存在する場合だけ使用。

### 2.5 STYLE_SOURCE
画風、塗り、情報密度、光、スナップ感だけ。
**顔、髪、年齢、体格、衣装、性別、固有パーツの根拠にしない。**

---

## 3. Actual binding requirement

`READ` と `BIND` は別。

正本画像を読んだ、見た、ファイルパスを知っている、文章へ転記した、だけでは生成参照として不十分。

生成直前に、各 `IDENTITY_SOURCE` / 必要な `PART_SOURCE` / 必要な `EXPRESSION_SOURCE` / 必要な `EVENT_SOURCE` が、**生成エンジンへ実画像参照として渡せる状態**であることを確認する。

内部状態:

```text
reference_read: true
reference_materialized: true
reference_bound: true
```

一つでも必要項目が `false / unknown` なら生成しない。

利用中の画像生成機構で、必要な個別実画像を生成入力へ結び付けられない場合は:

```text
STOP: REQUIRED_DIRECT_REFERENCE_NOT_BOUND
```

文章だけで続行しない。

---

## 4. Multi-character scenes

複数人の場合、人物ごとに別行でbindingを作る。

例:

```text
CHARACTER_BINDINGS
- 設計さん
  IDENTITY: 01_CHARACTER_BASE/設計さん/設計さん_プロフィール.png
  PARTS:    02_COSTUME_BASE/設計さん/設計さん_パーツデザインシート.png
  EXPRESSION: 01_CHARACTER_BASE/設計さん/設計さん_表情シート.png / NOT_REQUIRED
  STATUS:   BOUND

- 野良ちゃん
  IDENTITY: 01_CHARACTER_BASE/野良ちゃん/野良ちゃん_基準着衣.png
  PARTS:    02_COSTUME_BASE/野良ちゃん/野良ちゃん_衣装パーツ解説.png
  EXPRESSION: 01_CHARACTER_BASE/野良ちゃん/野良ちゃん_表情シート.png / NOT_REQUIRED
  STATUS:   BOUND
```

1枚の集合画像、contact sheet、group referenceを4人分のidentity bindingとして扱わない。
それらは関係・距離・画風補助としてだけ使える。

---

## 5. Text supplement rule

文章は画像の代わりではない。

文章で補足してよいもの:
- この画像のどの要素を固定するか
- 今回見せる/見せないパーツ
- 表情、行動、姿勢
- 混線禁止事項
- 正本画像間の役割分担

文章で新規に作ってはいけないもの:
- 正本画像と異なる顔
- 正本にない髪型変更
- 体格再設計
- 衣装の別物化
- 他キャラの記号移植

---

## 6. PRE_GENERATION_REVIEW requirement

キャラクターが登場するレビューでは `REFERENCE BINDING` を省略禁止。

最低限:

```text
REFERENCE BINDING
- <character>
  identity_image: <actual asset>
  part_images: <actual asset(s)> / NOT_REQUIRED
  expression_image: <actual asset> / NOT_REQUIRED
  event_image: <actual asset> / NOT_REQUIRED
  text_supplement: <short lock>
  binding_status: BOUND
- style_image: <actual asset> / NOT_REQUIRED
  usage: STYLE_ONLY
```

`binding_status: BOUND` と確認できない人物が一人でもいれば、`generation_state` はWAITではなくSTOP。

---

## 7. Visible-part handoff

直接binding完了後、生成へ進む前に必ず `VISIBLE_PART_LOCK_CONTRACT.md` を実行する。

`BOUND` は「参照画像を渡した」状態であり、今回の1枚で必要な固有パーツが拘束済みという意味ではない。
今回見える髪差し、耳、尾、眼鏡、衣装シグネチャ、左右差、個数等を人物ごとに抽出し、`VISIBLE_PART_LOCK` を `LOCKED` にする。

---

## 8. Post-generation identity audit

生成後は、文章だけではなく**直接bindingした画像**と比較する。

FAIL例:
- 司書さんへ執筆さんの衣装/髪記号が移る
- 設計さんの体格が別キャラへ寄る
- 修正刃さまの眼鏡・赤差しが消える
- 野良ちゃんの耳/二尾/白前髪差しが欠落
- STYLE画像の顔へ全員が均質化

本人性ズレを「雰囲気は近い」でPASSしない。


## 012_CA text link resolution
When `012_CA` supplies `CANON_LINKS.json`, resolve its linked physical/behavior text canon before text supplementation.
The visual asset in `012_CA` remains the visual identity authority; linked text supplies physical numbers, role, behavior, relationship, and other nonvisual constraints.
Missing or hash-conflicting required linked text is HOLD, not permission to reconstruct from memory.
