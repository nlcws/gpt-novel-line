# IM80 v013 CANDIDATE v005 / RUNTIME CONTRACT

`runtime_id: IM80`
`version: v013-candidate-v005`

## Lifecycle
ROUGH -> CANONIZATION -> CANON_ASSET -> ILLUSTRATION

## Image shelf architecture
- 000_IC = control/state only
- 011_G = image local gate/index/policy
- 012_CA = reusable accepted visual canon
- 019_* = temporary task/event scoped source pack
- final/event/one-off outputs = external archive by default

## Source priority (scoped)
1. current explicit user instruction
2. active 019 scoped override, only for fields declared by its scope
3. 012_CA accepted reusable visual canon
4. linked physical/text canon
5. task-bound references
6. candidate/rough allowed by current mode

019 cannot silently rewrite identity/body/base canon globally.
Generation success does not equal canon promotion. User acceptance + transfer/commit is required.

## Control boundary
000_IC is fixed control shelf and READ ONLY during normal generation. IMT00 resident activates only on explicit transfer request.

## Core protections
DIRECT_ASSET_BINDING / VISIBLE_PART_LOCK / PROMPT_COMPILER / HARD_CONSTRAINT / TEMPLATE_IMMUTABLE / PARTIAL_LKG / NO_BLIND_REROLL / FAILURE_ISOLATION / PRE_GENERATION_REVIEW / TOOL_CALL_PREFLIGHT.
