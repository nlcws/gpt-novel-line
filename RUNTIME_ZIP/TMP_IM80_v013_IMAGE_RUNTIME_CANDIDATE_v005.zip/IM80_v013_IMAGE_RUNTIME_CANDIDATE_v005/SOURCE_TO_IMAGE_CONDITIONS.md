# SOURCE_TO_IMAGE_CONDITIONS / IM80 v013 CANDIDATE

## 0. Purpose

話パック・単話テキスト・自由テキスト・直接指示を、1枚の画像生成条件 `IMAGE_CONDITION_SET` へ変換する。
本文事実と画像演出を混同しない。キャラ画像正本がある場合は `REFERENCE_BINDING_CONTRACT.md` を通し、画像正本を文章へ要約して終わらせない。

## 1. MODE + SOURCE_KIND

最初に `MODE_ROUTER.md` で active_mode を確定する。

`active_mode: ROUGH | CANONIZATION | CANON_ASSET | ILLUSTRATION`

## 1.1 SOURCE_KIND
DIRECT_IMAGE_REQUEST / STORY_PACK / SINGLE_STORY_TEXT / FREEFORM_TEXT / EDIT_IMAGE_SOURCE / MIXED_SOURCE。

STORY_PACKは対象話を特定し本文を実読。曖昧ならSTOP。
EDITは対象画像実体必須。

## 2. Source Fact Classes
- USER_EXPLICIT
- SOURCE_EXPLICIT
- PROJECT_CANON
- IMAGE_MOUNT_CANON
- ADOPTED_VISUAL_CONTINUITY
- VISUAL_CHOICE
- UNRESOLVED

VISUAL_CHOICEを正本事実のように扱わない。

## 3. Story/Text -> Condition Build
対象資料から:
- episode / title
- scene candidate
- target characters
- world / location / time
- action
- props / equipment
- physical relations
- dialogue / text candidates
- emotional temperature
- explicit visual constraints
- prohibited implications

を抽出。

Project正本・画像マウントから:
- character identity
- costume
- visible fixed parts
- body / height relation
- world design
- recurring marks / logos
- output size / aspect
- image-series continuity

を解決。

### 3.1 Character asset resolution
登場キャラごとに:

```text
identity_source
part_sources
optional_expression_source
optional_event_source
optional_style_source
binding_status
visible_part_locks
anti_crossover
text_supplement
```

まで解決する。

正本画像がある場合、`identity_source` / 必要 `part_sources` / 必要時 `optional_expression_source` を実画像bindingせずに `character_lock` の文章だけ作って終わらせない。

さらにbinding後、`VISIBLE_PART_LOCK_CONTRACT.md` に従って今回画面に必要な固有パーツを抽出し、lockを作る。

## 4. Scene Selection from Narrative
優先:
1. ユーザー指定場面
2. 話の核を一目で伝える場面
3. 作品温度・ギャグ構造を壊さない場面
4. 正本設備を無理に再設計しなくて済む場面
5. 1枚で物理的に成立する場面

同等候補が複数ならレビュー内で採用理由を短く示す。

## 5. IMAGE_CONDITION_SET

```text
source_kind
source_basis
scene
target
action
reference_bindings
visible_part_locks
anti_crossover
style_lock
world_color
camera
physics
character_lock
text_output_spec
preserve_change
prohibited
aim
unresolved
```

空欄を埋めるためだけの創作は禁止。

## 6. Output Size
1. 今回ユーザー指定
2. Project画像ルール
3. `000_IC/02_CONTROL_STATE`
4. 画像マウント共通規則

過去の別Projectサイズを持ち込まない。

## 7. STOP
- STORY_PACK対象話不明
- 対象本文読取不能
- CANON_ASSET / ILLUSTRATIONでキャラ識別に必要な正本不足
- CANONIZATION / CANON_ASSET / ILLUSTRATIONで必要な個別正本画像を実画像bindingできない
- CANONIZATION / CANON_ASSET / ILLUSTRATIONで必要な衣装/パーツ正本画像をbindingできない
- required visible part lockを根拠画像から確定できない
- visible part lockと構図が両立しない
- 本文とProject正本が明確に衝突
- 必要物理関係が未解決
- 未解決を推測しないと成立しない


## 8. Request fingerprint handoff
IMAGE_CONDITION_SETが確定した時点で、画像内容を左右する条件の同一性を `current_request_fingerprint` として扱う。
PRE_GENERATION_REVIEWはこのfingerprintをsnapshotし、承認bindとtool-call preflightで一致を確認する。
TARGET / reference / lock / scene / camera / text / output / edit target等が変われば旧review/approvalは失効する。
