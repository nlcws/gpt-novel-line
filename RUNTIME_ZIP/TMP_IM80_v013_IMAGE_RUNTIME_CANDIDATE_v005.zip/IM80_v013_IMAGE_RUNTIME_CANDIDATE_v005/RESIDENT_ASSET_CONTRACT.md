# RESIDENT_ASSET_CONTRACT / IM80 v013 CANDIDATE

## Purpose
Project固有ではない、Runtime共通の再利用資産を保持する。

## Resident template
`ASSETS/TEMPLATES/GENERIC_THREE_VIEW_CHARACTER_SHEET_v001.png`

Role:
- project-neutral three-view / character reference sheet base
- CANON_ASSET_MODE用
- TEMPLATE_ONLY
- identity sourceではない
- style sourceではない

Rules:
- 元画像をIMMUTABLE_BASEとして扱う
- Projectロゴ、固有名、固有世界観を追加した版をResidentへ上書きしない
- Project固有差分は作業成果物側で持つ
- 版面を変更する場合は新version assetとして追加し、既存をsilent overwriteしない

## Blank template guarantee
Resident templateは特定Projectの人物・ロゴ・固有アイテムを含めない。
