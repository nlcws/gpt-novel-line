# PROMPT_COMPILER_CONTRACT / IM80 v013 CANDIDATE

## Purpose
Runtimeの長い規則全文を画像エンジンへ投げず、今回の1 callで必要な意味制約だけへ圧縮する。

## Principle
> 詳しいほど良い、ではない。曖昧な自由度を潰すために必要な情報だけ詳しくする。

## Input
- active mode
- current target
- bound references
- visible part locks
- action/pose
- visual style
- camera/crop
- prohibited changes
- soft composition requests

## Output sections
```text
TARGET / IDENTITY
TASK
REQUIRED VISIBLE FEATURES
POSE / ACTION
STYLE / RENDERING
CAMERA / CROP
DO NOT CHANGE
OUTPUT INTENT
```

必要のないsectionは省略する。

## Do not compile as prompt-only hard constraints
次は自然言語で書くだけでは保証とみなさない:
- exact pixel coordinates
- exact ruler mapping
- exact panel boundary
- exact text baseline
- exact output canvas placement
- exact bbox clipping

これらは `HARD_CONSTRAINT_CONTRACT.md` へ渡す。

## Reference handling
画像正本がある場合、本人性は実画像bindingを主とする。
promptは参照画像の役割・落としてはいけない点を短く補助する。

## Anti-bloat
同義反復を増やさない。
Runtimeの履歴・工程・正本棚構造を画像エンジンへ説明しない。
