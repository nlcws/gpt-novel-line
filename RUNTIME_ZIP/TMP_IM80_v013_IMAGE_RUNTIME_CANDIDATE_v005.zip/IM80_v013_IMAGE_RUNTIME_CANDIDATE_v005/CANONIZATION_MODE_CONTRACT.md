# CANONIZATION_MODE_CONTRACT / IM80 v013 CANDIDATE

## Purpose
ROUGH_CANDIDATEまたは既存資料から、後工程が参照できる正本を作る。

## Canon lock classes
- `IDENTITY_LOCK`: 顔、髪、瞳、本人性、年齢感
- `PHYSICAL_LOCK`: 年齢、身長、体重、B/W/H、靴サイズ、体型など確定済み身体情報
- `COLOR_LOCK`: 髪、瞳、肌、基本衣装等の基準色
- `BASE_COSTUME_LOCK`: 基本衣装
- `ITEM_LOCK`: 固有小物、アクセサリ、装備
- `RELATION_LOCK`: 必要な人物関係や立場
- `OPEN_ITEM`: 未確定。埋めない

## Evidence
各LOCKは、最低1つの根拠へ結び付ける。
- user explicit
- adopted rough image
- project text canon
- project image canon
- physical canon pack

根拠無しLOCKは禁止。

## Promotion gate
正本化はユーザーの採用/確定によってのみ成立する。

```text
candidate_generated != canon_promoted
```

採用前は `CANON_CANDIDATE`。
採用後にのみ `ACTIVE_CANON`。

## Conflict
複数資料が衝突する場合、勝手に平均化しない。
優先順位で解けなければHOLDし、衝突項目だけをユーザーへ示す。

## Output
- canonical visual source(s)
- lock record
- open item record
- provenance/evidence record
