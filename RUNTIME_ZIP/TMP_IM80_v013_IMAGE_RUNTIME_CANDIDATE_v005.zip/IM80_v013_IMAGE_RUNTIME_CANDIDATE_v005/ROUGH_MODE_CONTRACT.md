# ROUGH_MODE_CONTRACT / IM80 v013 CANDIDATE

## Purpose
正本が存在しない対象を探索する。方向性を作る段階であり、正本を装わない。

## Allowed inputs
- ユーザーの文章設定
- 世界観 / 役割 / 年齢帯 /雰囲気
- 参考画像
- 既存Projectの非本人性style reference
- ラフな身体条件・衣装条件

## Output status
全出力は `ROUGH_CANDIDATE`。
ファイル名・メモ・レビューで正本、CANON、LOCKEDと表記しない。

## Allowed freedom
- 複数案
- 配色差分
- 髪型差分
- 衣装方向差分
- 顔つきの候補比較

ただしユーザー明示条件・Project世界観・安全条件は守る。

## Prohibited
- ラフ生成成功だけで正本化
- 未確定身体数値を確定値として発明
- 他キャラ正本の記号を無断転用
- style imageを本人性の正本扱い

## Handoff to Canonization
採用候補が決まったら、候補画像と明示設定を `CANONIZATION_INPUT` として渡す。
未確定項目一覧も渡す。
