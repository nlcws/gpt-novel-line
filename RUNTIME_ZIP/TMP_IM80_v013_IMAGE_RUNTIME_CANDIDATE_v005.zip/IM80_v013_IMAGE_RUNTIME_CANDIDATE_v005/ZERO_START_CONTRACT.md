# ZERO_START_CONTRACT / IM80 v013 CANDIDATE v005

## Purpose
Project固有の画像正本がまだ無い新規Projectを、推測補完なしでIM80へ接続する。

## Required zero-start mount
- `000_IC.zip` : IM80 control/resident shelf, `project_state = ZERO_START_READY`
- `011_G_v000.zip` : project-neutral image local gate
- `012_CA_v000.zip` : empty reusable visual canon shelf

`019_*` はZERO STARTでは作成しない。イベント資料が実在し、ユーザーが投入した時だけ存在する。

## Boot behavior
1. `000_IC/00_READ_FIRST/IM80_START_GATE.*` を読む。
2. `IMAGE_PROGRESS.json` が `ZERO_START_READY` なら、Project名・人物・世界観を勝手に作らない。
3. `011_G_v000` で棚境界を確認する。
4. `012_CA_v000` が空であることは正常。新規キャラは `ROUGH -> CANONIZATION` へ入れる。
5. Project固有sourceが投入されたら、実読してbindingを作る。
6. ユーザー明示採用前に `012_CA` へcanon promotionしない。
7. Project binding成立後、必要なsemantic shelfだけ版上げする。空の未来棚を先行生成しない。

## Root boundary
DS90 / `000_C`, BL90 / `000_BC`, IM80 / `000_IC` は並列Root。ZERO STARTでも相互resident化しない。
