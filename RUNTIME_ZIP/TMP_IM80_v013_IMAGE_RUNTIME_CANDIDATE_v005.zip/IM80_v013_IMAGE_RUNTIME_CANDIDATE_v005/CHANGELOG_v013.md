# IM80 v013 CANDIDATE CHANGELOG

## Added
- 4-mode lifecycle: ROUGH / CANONIZATION / CANON_ASSET / ILLUSTRATION
- canon absence routes to ROUGH instead of global STOP
- explicit canon promotion gate
- Prompt Compiler separation
- Hard Constraint layer for coordinates/ruler/template/text/clipping
- Partial LKG for accepted regions
- failure isolation: image call FAIL does not stop unrelated workflow
- resident generic three-view character sheet template

## Changed
- direct reference binding is mandatory when canon exists and the current mode needs canon, but is not a prerequisite for creating a brand-new rough character
- CANON_ASSET forbids whole-template redraw as the default route
- exact geometry is not considered satisfied by prompt wording alone
- sheet text/layout should be deterministic when exactness matters

## Preserved
- v012 direct image binding hardening
- expression source separation
- visible part locks
- review/approval/tool-call preflight interlock
- post-fail no-blind-reroll rule
- `000_IC.zip` read-only generation boundary


## Candidate package revision v002
- added dedicated project canon asset shelf interface: `012_CA_v001.zip`
- accepted heavy three-view/character-base assets route to `012_CA`, not `000_IC` by default
- added linked text-canon registry model with locator + hash validation
- reference binding now prefers accepted `012_CA` visual canon before `000_IC` supporting imagery


## candidate v003 / 2026-09-23
- image semantic band normalized to 01x
- 000_IC restored to control-only role
- added 011_G local image gate
- moved reusable canon shelf from 000_CA to 012_CA
- reserved 019_* for temporary event/special/collab source packs
- final/event/one-off artwork excluded from permanent mount by default
- loose root README packaging dependency removed


## v004 mount-shape correction
- 000_IC control shelf now uses C-style ZIP-root contents, not an inner `000_IC/` wrapper.
- helper residents live at root paths `IMT00/`, `SP00/`, `MT00_BOOTSTRAP_EA/`.
- control state path normalized to `000_IC/02_CONTROL_STATE`.
- removed legacy assumptions that visual assets live inside 000_IC; reusable canon belongs to 012_CA and task overrides to 019_* / explicit references.


## v005 manifest sync / zero-start alignment
- synchronized runtime identity to candidate v005
- regenerated stale manifest entries found in v004
- added explicit ZERO_START contract for `000_IC + 011_G_v000 + 012_CA_v000`
- zero-start keeps `019_*` absent until task-bound input exists
- no change to the four-mode creative routing or parallel-root policy
