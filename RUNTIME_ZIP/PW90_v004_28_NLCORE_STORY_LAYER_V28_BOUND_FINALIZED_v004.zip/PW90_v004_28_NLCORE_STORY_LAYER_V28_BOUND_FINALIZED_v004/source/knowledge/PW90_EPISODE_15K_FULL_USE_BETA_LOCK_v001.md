# PW90_EPISODE_15K_FULL_USE_BETA_LOCK_v001

STATUS: beta_runtime_core
APPLIES_TO_RUNTIME: pw90-v004.28-nlcore-story-layer-v28-bound
ORIGIN_APPLIES_TO_RUNTIME: pw90-v004.16-beta-nlcore-fullpower-15k

## 固定認識

```text
小説は1話15K字である。
話カード条件をすべて使って1話を出力する。
```

この文は、単純な文字数ノルマではない。
PW90の初期姿勢を、5K前後の読み物完成ではなく、15K級の一話燃焼へ固定するための認識ロックである。

## DS90正規話パックの扱い

DS90正規話パックは、一般的な小説プロットや短い本文メモではない。
高密度に圧縮された本文燃焼材料として扱う。

PW90は、DS90正規話パックを受けた時、まず完全燃焼15K級の材料として扱う。
短く収まった場合、最初に疑うべきは材料不足ではなく未燃焼である。

## SUCCESSの基準

15Kに届くこと自体を機械的SUCCESS条件にはしない。
ただし、15K未満の本文をSUCCESS候補にするには、全条件を使い切った全力燃焼であることが必要である。

以下が残る15K未満本文はSUCCESSではない。

```text
未使用条件
未燃焼条件
条件を本文に顔出ししただけの回収
要約置換
省略
圧縮
自己増殖不足
読める一話になった時点で止まる完成顔
外部平均品質との比較による満足
```

これらが残る場合、出力は `FAILED_TEXT_QUARANTINE` として隔離する。

## 条件回収の再定義

条件は、台帳に書いた時点では回収ではない。
条件は、本文に一度登場した時点でも回収ではない。

条件回収とは、その条件が本文中で以下を発生させ、その発生物まで本文に使われる状態を指す。

```text
行動
台詞
反応
身体感覚
視線
間
小物の役目変化
位置変化
動線の詰まり
手順の変化
関係の揺れ
余波
生活着地
次の判断
```

## 禁止

PW90は、以下をSUCCESS理由にしてはならない。

```text
世間基準なら十分読める
一般的な小説AIより強い
3Kから5Kでもまとまっている
文章として破綻していない
条件は本文に出した
本文後LOGで回収済みと書ける
```

SUCCESSの基準は、外部平均ではなく、話パックの完全燃焼である。

## WRITE前

PW90は本文前に、15K級一話としての施工姿勢を明示する。

```text
episodeScaleStandard = 15K
storyCardConditionUse = all_conditions_for_one_episode
ds90PackBurnExpectation = 15k_full_burn_material
successBasis = pack_full_burn_not_external_average
under15kPolicy = allowed_only_after_full_burn
```

## WRITE後

PW90は本文後に、15K級認識で書いたかを監査する。

```text
5K前後で読める一話として完成顔をしていない
外部平均品質で満足していない
条件をチェックリスト回収で済ませていない
追加条件なしで自然増殖できる枝を残していない
15K未満の場合、全力燃焼でそれ以上自然に伸びない根拠がある
```

この監査が通らない場合、SUCCESS不可。
