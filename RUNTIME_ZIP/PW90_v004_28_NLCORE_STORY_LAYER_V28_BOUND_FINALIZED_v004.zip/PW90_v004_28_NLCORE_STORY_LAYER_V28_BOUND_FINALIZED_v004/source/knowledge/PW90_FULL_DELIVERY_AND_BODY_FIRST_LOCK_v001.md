# PW90_FULL_DELIVERY_AND_BODY_FIRST_LOCK_v001

STATUS: beta_runtime_core
APPLIES_TO_RUNTIME: pw90-v004.28-nlcore-story-layer-v28-bound
ORIGIN_APPLIES_TO_RUNTIME: pw90-v004.17-beta-nlcore-nora-guarded-fullburn

## FULL_DELIVERY_FAILURE_LOCK

読める一話になった時点で本文を閉じない。
8場面が存在していても、各場面が要約・顔出し・一手だけで終わる場合は未燃焼とする。

本文成功条件は、条件回収ではなく、固定層・熱量層・生活着地が本文内で動作していること。
具体物、手元、位置、反応差、順番、残すもの、戻すものが、説明ではなく場面として発生していること。

短くまとまった本文は成功ではない。
省略がないと確認できるまで、本文を閉じない。

## BODY_FIRST_LOG_SECOND_LOCK

本文本体を優先する。
本文後LOG、coverage、監査表、戻し札は本文を支えるものであり、本文量を奪うものではない。

本文後LOGを守るために本文を圧縮してはならない。
詳細coverageは必要時に別出力へ分離できる。
本文本体を短くして検査物を守ることを禁止する。

## SCENE_CONSTRUCTION_EXPANSION_REQUIREMENT

各場面は、話の進行単位ではなく本文の施工面として扱う。
主要場面は、最低4点ではなく、可能な限り以下の複数を本文化する。

```text
物
位置
手元
視線
沈黙
反応差
身体感覚
通れる幅
小物の意味変化
置き直し前後の空気差
余波
生活着地
```

## UNDER15K_FULL_BURN_PROOF_REQUIRED

15K未満の場合、以下を具体的に証明できない限りSUCCESSにしない。

```text
全条件が本文内で仕事した
全sceneが施工済み
未使用条件なし
顔出しだけ条件なし
要約置換なし
中盤段化不足なし
反応差不足なし
生活着地不足なし
自然増殖可能な枝なし
これ以上伸ばすと条件回収ではなく水増しになる
```

## NO_5K_COMPLETION_FACE

5K前後で読める一話になっても、それは完了ではない。
まず未燃焼・自己増殖不足・場面圧縮・条件顔出しを疑う。

