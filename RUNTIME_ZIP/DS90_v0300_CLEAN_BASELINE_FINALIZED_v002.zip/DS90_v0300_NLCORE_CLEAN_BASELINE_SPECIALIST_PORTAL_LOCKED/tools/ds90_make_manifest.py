#!/usr/bin/env python3
"""Regenerate DS90 updated_manifest.json file records.

Preserves existing metadata where possible and recalculates files, count, sizes, and sha256.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

EXCLUDE = {"updated_manifest.json"}


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def build_records(root: Path) -> list[dict]:
    records = []
    for file in sorted(p for p in root.rglob("*") if p.is_file()):
        rel = file.relative_to(root).as_posix()
        if rel in EXCLUDE:
            continue
        records.append({"path": rel, "sha256": sha256_file(file), "size": file.stat().st_size})
    return records


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("root", type=Path)
    parser.add_argument("--write", action="store_true")
    args = parser.parse_args()
    root = args.root
    manifest_path = root / "updated_manifest.json"
    metadata = {}
    if manifest_path.exists():
        metadata = json.loads(manifest_path.read_text(encoding="utf-8"))
    records = build_records(root)
    metadata.update({
        "runtime": "DS90_v0300_NLCORE_CLEAN_BASELINE_SPECIALIST_PORTAL_LOCKED",
        "version": "v0300-clean-baseline-specialist-portal",
        "status": "ACTIVE_CLEAN_BASELINE",
        "source_cutover_from": "DS90_v0210_SPECIALIST_PORTAL_FLOW_FINALIZED_v001.zip",
        "source_zip_sha256": "ddc548ae3b81eedfb582ac122979fd2369e4c8fe2c4ffef69524d306a145244e",
        "patch_base": "DS90_v0210_SPECIALIST_PORTAL_FLOW_FINALIZED_v001.zip",
        "updated_at": datetime.now(timezone.utc).isoformat(),
        "file_count_excluding_updated_manifest": len(records),
        "files": records,
        "tooling_boundary_policy": {
            "pythonized_scope": "mechanical_inspection_and_packaging_only",
            "markdown_scope": "runtime_law_role_boundary_stop_and_intent",
            "json_scope": "machine_readable_lists_and_contracts",
            "non_goal": "no_direct_context_meter_no_story_quality_scoring_no_mt00_sp00_pw90_ts90_replacement"
        }
    })
    text = json.dumps(metadata, ensure_ascii=False, indent=2) + "\n"
    if args.write:
        manifest_path.write_text(text, encoding="utf-8")
    else:
        print(text)
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
