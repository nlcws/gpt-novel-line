export { execute } from "./src/engine.js";
export { route } from "./src/router.js";
export { READ_ORDER, MODULES, runModule } from "./src/runtime/program.js";
export { ASSET_REGISTRY, ASSET_POLICY } from "./src/assets.js";
export {
  OPERATION_READS,
  OPTIONAL_REFERENCE_ROUTES,
  requiredReads,
  validateOperationReads
} from "./src/loading/manifest.js";
export { narrationBaseProfile, narrationBaseDeny } from "./src/profiles/narrationBase.js";
export {
  singleEpisodeProfileGate,
  validateRowAlignment
} from "./src/profiles/singleEpisodeProfileGate.js";

/*
DS90 v0300 CLEAN BASELINE INSTRUCTION

Read this file first, then follow READ_ORDER and ALWAYS_READ.

Current clean-baseline law:
- assets/dsgn_infra/04_MODULE/common/DS90_V0300_CLEAN_BASELINE_LOCK.md
- assets/dsgn_infra/04_MODULE/common/machine/DS90_V0300_CLEAN_BASELINE_MACHINE.json

Core duties:
- Use requiredReads(operation) and read every returned file before the operation.
- Do not treat included files as used unless the route and validation prove use.
- Do not claim npm/Python/CRC/sha256 results without execution evidence.
- Do not turn runtime into project identity.

Specialist defaults:
- MOUNT_TRANSFER / chat crossing -> MT00 / Nul / ヌル.
- STORY_PACK_CUTOUT -> SP00 / Nal / ナル.
- WRITING from writer-ready story pack -> PW90 / 執筆さん usage guidance.
- REVISION of existing body text -> TS90 / 修正刃さま usage guidance.

MT00/SP00:
- Ask ownership first.
- If missing, guide to public portal/archive.
- If owned or obtained, direct specialist invocation and stop DS90 from holding the specialist work.
- Do not require MT00_HANDOFF_SEED or SP00_HANDOFF_SEED.

DS90 fallback:
- Minimum internal MOUNT_TRANSFER/PACK_CUTOUT is exception-only.
- If used, state it is not MT00/SP00 specialist-complete.

Context safety:
- DS90 cannot measure exact remaining context capacity.
- Watch visible risk signals and prompt transfer before safe transfer becomes difficult.
- Do not bake project-specific rally thresholds into common DS90.

Tooling boundary:
- Python may mechanically inspect, hash, verify manifests, generate CHECK_REPORT, and build DS90 runtime ZIPs.
- Python does not replace DS90 judgment, MT00, SP00, PW90, TS90, canon adoption, or story quality checks.
*/
