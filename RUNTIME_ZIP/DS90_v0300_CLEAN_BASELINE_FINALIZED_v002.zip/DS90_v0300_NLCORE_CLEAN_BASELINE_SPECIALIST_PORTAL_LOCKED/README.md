# DS90 v0300 NLCORE Clean Baseline Specialist Portal Locked

STATUS: ACTIVE_CLEAN_BASELINE
ENTRY: `START_HERE.js`
VERSION: `v0300`

This package is the clean DS90 baseline after the v0201-v0210 specialist/tooling repair chain.
The incremental repair files are not active law in this ZIP.

## Active boundary

- DS90 is the designer runtime.
- DS90 keeps minimum MOUNT_TRANSFER and PACK_CUTOUT routes for detection, boundary protection, and exception-only fallback.
- MT00 / Nul / ヌル is the default specialist for mount transfer and chat crossing.
- SP00 / Nal / ナル is the default specialist for story-pack cutout.
- PW90 / 執筆さん and TS90 / 修正刃さま use light portal-and-usage guidance.
- Git/Codex/Dropbox are optional archive or distribution surfaces, not required execution infrastructure.
- Python supports mechanical inspection/manifest/ZIP/report work only.
- Markdown/TXT holds roles, intention, STOP conditions, and human/AI operating policy.
- JSON holds machine-readable contracts and routing policy.

## Public specialist acquisition

Portal:

```text
https://gpt-novel-line-portal.harmoniets.chatgpt.site/
```

MT00 archive direct link:

```text
https://runtime-public-archive.harmoniets.chatgpt.site/#file-28c7b48c1498749d
```

## Clean baseline rule

Read:

```text
assets/dsgn_infra/04_MODULE/common/DS90_V0300_CLEAN_BASELINE_LOCK.md
assets/dsgn_infra/04_MODULE/common/machine/DS90_V0300_CLEAN_BASELINE_MACHINE.json
```

These are the consolidated active specialist/tooling/portal/context-safety rules.

## Submit rule

If any required read, shelf shape, route, output shape, user intent, stale active path, manifest mismatch, unsafe path, or unresolved STOP remains, STOP.
Do not emit a CONVERGED artifact from filename or self-report alone.

## Retained pack schema invariants

- `WORLD_AXIS_LAYER_BINDING_SCHEMA_v1.json` remains the world-axis binding schema.
- `EPISODE_LAYER_ACTIVATION_SCHEMA_v1.json` remains the episode activation schema.
