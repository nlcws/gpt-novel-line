export const PUBLIC_RUNTIME_SOURCES = Object.freeze({
  portal: "https://gpt-novel-line-portal.harmoniets.chatgpt.site/",
  archiveDirectLink: "https://runtime-public-archive.harmoniets.chatgpt.site/#file-28c7b48c1498749d"
});

export const SPECIALIST_HANDOFFS = Object.freeze({
  MT00: {
    runtime: "MT00 / Nul / ヌル",
    purpose: "MOUNT_TRANSFER",
    ownershipQuestion: "MT00 / ヌルのZIPは手元にありますか？",
    recommendedAction: "If owned or obtained, invoke MT00 / Nul and let Nul perform MOUNT_TRANSFER by default. DS90 does not make MT00_HANDOFF_SEED mandatory.",
    missingRuntimeAction: "If not owned, acquire MT00 from the public portal or archive direct link; then invoke MT00 / Nul.",
    fallbackAction: "DS90 minimum MOUNT_TRANSFER route is exception-only when MT00 is unavailable or the user explicitly commands DS90 to continue without MT00; DS90 must state that it is not MT00-complete.",
    acquisitionLinks: PUBLIC_RUNTIME_SOURCES
  },
  SP00: {
    runtime: "SP00 / Nal / ナル",
    purpose: "STORY_PACK_CUTOUT",
    ownershipQuestion: "SP00 / ナルのZIPは手元にありますか？",
    recommendedAction: "If owned or obtained, invoke SP00 / Nal and let Nal perform STORY_PACK_CUTOUT by default. DS90 does not make SP00_HANDOFF_SEED mandatory.",
    missingRuntimeAction: "If not owned, acquire the runtime from the public portal; then invoke SP00 / Nal.",
    fallbackAction: "DS90 minimum PACK_CUTOUT route is exception-only when SP00 is unavailable or the user explicitly commands DS90 to continue without SP00; DS90 must state that it is not SP00-complete.",
    acquisitionLinks: { portal: PUBLIC_RUNTIME_SOURCES.portal }
  },
  PW90: {
    runtime: "PW90 / 執筆さん",
    purpose: "WRITING",
    guidanceMode: "LIGHT_PORTAL_AND_USAGE_GUIDANCE",
    ownershipQuestion: null,
    recommendedAction: "Use the public portal route and explain how to start PW90 with a writer-ready story pack. DS90 does not need the heavy MT00/SP00 ownership flow for PW90.",
    missingRuntimeAction: "Guide the user to the public portal and explain that PW90 uses writer-ready story pack input.",
    fallbackAction: "DS90 may explain usage, but must not claim to replace PW90 as a full writing runtime.",
    acquisitionLinks: { portal: PUBLIC_RUNTIME_SOURCES.portal }
  },
  TS90: {
    runtime: "TS90 / 修正刃さま",
    purpose: "REVISION",
    guidanceMode: "LIGHT_PORTAL_AND_USAGE_GUIDANCE",
    ownershipQuestion: null,
    recommendedAction: "Use the public portal route and explain how to start TS90 with target body text and bounded revision instructions. DS90 does not need the heavy MT00/SP00 ownership flow for TS90.",
    missingRuntimeAction: "Guide the user to the public portal and explain that TS90 uses target body text plus revision instructions.",
    fallbackAction: "DS90 may explain usage, but must not claim to replace TS90 as a full revision runtime.",
    acquisitionLinks: { portal: PUBLIC_RUNTIME_SOURCES.portal }
  }
});

function normalize(value) {
  return String(value ?? "").toLowerCase();
}

function detectTarget(input) {
  const explicit = String(input?.payload?.specialistTarget ?? input?.specialistTarget ?? "").toUpperCase();
  if (SPECIALIST_HANDOFFS[explicit]) return explicit;
  const text = normalize(`${input?.command ?? ""} ${input?.payload?.intent ?? ""}`);
  if (text.includes("ts90") || text.includes("修正刃") || text.includes("本文修正") || text.includes("修正")) return "TS90";
  if (text.includes("pw90") || text.includes("執筆さん") || text.includes("本文出力") || text.includes("本文を書") || text.includes("本文生成")) return "PW90";
  if (text.includes("sp00") || text.includes("ナル") || text.includes("話パック")) return "SP00";
  if (text.includes("mt00") || text.includes("ヌル") || text.includes("移管") || text.includes("チャットを跨")) return "MT00";
  return "UNKNOWN";
}

function ownershipState(input) {
  const owned = input?.payload?.runtimeOwned ?? input?.runtimeOwned;
  if (owned === true) return "OWNED_OR_AVAILABLE";
  if (owned === false) return "MISSING_RUNTIME";
  return "CHECK_RUNTIME_OWNERSHIP";
}

function ds90MinimumExceptionRequested(input) {
  return input?.payload?.forceDs90MinimumRoute === true || input?.forceDs90MinimumRoute === true;
}

function isDefaultComplianceTarget(target) {
  return target === "MT00" || target === "SP00";
}

function isLightPortalGuidanceTarget(target) {
  return target === "PW90" || target === "TS90";
}

export const specialistHandoffModule = Object.freeze({
  id: "SPECIALIST_HANDOFF",
  loadWhen: ["GPT内専門ランタイム動線", "執筆さん投入", "修正刃さま投入"],
  rules: [],
  validate(input) {
    const target = detectTarget(input);
    if (target === "UNKNOWN") {
      return {
        issues: [{
          code: "SPECIALIST_TARGET_REQUIRED",
          severity: "STOP",
          path: "payload.specialistTarget",
          message: "MT00/SP00/PW90/TS90のいずれかの専門ランタイム対象を指定してください"
        }]
      };
    }
    const state = ownershipState(input);
    const exceptionRequested = ds90MinimumExceptionRequested(input);
    const handoff = SPECIALIST_HANDOFFS[target];
    let nextAction = "ASK_USER_IF_RUNTIME_ZIP_IS_OWNED_OR_AVAILABLE";
    if (isLightPortalGuidanceTarget(target)) {
      nextAction = state === "OWNED_OR_AVAILABLE"
        ? "EXPLAIN_SPECIALIST_USAGE_WITH_OWNED_RUNTIME"
        : "EXPLAIN_PORTAL_AND_USAGE_PATH";
    } else {
      if (state === "MISSING_RUNTIME") nextAction = "DIRECT_USER_TO_PUBLIC_RUNTIME_SHELF";
      if (state === "OWNED_OR_AVAILABLE" && isDefaultComplianceTarget(target) && exceptionRequested) {
        nextAction = "DS90_MINIMUM_EXCEPTION_ROUTE_WITH_LIMITATION_NOTICE";
      } else if (state === "OWNED_OR_AVAILABLE") {
        nextAction = "INVOKE_SPECIALIST_RUNTIME_AND_STOP_DS90_HOLDING_WORK";
      }
    }
    return {
      issues: [],
      output: {
        target,
        handoff,
        runtimeOwnershipState: state,
        specialistDefaultCompliance: isDefaultComplianceTarget(target),
        lightPortalGuidanceOnly: isLightPortalGuidanceTarget(target),
        ds90MinimumExceptionRequested: exceptionRequested,
        ownershipCheckRequired: !isLightPortalGuidanceTarget(target),
        publicRuntimeSources: PUBLIC_RUNTIME_SOURCES,
        nextAction,
        flowVersion: "v0300",
        noGitRequired: true,
        chatgptProjectPath: true,
        sourceThreadHandoffSeedRequired: false,
        mandatoryHandoffSeed: false,
        ds90MustNotForceSeed: true,
        ds90MayOfferOptionalPreparationHelp: true,
        ds90MayExplainPw90Ts90UsageInOneThread: isLightPortalGuidanceTarget(target),
        ds90DoesNotAskNormalNulNalDeclineChoice: true,
        ds90MustStateFallbackIsNotSpecialistComplete: nextAction === "DS90_MINIMUM_EXCEPTION_ROUTE_WITH_LIMITATION_NOTICE",
        ds90DoesNotSubstituteSpecialistRuntime: true
      }
    };
  }
});
