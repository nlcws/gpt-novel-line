# DS90 v0300 Load Order

## Always

1. Read `START_HERE.js`.
2. Follow exported `READ_ORDER` from `src/runtime/program.js`.
3. Read every path in `ALWAYS_READ` from `src/boot/validator.js`.
4. For the selected operation, read every path returned by `requiredReads(operation)`.
5. Run the routed module only after all required reads resolve.
6. Finish through `src/modules/endLog.js`. END_LOG is a location snapshot, never canon.

## Clean baseline active rule

Read these as the active consolidated specialist/tooling/portal/context-safety rule:

- `assets/dsgn_infra/04_MODULE/common/DS90_V0300_CLEAN_BASELINE_LOCK.md`
- `assets/dsgn_infra/04_MODULE/common/machine/DS90_V0300_CLEAN_BASELINE_MACHINE.json`
- `assets/dsgn_infra/04_MODULE/common/machine/DS90_CHECK_REPORT_SCHEMA_v0300.json`
- `assets/dsgn_infra/04_MODULE/common/machine/DS90_ZIP_PACKAGING_CONTRACT_v0300.json`

The v0201-v0210 patch-chain files are not active read law in this clean baseline.

## Specialist routes

```text
MOUNT_TRANSFER / chat crossing -> MT00 / Nul / ヌル
STORY_PACK_CUTOUT              -> SP00 / Nal / ナル
WRITING                         -> PW90 / 執筆さん light portal guidance
REVISION                        -> TS90 / 修正刃さま light portal guidance
```

MT00 and SP00 are default specialist-compliance routes. DS90 internal minimum routes are exception-only and must be labeled as not specialist-complete.

PW90 and TS90 need only portal and usage guidance inside DS90.

## Portal links

```text
https://gpt-novel-line-portal.harmoniets.chatgpt.site/
https://runtime-public-archive.harmoniets.chatgpt.site/#file-28c7b48c1498749d
```

## Operation reads

Use `requiredReads(operation)` as the machine source of truth. Do not rely on this prose list to infer a complete read set.

## Archive boundary

History, reference logs, comparison fixtures, and source-floor material are inactive unless an explicit optional route calls for them. Their presence alone is not active-route input.

## Retained base invariants

The clean baseline still reads retained base invariants when routed:

- `assets/dsgn_infra/04_MODULE/common/NOVEL_LINE_FINAL_CORE_LOCK_v001.md`
- `assets/dsgn_infra/04_MODULE/common/DS90_PW90_ARTIFACT_HANDOFF_JOINT_LOCK_v001.md`

## Pack Cutout retained path markers

- `assets/dsgn_infra/04_MODULE/packager/pack_cutout_module_v1.md`
- `assets/dsgn_infra/04_MODULE/packager/PACKAGER_CURRENT_ROUTE_V2_v0194.md`
- `assets/dsgn_infra/03_REFERENCE/layer/layer_alias_to_current_keys_v0194.md`

Active assembly order remains ready / V2 / world_axis_layer_binding / episode_layer_activation / layer / crosscheck / frozen / execution queue / sources.
