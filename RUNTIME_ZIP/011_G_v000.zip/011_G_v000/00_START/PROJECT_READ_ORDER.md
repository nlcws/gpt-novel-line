# IMAGE PROJECT READ ORDER / ZERO START

```text
000_IC  ZERO_START_READY control
  -> 011_G_v000  project-neutral local image gate
  -> 012_CA_v000 empty reusable canon shelf
  -> grounded project/user source input
  -> linked 02x text canon only after a real locator exists
  -> 019_* only when explicitly supplied for a task
```

New characters without canon route through ROUGH -> CANONIZATION.
