# START_HERE / 011_G v000 ZERO START

`011_G_v000` is a project-neutral image semantic gate. It is not the IM80 control shelf.

Read order:
1. `000_IC` zero-start control state
2. `00_START/PROJECT_READ_ORDER.md`
3. `10_GATE/IMAGE_SHELF_GATE.json`
4. `012_CA_v000` empty canon shelf
5. grounded project/user sources when supplied
6. `019_*` only when explicitly supplied and task-bound

Missing project-specific canon is normal in ZERO START. Do not invent it.
