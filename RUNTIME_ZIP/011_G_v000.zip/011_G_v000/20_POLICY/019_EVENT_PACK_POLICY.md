# 019 EVENT PACK POLICY / ZERO START

- Do not create an empty `019_*` shelf.
- `019_作品_イベント_日付_版` exists only when the user supplies a real temporary event/special/collab image source pack.
- It overrides only its declared task scope and never silently replaces identity/body/base canon.
- Remove it from the active mount when the task ends unless the user explicitly keeps it mounted.
