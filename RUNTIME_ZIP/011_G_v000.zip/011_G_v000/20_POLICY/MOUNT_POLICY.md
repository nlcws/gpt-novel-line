# MOUNT POLICY / ZERO START

Persistent image-side zero-start mount:
- `000_IC.zip`
- `011_G_v000.zip`
- `012_CA_v000.zip`

Do not pre-create 013-018 or 019.
DS90/000_C and BL90/000_BC remain external peer roots.
Finished illustrations are external deliverables, not semantic shelves.
