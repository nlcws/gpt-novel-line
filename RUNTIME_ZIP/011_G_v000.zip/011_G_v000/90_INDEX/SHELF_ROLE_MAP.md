# SHELF ROLE MAP / ZERO START

- `000_IC` = IM80 control/state/resident helpers
- `011_G` = image local gate/index/policy
- `012_CA` = reusable accepted visual canon; empty is valid before canonization
- `019_*` = optional temporary image task/event source pack
- `02x` = external text semantic band when linked by grounded project data
