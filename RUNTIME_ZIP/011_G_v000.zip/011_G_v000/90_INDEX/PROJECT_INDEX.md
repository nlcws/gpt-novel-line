# PROJECT INDEX / ZERO START

Project: UNBOUND
Status: WAIT_FOR_PROJECT_INPUT
Control: `000_IC`
Image gate: `011_G_v000`
Reusable canon: `012_CA_v000` (EMPTY)
Temporary pack: none
