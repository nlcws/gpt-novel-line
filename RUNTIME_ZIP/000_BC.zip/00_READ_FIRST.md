# 000_BC / BL90 ZERO START CONTROL

STATUS: CANDIDATE / ZERO_START_READY / BL90_v004
PURPOSE: Business control shelf for BL90 Projects.

Resident: BL90 / 司書さん, MT00 / ヌル. Ordinary business data remains outside 000_BC.
