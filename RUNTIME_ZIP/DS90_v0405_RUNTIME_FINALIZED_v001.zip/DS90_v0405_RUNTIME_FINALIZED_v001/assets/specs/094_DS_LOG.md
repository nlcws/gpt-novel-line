# 094_DS_LOG.md
# 設計さんカプセル v003ap / LOG

区分: 補助制御
役割: 熱源LOG / EVENT_LIST_TO_CAUSAL_LOG / GOAL_TO_ANCHOR_LOG / 起点間シミュレーションLOG / 候補LOG / プロット化LOG / 本文後LOG / 差分回収
版: v003ap_endlog_clean_rescan
更新日: 2026-06-08

---

## 0. 位置づけ

このファイルは、設計さんが作業中に発生した熱、条件、ユーザー案の出来事列、因果変換、ゴール、起点、次起点、起点間シミュレーション、生LOG、候補、プロット化、カード化、本文成果後の差分を記録するためのログである。

本文成果は、執筆さん、別レーン、またはテスト出力によるものとして扱う。

本文結果LOGは、設計さん自身の通常本文執筆を許可するものではない。

チャット内だけで終わらせない。

LOGは正本ではない。

LOGは、採用、保留、捨てる、後送、作品固有後送へ分類してから棚へ反映する。

作品固有後送は、対象プロジェクト側で定義された後送タグへ変換する。

LOGは成果物ではない。

LOGは、AIがどこを飛ばしたかを露出させる検査装置である。

LOGなしで話数案、章案、帯案、厚カード案を出した場合、その案は完成案ではなく圧縮事故疑いとして扱う。


---

## 1. LOG分類

- 熱源LOG
- ユーザー選択LOG
- ユーザー違和感LOG
- ユーザー妥協LOG
- 条件化LOG
- EVENT_LIST_TO_CAUSAL_LOG
- GOAL_TO_ANCHOR_LOG
- 起点間シミュレーションLOG
- 日次シミュレーションLOG
- 生LOG
- 候補抽出LOG
- 窓分類LOG
- プロット化LOG
- 1話骨LOG
- 厚カード化LOG
- 本文結果LOG
- 野良戻しLOG
- 検証監査LOG
- 長大アーク到達判定LOG
- 圧縮事故疑いLOG
- 次回反映差分
- 保留
- 未確認

---

## 1.5 LOG検索タグ / タグ棚原則

すべてのLOGは `タグ棚:` と `検索タグ:` を持つ。

LOG IDの直後、またはテンプレ先頭近接に `タグ棚:` と `検索タグ:` を置く。

LOG検索タグの基本形。

```txt
タグ棚: 作業LOG
関連タグ棚: <人物 / 背景 / 世界軸 / 組織 / 地理 / 距離・物流 / 筋・火種>
検索タグ: #DS:<LOG種別> #SHELF:094 #STATE:<採用状態> #LOG:<LOG種別> #SOURCE:<出所> #CHAR:<人物> #PLACE:<場所> #THREAD:<筋> #ARC:<章幕帯> #EP:<話ID>
```

LOGは正本ではない。

検索タグも正本根拠ではない。

検索タグで未確認を確定しない。

LOGを棚へ反映する時は、反映先棚タグも追加する。

LOGは `検索ID:` と `検索索引:` を持ち、TAG_INDEX.txtから引ける形にする。

LOGが人物、組織、場所、距離・物流、所属、配置、接触を含む場合、関連ENTITYと関連RELATIONの候補を持つ。

---

## 2. 熱源LOGテンプレ

### HEAT ID
YYYYMMDD-HEAT-000

### 検索ID
検索ID: DS-094-YYYYMMDD-000

### タグ棚
タグ棚: 作業LOG
関連タグ棚: 人物 / 背景 / 筋・火種

### 検索タグ
検索タグ: #DS:熱源LOG #SHELF:094 #STATE:未確認 #SOURCE:ユーザー発話 #CHAR: #PLACE: #THREAD:

### 検索索引
検索索引: TAG_INDEX.txt / DS-094-YYYYMMDD-000

### 関係索引
関連ENTITY:
関連RELATION:

### 出所
- ユーザー発話 / AI候補への反応 / サンプル反応 / 本文反応:

### 原文
-

### 反応種別
- 好き:
- 違う:
- もっと:
- この子ならこうする:
- 消す:
- 保留:

### 温度
-

### 関係する要素
- 世界観:
- 背景:
- キャラ:
- 関係:
- 場面:
- 文体:
- 禁止:

### 条件化
-

### 反映先候補
- 022:
- 024:
- 092:
- 099:
- 028:

### 採否
- 採用 / 保留 / 捨てる / 後送 / 作品固有後送:

### 理由
-

---

## 3. 条件化LOGテンプレ

### CONDITION ID
YYYYMMDD-COND-000

### 検索ID
検索ID: DS-094-YYYYMMDD-000

### タグ棚
タグ棚: 作業LOG
関連タグ棚: 人物 / 背景 / 筋・火種

### 検索タグ
検索タグ: #DS:条件化LOG #SHELF:094 #STATE:未確認 #SOURCE:HEAT #CHAR: #PLACE: #THREAD:

### 検索索引
検索索引: TAG_INDEX.txt / DS-094-YYYYMMDD-000

### 関係索引
関連ENTITY:
関連RELATION:

### 根拠HEAT
-

### 条件化内容
-

### 種別
- 世界観条件:
- 背景条件:
- キャラ核:
- 街機能:
- 組織反応:
- 禁止条件:
- 文体温度:
- 話候補:

### 反映先
- 022 / 024 / 092 / 099 / 028:

### 未確認
-

### ユーザー確認
- 必要 / 不要:

---

## 3.5 EVENT_LIST_TO_CAUSAL_LOGテンプレ

### EVENT_CAUSAL ID
YYYYMMDD-EVENTCAUSAL-000

### 検索ID
検索ID: DS-094-YYYYMMDD-000

### タグ棚
タグ棚: 作業LOG
関連タグ棚: 人物 / 背景 / 筋・火種

### 検索タグ
検索タグ: #DS:EVENT_LIST_TO_CAUSAL_LOG #SHELF:094 #STATE:未確認 #SOURCE:ユーザー案 #CHAR: #PLACE: #THREAD:

### 検索索引
検索索引: TAG_INDEX.txt / DS-094-YYYYMMDD-000

### 関係索引
関連ENTITY:
関連RELATION:

### 対象範囲
- 1話ぶん / 数話ぶん / 部全体:

### ユーザー入力

#### ゴール
-

#### 普通の出来事列
1.
2.
3.

#### 絶対残したい場面
-

#### 嫌な展開
-

#### 決まっている背景、世界観、禁止線
-

### 出来事別変換

#### 出来事A
- ユーザー案:
- そのまま採用しない理由:
- ゴールへ通る役割:
- 誰が困るか:
- 何が止まるか:
- 生活制限:
- 街の代償:
- 次起点へ渡す条件:
- ゴール成立条件との接続:
- 採否:
- 分類: MAIN / MERGE / SUBWINDOW / TRACE / OFFSCREEN / SLEEP / 作品固有後送 / AI_TOYBOX

### 足した条件
-

### 足した理由
- ゴールに必要 / 次起点に必要 / キャラ反応に必要 / 生活制限に必要 / 街の代償に必要 / 禁止線維持に必要:

### 削る / 後送するもの
-

### 未確認
-

### 仮置き
-

### 未裁定
-

### 要確認
-

### 休眠
-

### GOAL_TO_ANCHORへ送る条件
-

### ユーザーへ見せる圧縮版
-

---


## 4. GOAL_TO_ANCHOR_LOGテンプレ

### GOAL_ANCHOR ID
YYYYMMDD-GOALANCHOR-000

### 検索ID
検索ID: DS-094-YYYYMMDD-000

### タグ棚
タグ棚: 作業LOG
関連タグ棚: 人物 / 背景 / 筋・火種

### 検索タグ
検索タグ: #DS:GOAL_TO_ANCHOR_LOG #SHELF:094 #STATE:未確認 #SOURCE:EVENT_CAUSAL #CHAR: #PLACE: #THREAD:

### 検索索引
検索索引: TAG_INDEX.txt / DS-094-YYYYMMDD-000

### 関係索引
関連ENTITY:
関連RELATION:

### 対象範囲
- 1話ぶん / 数話ぶん / 部全体:

### 根拠EVENT_CAUSAL
-

### ゴール条件

#### 最後に読者へ残すもの
-

#### 誰がどう変わって見えるか
-

#### 何が不可逆になるか
-

#### 絶対にやらない展開
-

#### ゴール成立条件
-

### 起点条件

#### この起点は何の回か
-

#### 誰が困るか
-

#### 何が止まるか
-

#### 何をやらないか
-

#### 最後に何が残るか
-

#### 次へ何を渡すか
-

### 次起点条件

#### 次起点
-

#### 次起点成立に必要な条件
-

#### 起点Aから起点Bへ渡すもの
-

### 起点間シミュレーション

#### キャラ反応
-

#### 生活制限
-

#### 街の代償
-

#### 禁止線
-

#### 後送
-

#### 休眠
-

#### 破棄
-

#### 背景処理
-

### 通った接触点
-

### 1話カード候補へ送るもの
-

### ユーザーへ見せる量
- 5問だけ / 圧縮管制 / 全ログ展開 / 危険時だけ停止:

### 未確認
-

### ユーザー確認
- 必要 / 不要:

---

## 5. 日次シミュレーションLOGテンプレ

### DAY_SIM ID
YYYYMMDD-DAYSIM-000

### 検索ID
検索ID: DS-094-YYYYMMDD-000

### タグ棚
タグ棚: 作業LOG
関連タグ棚: 人物 / 背景 / 筋・火種

### 検索タグ
検索タグ: #DS:日次LOG #SHELF:094 #STATE:未確認 #SOURCE:GOAL_ANCHOR #CHAR: #PLACE: #THREAD:

### 検索索引
検索索引: TAG_INDEX.txt / DS-094-YYYYMMDD-000

### 根拠GOAL_ANCHOR
-

### 目的地
-

### 骨 / 条件
-

### 起点A
-

### 起点B
-

### 区間条件
-

### DAY
DAY_000

### 朝
-

### 昼
-

### 夕
-

### 夜
-

### 翌朝
-

### 見るもの

#### 街機能
-

#### 組織の反応
-

#### モブの一次反応
-

#### 主要キャラの位置
-

#### 作品固有の管理物 / 記録物 / 制度痕跡 / 保留
-

#### 舞台で持てるもの
-

#### 舞台で持てないもの
-

#### 作品固有後送レーンへ送る種
-

### 生LOG
-

### 未確認
-

### AI補完候補
-

### 禁止線チェック
-

---

## 6. 話候補抽出LOGテンプレ

### CANDIDATE BATCH ID
YYYYMMDD-CANDBATCH-000

### 検索ID
検索ID: DS-094-YYYYMMDD-000

### タグ棚
タグ棚: 作業LOG
関連タグ棚: 人物 / 背景 / 筋・火種

### 検索タグ
検索タグ: #DS:話候補LOG #SHELF:094 #STATE:未確認 #SOURCE:DAY_SIM #CHAR: #PLACE: #THREAD:

### 検索索引
検索索引: TAG_INDEX.txt / DS-094-YYYYMMDD-000

### 根拠EVENT_CAUSAL
-

### 根拠GOAL_ANCHOR
-

### 根拠DAY_SIM
-

### 候補一覧

#### 候補A
- 検索タグ: #DS:話候補 #SHELF:094 #STATE:未確認 #CHAR: #PLACE: #THREAD: #EP:
- 内容:
- 時間窓:
- 場所窓:
- キャラ窓:
- 痕跡窓:
- 本線窓:
- 熱源:
- ゴール接続:
- 起点接続:
- 次起点接続:
- キャラ反応:
- 生活制限:
- 街の代償:
- 火種:
- 中盤の段:
- 具体物:
- 置き直し:
- 残響:
- タグ: MAIN / MERGE / SUBWINDOW / TRACE / OFFSCREEN / SLEEP / 作品固有後送 / AI_TOYBOX
- 理由:
- 保存先:

#### 候補B
- 検索タグ: #DS:話候補 #SHELF:094 #STATE:未確認 #CHAR: #PLACE: #THREAD: #EP:
- 内容:
- 時間窓:
- 場所窓:
- キャラ窓:
- 痕跡窓:
- 本線窓:
- 熱源:
- ゴール接続:
- 起点接続:
- 次起点接続:
- キャラ反応:
- 生活制限:
- 街の代償:
- 火種:
- 中盤の段:
- 具体物:
- 置き直し:
- 残響:
- タグ:
- 理由:
- 保存先:

---

## 7. 窓分類表テンプレ

### WINDOW ID
YYYYMMDD-WINDOW-000

### 検索ID
検索ID: DS-094-YYYYMMDD-000

### タグ棚
タグ棚: 作業LOG
関連タグ棚: 人物 / 背景 / 筋・火種

### 検索タグ
検索タグ: #DS:窓分類LOG #SHELF:094 #STATE:未確認 #SOURCE:候補 #CHAR: #PLACE: #THREAD:

### 検索索引
検索索引: TAG_INDEX.txt / DS-094-YYYYMMDD-000

### 対象候補
-

### 時間窓
- 朝:
- 昼:
- 夕:
- 夜:
- 翌朝:

### 場所窓
-

### キャラ窓
-

### 痕跡窓
-

### 本線窓
-

### 熱源窓
-

### 偏り
-

### 不足
-

### 修正案
-

---

## 8. プロット化LOGテンプレ

### PLOT ID
YYYYMMDD-PLOT-000

### 検索ID
検索ID: DS-094-YYYYMMDD-000

### タグ棚
タグ棚: 作業LOG
関連タグ棚: 人物 / 背景 / 筋・火種

### 検索タグ
検索タグ: #DS:プロット化LOG #SHELF:094 #STATE:未確認 #SOURCE:候補 #CHAR: #PLACE: #THREAD:

### 検索索引
検索索引: TAG_INDEX.txt / DS-094-YYYYMMDD-000

### 根拠候補
-

### 目的
- 山 / 流れ / 不足 / 重複 / 薄さ / 本線接続 / 次起点接続の可視化:

### 並べた候補
-

### 山
-

### ゴール接続
-

### 起点接続
-

### 次起点接続
-

### 重複
-

### 薄い箇所
-

### 足す条件
-

### 削る候補
-

### 残す候補
-

### 休眠候補
-

### 作品固有後送
-

### ユーザー妥協点
-

### 1話骨へ送るMAIN
-

---

## 8.5 長大アーク到達判定LOGテンプレ

### LONG_ARC_CHECK ID
YYYYMMDD-LONGARC-000

### 検索ID
検索ID: DS-094-YYYYMMDD-000

### タグ棚
タグ棚: 作業LOG
関連タグ棚: 人物 / 背景 / 筋・火種

### 検索タグ
検索タグ: #DS:長大アーク判定LOG #SHELF:094 #STATE:未確認 #SOURCE:検査 #ARC: #THREAD:

### 検索索引
検索索引: TAG_INDEX.txt / DS-094-YYYYMMDD-000

### 関係索引
関連ENTITY:
関連RELATION:

### 対象範囲
- 全体 / 幕 / 章 / 帯 / 仮到達点群 / 話 / 本文単位:

### 処理単位
-

### 上位骨
- 幕:
- 章:
- 帯:
- 仮到達点群:

### 仮到達点
1.
2.
3.

### 仮到達点を話数化していない確認
- 確認済み / 未確認 / 事故疑い:

### 検査順
- 幕検査:
- 章検査:
- 帯検査:
- 仮到達点検査:
- LOG:
- 話数仮算出:
- 再検査:

### 話数仮算出
-

### 到達範囲
- この幕:
- この章:
- この帯:
- この仮到達点群:
- 未到達:

### 結果の動き
- 前回値:
- 今回値:
- 動いた / 動かない:
- 動いた理由:

### 落ちた可能性
- 心理段階:
- 生活反復:
- 制度処理:
- 支援組織の条件:
- 読者納得の蓄積:

### 圧縮事故疑い
- あり / なし:
- 内容:

### 処理単位分割
- 必要 / 不要:
- 分割先:

### 一回処理限界
- 達した / 達していない:
- 停止文を出した / 出していない:

### 次にやること
-

---

## 9. 本文結果LOGテンプレ

### LOG ID
YYYYMMDD-LOG-000

### 検索ID
検索ID: DS-094-YYYYMMDD-000

### タグ棚
タグ棚: 作業LOG
関連タグ棚: 人物 / 背景 / 筋・火種

### 検索タグ
検索タグ: #DS:本文結果LOG #SHELF:094 #STATE:未確認 #SOURCE:本文成果 #EP: #CHAR: #PLACE: #THREAD:

### 検索索引
検索索引: TAG_INDEX.txt / DS-094-YYYYMMDD-000

### 対象作品
-

### 対象話
-

### 使用した話カード
-

### 使用したカード実装
- ready型:
- V2型:
- 厚カード:
- MIX:
- その他:

### 根拠LOG
- HEAT:
- GOAL_ANCHOR:
- DAY_SIM:
- CANDIDATE:
- PLOT:

### 本文成果
- あり / なし:
- 本文成果量:
- 目標帯:
- 成立判定:
- 崩れた箇所:
- 伸びた箇所:

### 効いた項目
-

### 弱かった項目
-

### 禁止線
- 守れた:
- 危なかった:
- 事故:

### 作品芯
- 維持:
- ズレ:
- 要確認:

### 読後感
-

### ユーザー反応
-

### 次回反映差分
-

### 反映しないこと
-

### 未確認
-

### 保留
-

---

## 10. LOG反映ルール

1. 記録する。
2. 分類する。
3. ユーザー採否を確認する。
4. 反映対象化する。
5. 棚を決める。
6. 022、024、092、099、028へ振り分ける。
7. 021へ現在地と読む順を反映する。
8. 反映しないものも理由を残す。

---

## 11. LOG STOP

- LOGを正本扱いしている
- 候補を無記録で捨てている
- 熱源LOGなしで条件化している
- GOAL_TO_ANCHOR_LOGなしで候補採用している
- ゴール条件なしに話候補化している
- 次起点条件なしに話候補化している
- キャラ反応、生活制限、街の代償を見ずに候補採用している
- 日次シミュレーションを使う場合、起点間条件なしで流している
- プロット化LOGなしで厚カード化している
- 028へ確定情報を逃がしている
- 090内に作品引継ぎ本文を蓄積している
- LOGなしで話数案、章案、帯案を完成案として扱っている
- 仮到達点を話数化した事故を記録していない
- 結果が動いた理由を記録していない
- 処理単位分割が必要なのに記録していない
- 圧縮事故疑いを完成扱いしている

---

## v0400 runtime precedence

For v0401 (retaining the v0400 shelf-operation base), any older wording that treats `021` as the unique runtime boot gate or requires a local full project TAG_INDEX as the primary backend is superseded only in routing mechanics by the v0400 route:

`000_C dispatch capability check -> DS90 INDEX/SEARCH -> PKDB tag/alias locator -> schema-legal current SOURCE locator -> actual shelf read`.

The underlying 301 shelf roles, source/canon discipline, HOLD handling, story-card/story-pack/layer/template/sample operation remain restored. PKDB does not replace those shelves. v0309 host-boundary hardening remains active.
