# END_LOG_OPERATION_RULE.md
# 設計さんカプセル / 文末LOG共通運用

区分: 運用規則
役割: 外部共有面非依存の現在地共有 / 作業位置確認 / 長文化防止
版: v003ap_endlog_clean_rescan
更新日: 2026-06-08

---

## v0400 runtime authority note

`src/runtime/report-policy.js` is the active runtime report formatter. `END_LOG` remains a report/current-position surface only and never decides PASS/STOP, proves reads, or commits state. `src/modules/endLog.js` is retained as compatibility validation material and is not terminal authority.

END_LOGは、返答末尾に置く現在地共有用の最小作業ログである。

END_LOGは、外部共有面に依存しない現在地共有である。

現在地共有はEND_LOGで行う。

END_LOGは正本ではない。

END_LOGはsourceではない。

END_LOGは生ログではない。

END_LOGは引継ぎ本文ではない。

END_LOGはV2カードではない。

END_LOGはPW起点ではない。

END_LOGは読了証明ではない。

END_LOGは採用判定ではない。

END_LOGは移管済み判定ではない。

END_LOGは作品条件源ではない。

END_LOGを読んだことを、source実読の代替にしない。

END_LOGを根拠札にしない。

END_LOGを倉庫にしない。

---

## 形式

END_LOGは最大4行にする。

形式は固定する。

```txt
END_LOG:
現在:
未反映:
次:
注意:
```

---

## END_LOGに書いてよいもの

- BOOT_READY / BOOT_CONNECTED / PROJECT_STOP / FACTORY_STOP の短い現在地
- 読んだものの最小表示
- 未反映、未読、未移管の短い表示
- 次に必要な添付物
- 次にできる作業
- 収納違反、版メタズレ、再開メモなしなどの短い注記
- STOP中の未解決項目の短い表示

---

## END_LOGに書かないもの

- 作品判断の詳細根拠
- 生ログの熱
- 長い議論の要約
- V2カード本体
- PW本文起点
- 細かい台詞案
- source TXTの代替要約
- 確定していない仮説を確定風にしたもの
- 長文正本
- 全文構築文
- 本文原稿
- 差分履歴全文
- 更新履歴全文

---

## 更新するタイミング

- 毎返答末尾
- 起動時
- マウント接続時
- STOPが増えた時
- 次作業が変わった時
- 未反映が出た時
- マウント移管後

---

## 更新しないもの

END_LOGは履歴保存しない。

END_LOGは前回行を積み上げない。

END_LOGは過去版を保持しない。

END_LOGは現在位置だけを短く出す。

---

## 再開メモとの関係

再開メモは任意の補助メモとして扱う。

再開メモは起動条件ではない。
再開メモはEND_LOG本体ではない。
再開メモがある場合、END_LOGへ必要範囲だけ短く転記してよい。
再開メモの長文をEND_LOGへ貼らない。
再開メモがない場合でも起動を止めない。


## 外部共有面との関係

外部共有面が使用不能でも起動を止めない。

外部共有面不可をFACTORY_STOPにしない。

外部共有面不可をPROJECT_STOPにしない。

外部共有面の有無を状態名にしない。

外部共有面を通常運用の保存先、現在地共有面、正本置き場、長文LOG置き場、本文原稿置き場、source要約置き場にしない。

---

## END_LOG STOP

- END_LOGだけで作品判断しない。
- END_LOGだけでV2作成しない。
- END_LOGだけでPWへ降ろさない。
- END_LOGの短い要約を、正本全文の代替にしない。
- 古いEND_LOGを最新状態として扱わない。

---

## 過去レポートとの関係

過去レポートはランタイムZIPから外す。

外部保管された過去レポートを読んだ場合も、旧運用や既存再開メモ運用を現行へ戻さない。

現行の現在地共有はEND_LOGで行う。
