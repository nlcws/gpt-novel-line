# COMPLETE MOUNT OUTPUT LOCK

PASS output root contains nested canonical shelf ZIPs only.

For the current BC contract, `000_BC.zip` is mandatory. The remaining exact set comes from `TRANSFER_STATE.inventory_expected`.

Forbidden PASS outputs:
- `diff.zip`
- `patch.zip`
- `changed_files.zip`
- loose README / report / manifest / handoff files at outer root
- a container missing an unchanged shelf

Unchanged canonical shelf ZIPs must remain byte-identical.
