# INPUT CONTRACT

Required:
1. a current mount ZIP or directory
2. `000_BC.zip`
3. `000_BC/TRANSFER_STATE/TRANSFER_STATE.json` with `inventory_expected`
4. every canonical shelf named in `inventory_expected`
5. explicit disposition for noncanonical root material, if any

Stop when:
- a canonical shelf is missing
- a shelf ZIP or its manifest fails
- a root item is neither canonical nor explicitly disposed
- a locator cannot resolve
- a new shelf is required but not approved
- the requested operation exceeds current authority
