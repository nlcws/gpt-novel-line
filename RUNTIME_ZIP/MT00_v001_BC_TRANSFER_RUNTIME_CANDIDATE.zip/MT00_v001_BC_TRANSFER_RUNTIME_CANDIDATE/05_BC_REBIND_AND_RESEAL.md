# BC REBIND / RESEAL

`000_BC` is the control shelf for BL90-family business projects. MT00 may update it only for transfer / rebind / recovery / reseal work allowed by the authority profile.

During transfer MT00 may update:
- `CURRENT_STATE` transfer-related status only
- `DISPATCH` MT00 availability / binding
- `RESIDENT/MT00` exact runtime and binding
- `TRANSFER_STATE`
- `AUDIT` transfer evidence
- `MANIFEST.json` last

MT00 must not alter business data or template semantics merely to make validation pass.
