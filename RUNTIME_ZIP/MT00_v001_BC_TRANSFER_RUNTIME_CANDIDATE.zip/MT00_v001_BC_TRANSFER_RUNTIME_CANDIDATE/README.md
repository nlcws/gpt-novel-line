# MT00 v001 BC Transfer Runtime (Candidate)

Display name: **ヌル**

Zero-base BC-bound transfer runtime for BL90 / `000_BC` projects.

Core rule: **transfer means a complete mount, never a patch.**
