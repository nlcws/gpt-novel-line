#!/usr/bin/env python3
from pathlib import Path
import subprocess,sys
root=Path(__file__).resolve().parents[1]
r=subprocess.run([sys.executable,str(root/'tools/validate_mt00.py')],capture_output=True,text=True)
if r.returncode or 'PASS_MT00_BC_CORE' not in r.stdout: raise SystemExit('FAIL CORE')
text=(root/'04_COMPLETE_MOUNT_OUTPUT.md').read_text()
for needle in ['diff.zip','patch.zip','changed_files.zip','byte-identical']:
    if needle not in text: raise SystemExit('FAIL OUTPUT_LOCK '+needle)
print('PASS_MT00_BC_TESTS')
