# TARGET VALIDATION

A transfer is not complete merely because a ZIP was built.

Target completion requires:
- complete container present
- every canonical shelf ZIP present
- shelf CRC and manifest PASS
- PKDB locators resolve
- resident MT00 binding resolves
- `000_BC` authority profile remains present
- target-side read/validation actually performed

Until then state is `PACKAGED_READY_FOR_TARGET`, not `TRANSFER_COMPLETE`.
