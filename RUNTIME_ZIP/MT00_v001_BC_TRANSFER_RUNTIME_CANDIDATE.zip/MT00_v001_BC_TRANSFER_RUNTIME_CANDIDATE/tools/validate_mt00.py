#!/usr/bin/env python3
from pathlib import Path
import json,hashlib,zipfile,sys
root=Path(__file__).resolve().parents[1]
man=json.loads((root/'MANIFEST.json').read_text())
actual=[]
for p in sorted(root.rglob('*')):
    if p.is_file() and p.name!='MANIFEST.json':
        rel=p.relative_to(root).as_posix(); b=p.read_bytes(); actual.append(rel)
        row=next((r for r in man['files'] if r['path']==rel),None)
        if not row or row['sha256']!=hashlib.sha256(b).hexdigest() or row['bytes']!=len(b):
            raise SystemExit('FAIL '+rel)
if set(actual)!=set(r['path'] for r in man['files']): raise SystemExit('FAIL CLOSURE')
print('PASS_MT00_BC_CORE')
