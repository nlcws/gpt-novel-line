#!/usr/bin/env python3
from pathlib import Path
import argparse, json, hashlib, zipfile, tempfile, shutil, os, sys
FIXED=(2020,1,1,0,0,0)
RUNTIME_ID='MT00'

def sha(b): return hashlib.sha256(b).hexdigest()
def jd(o): return json.dumps(o,ensure_ascii=False,indent=2,sort_keys=True)+'\n'
def zwrite(z, name, data):
    zi=zipfile.ZipInfo(name,FIXED); zi.compress_type=zipfile.ZIP_DEFLATED; zi.external_attr=(0o100644<<16); z.writestr(zi,data)

def zip_bytes(mapping):
    import io
    bio=io.BytesIO()
    with zipfile.ZipFile(bio,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for n,b in sorted(mapping.items()): zwrite(z,n,b)
    return bio.getvalue()

def read_mount(source):
    p=Path(source)
    items={}
    if p.is_dir():
        for f in p.iterdir():
            if f.is_file(): items[f.name]=f.read_bytes()
    else:
        with zipfile.ZipFile(p) as z:
            for n in z.namelist():
                if '/' not in n.rstrip('/') and not n.endswith('/'):
                    items[n]=z.read(n)
    return items

def read_zip_mapping(b):
    import io
    with zipfile.ZipFile(io.BytesIO(b)) as z:
        return {n:z.read(n) for n in z.namelist() if not n.endswith('/')}

def verify_inner_manifest(zip_name,b):
    import io
    with zipfile.ZipFile(io.BytesIO(b)) as z:
        bad=z.testzip()
        if bad: raise ValueError(f'CRC_FAIL {zip_name} {bad}')
        names=set(n for n in z.namelist() if not n.endswith('/'))
        if 'MANIFEST.json' not in names: raise ValueError(f'MANIFEST_MISSING {zip_name}')
        m=json.loads(z.read('MANIFEST.json'))
        declared=set()
        for r in m.get('files',[]):
            p=r['path']; declared.add(p)
            if p not in names: raise ValueError(f'MANIFEST_TARGET_MISSING {zip_name} {p}')
            bb=z.read(p)
            if sha(bb)!=r['sha256']: raise ValueError(f'HASH_FAIL {zip_name} {p}')
            if 'bytes' in r and len(bb)!=r['bytes']: raise ValueError(f'BYTES_FAIL {zip_name} {p}')
        actual=names-{'MANIFEST.json'}
        if actual!=declared: raise ValueError(f'MANIFEST_CLOSURE_FAIL {zip_name}')

def bc_state_from_bytes(bc_bytes):
    mp=read_zip_mapping(bc_bytes)
    req=['TRANSFER_STATE/TRANSFER_STATE.json','CURRENT_STATE/BC_STATE.json','DISPATCH/DISPATCH.json','AUTHORITY/PROJECT_MAINTENANCE_AUTHORITY_PROFILE_v003.json']
    for r in req:
        if r not in mp: raise ValueError('BC_REQUIRED_MISSING '+r)
    return mp, json.loads(mp['TRANSFER_STATE/TRANSFER_STATE.json'])

def validate_pkdb(items):
    if 'PKDB_VOLUME_0001.zip' not in items: return
    import io
    shelves={}
    for role in ['021_G','022_B','024_V','028_H']:
        zn=role+'.zip'
        if zn in items: shelves[role]=read_zip_mapping(items[zn])
    pk=read_zip_mapping(items['PKDB_VOLUME_0001.zip'])
    if 'records.json' not in pk: raise ValueError('PKDB_RECORDS_MISSING')
    recs=json.loads(pk['records.json']).get('records',[])
    for r in recs:
        loc=r.get('source_locator','')
        parts=loc.split('/')
        if not parts or parts[0] not in shelves: raise ValueError('PKDB_BAD_LOCATOR '+loc)
        rel='/'.join(parts[1:])
        if rel not in shelves[parts[0]]: raise ValueError('PKDB_BROKEN_LOCATOR '+loc)

def manifest_for_mapping(mp, root='000_BC'):
    rows=[]
    for n,b in sorted(mp.items()):
        if n=='MANIFEST.json': continue
        rows.append({'path':n,'bytes':len(b),'sha256':sha(b)})
    return {'schema':'BL90_TEST_SHELF_MANIFEST_v002_MT00','root':root,'files':rows}

def runtime_bytes_from_self():
    # runtime ZIP must be supplied through env or sibling path when executed from extracted runtime
    env=os.environ.get('MT00_RUNTIME_ZIP')
    if env and Path(env).exists(): return Path(env).read_bytes(), Path(env).name
    here=Path(__file__).resolve()
    root=here.parents[1]
    candidate=root.parent/(root.name+'.zip')
    if candidate.exists(): return candidate.read_bytes(), candidate.name
    raise ValueError('MT00_RUNTIME_ZIP_REQUIRED')

def ensure_authority(profile,purpose):
    if purpose not in profile.get('standing_maintenance_keys',{}).get('allowed_purposes',[]):
        raise ValueError('AUTHORITY_PURPOSE_NOT_ALLOWED')
    holders=[h.get('runtime_id') for h in profile['standing_maintenance_keys'].get('holders',[])]
    if RUNTIME_ID not in holders: raise ValueError('MT00_NOT_KEY_HOLDER')

def update_bc(bc_bytes, phase, outer_before_sha=None, target_name=None):
    mp, st = bc_state_from_bytes(bc_bytes)
    profile=json.loads(mp['AUTHORITY/PROJECT_MAINTENANCE_AUTHORITY_PROFILE_v003.json'])
    ensure_authority(profile,'TRANSFER')
    rt_b, rt_name=runtime_bytes_from_self()
    # Remove prior MT00 requirement/binding/runtime entries
    for n in list(mp):
        if n.startswith('RESIDENT/MT00/'):
            del mp[n]
    runtime_path='RESIDENT/MT00/'+rt_name
    mp[runtime_path]=rt_b
    bind={'schema':'MT00_BC_BINDING_v001','runtime_id':'MT00','display_name':'ヌル','runtime_path':runtime_path,'runtime_sha256':sha(rt_b),'control_shelf':'000_BC','binding':'BC_TRANSFER'}
    mp['RESIDENT/MT00/MT00_BINDING.json']=jd(bind).encode()

    bcstate=json.loads(mp['CURRENT_STATE/BC_STATE.json'])
    bcstate.setdefault('resident',{})['MT00']='BUNDLED'
    if phase=='PREPARE': bcstate['status']='TRANSFER_PACKAGED_READY_FOR_TARGET'
    else: bcstate['status']='TRANSFER_COMPLETE'
    mp['CURRENT_STATE/BC_STATE.json']=jd(bcstate).encode()

    dispatch=json.loads(mp['DISPATCH/DISPATCH.json'])
    for r in dispatch.get('routes',[]):
        if r.get('target')=='MT00':
            r['availability']='BUNDLED_READY'
            r['runtime_path']=runtime_path
            r['runtime_sha256']=sha(rt_b)
    mp['DISPATCH/DISPATCH.json']=jd(dispatch).encode()

    if phase=='PREPARE':
        st['state']='PACKAGED_READY_FOR_TARGET'
        st['transfer_packaged']=True
        st['target_validated']=False
        st['transfer_complete']=False
        st['transfer_executed']=True
        st['do_not_claim']=['TARGET_MOUNTED','TRANSFER_COMPLETE']
        st['completed']=[x for x in st.get('completed',[]) if x!='MT00_BC_REBIND']+['MT00_BC_REBIND','COMPLETE_CONTAINER_BUILT','SOURCE_VALIDATED']
        st['completed']=list(dict.fromkeys(st['completed']))
        st['pending']=['TARGET_MOUNT','POST_MOUNT_LOCATOR_VALIDATION','TARGET_COMPLETE_RESEAL']
        st['restart_point']='TARGET_MOUNT_AND_VALIDATE_COMPLETE_CONTAINER'
    else:
        st['state']='TRANSFER_COMPLETE'
        st['transfer_packaged']=True
        st['target_validated']=True
        st['transfer_complete']=True
        st['transfer_executed']=True
        st['do_not_claim']=[]
        st['completed']=list(dict.fromkeys(st.get('completed',[])+['TARGET_MOUNTED','POST_MOUNT_LOCATOR_VALIDATION','TARGET_COMPLETE_RESEAL']))
        st['pending']=[]
        st['restart_point']='BL90_SESSION_ACTIVATION_OR_USER_TASK'
        if target_name: st['target_environment']=target_name
    st['mt00_binding']=bind
    mp['TRANSFER_STATE/TRANSFER_STATE.json']=jd(st).encode()

    audit={'schema':'MT00_BC_TRANSFER_AUDIT_v001','actor':'MT00','display_name':'ヌル','purpose':'TRANSFER','phase':phase,'authority_source':'STANDING_MAINTENANCE_KEY','before_bc_sha256':sha(bc_bytes),'runtime_sha256':sha(rt_b)}
    if outer_before_sha: audit['source_mount_sha256']=outer_before_sha
    if target_name: audit['target_environment']=target_name
    mp[f'AUDIT/MT00_{phase}_AUDIT.json']=jd(audit).encode()
    mp['MANIFEST.json']=jd(manifest_for_mapping(mp)).encode()
    return zip_bytes(mp), st

def validate_complete_container(path_or_bytes):
    import io
    if isinstance(path_or_bytes,(bytes,bytearray)): z=zipfile.ZipFile(io.BytesIO(path_or_bytes))
    else: z=zipfile.ZipFile(path_or_bytes)
    with z:
        bad=z.testzip()
        if bad: raise ValueError('OUTER_CRC_FAIL '+bad)
        names=[n for n in z.namelist() if not n.endswith('/')]
        if any('/' in n for n in names): raise ValueError('OUTER_LOOSE_OR_FOLDER_ENTRY')
        if any(not n.endswith('.zip') for n in names): raise ValueError('OUTER_NON_ZIP_ENTRY')
        items={n:z.read(n) for n in names}
    if '000_BC.zip' not in items: raise ValueError('BC_MISSING')
    mp,st=bc_state_from_bytes(items['000_BC.zip'])
    expected=st.get('inventory_expected',[])
    if sorted(items)!=sorted(expected): raise ValueError('COMPLETE_SET_MISMATCH')
    for n,b in items.items(): verify_inner_manifest(n,b)
    validate_pkdb(items)
    # resident binding exact
    bind=json.loads(mp['RESIDENT/MT00/MT00_BINDING.json'])
    rp=bind['runtime_path']
    if rp not in mp or sha(mp[rp])!=bind['runtime_sha256']: raise ValueError('MT00_BINDING_FAIL')
    return items,st

def check_root_disposition(source_items, st):
    expected=set(st.get('inventory_expected',[]))
    disp=st.get('root_disposition',{})
    for n in source_items:
        if n in expected: continue
        if n not in disp: raise ValueError('UNCLASSIFIED_ROOT_ITEM '+n)
        if disp[n] not in ['REFLECTED_IN_BC','DISCARDED_TEST_HARNESS','DISCARDED_NONCANONICAL','HELD_OUTSIDE_TRANSFER']:
            raise ValueError('BAD_ROOT_DISPOSITION '+n)

def prepare(source, output):
    items=read_mount(source)
    if '000_BC.zip' not in items: raise ValueError('BC_MISSING')
    for n,b in items.items():
        if n.endswith('.zip') and n in ['000_BC.zip','021_G.zip','022_B.zip','024_V.zip','028_H.zip','PKDB_VOLUME_0001.zip']:
            verify_inner_manifest(n,b)
    mp,st=bc_state_from_bytes(items['000_BC.zip'])
    expected=st.get('inventory_expected',[])
    for n in expected:
        if n not in items: raise ValueError('CANONICAL_SHELF_MISSING '+n)
    check_root_disposition(items,st)
    validate_pkdb(items)
    source_sha=sha(Path(source).read_bytes()) if Path(source).is_file() else None
    new_bc,new_st=update_bc(items['000_BC.zip'],'PREPARE',source_sha)
    out_items={n:items[n] for n in expected}
    out_items['000_BC.zip']=new_bc
    out_b=zip_bytes(out_items)
    Path(output).write_bytes(out_b)
    validate_complete_container(out_b)
    print('PASS_MT00_PREPARE_COMPLETE_CONTAINER')

def finalize(source, output, target):
    items,st=validate_complete_container(source)
    if st.get('state')!='PACKAGED_READY_FOR_TARGET': raise ValueError('NOT_READY_FOR_TARGET_FINALIZE')
    new_bc,new_st=update_bc(items['000_BC.zip'],'FINALIZE',sha(Path(source).read_bytes()),target)
    items['000_BC.zip']=new_bc
    out_b=zip_bytes(items)
    Path(output).write_bytes(out_b)
    _,st2=validate_complete_container(out_b)
    if st2.get('state')!='TRANSFER_COMPLETE' or not st2.get('transfer_complete'):
        raise ValueError('FINALIZE_STATE_FAIL')
    print('PASS_MT00_FINALIZE_COMPLETE_CONTAINER')

def cmd_validate(source):
    _,st=validate_complete_container(source)
    print('PASS_MT00_BC_TRANSFER_CONTAINER '+st.get('state','UNKNOWN'))

def main():
    ap=argparse.ArgumentParser()
    sp=ap.add_subparsers(dest='cmd',required=True)
    p=sp.add_parser('prepare'); p.add_argument('--source',required=True); p.add_argument('--output',required=True)
    f=sp.add_parser('finalize'); f.add_argument('--source',required=True); f.add_argument('--output',required=True); f.add_argument('--target',required=True)
    v=sp.add_parser('validate'); v.add_argument('--source',required=True)
    a=ap.parse_args()
    try:
        if a.cmd=='prepare': prepare(a.source,a.output)
        elif a.cmd=='finalize': finalize(a.source,a.output,a.target)
        else: cmd_validate(a.source)
    except Exception as e:
        print('STOP_MT00 '+str(e)); sys.exit(2)
if __name__=='__main__': main()
