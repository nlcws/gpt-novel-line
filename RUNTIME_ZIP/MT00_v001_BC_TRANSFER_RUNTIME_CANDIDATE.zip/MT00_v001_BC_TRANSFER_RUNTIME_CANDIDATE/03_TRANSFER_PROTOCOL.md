# TRANSFER PROTOCOL

## PREPARE
1. Verify current mount.
2. Read `000_BC` and transfer state.
3. Enumerate all root items.
4. Require exactly one disposition for every root item.
5. Preserve all canonical shelf ZIPs.
6. Rebuild only `000_BC` control facts required for transfer.
7. Put this exact MT00 runtime in `RESIDENT/MT00/`.
8. Recompute `000_BC/MANIFEST.json` last.
9. Build one deterministic outer ZIP containing only canonical shelf ZIPs.
10. Validate the outer ZIP.

## FINALIZE TARGET
After the next environment has actually read the complete container and validation passes, rebuild `000_BC` transfer state to `TRANSFER_COMPLETE`, add target-validation audit, reseal `000_BC`, and emit another **complete container**.

No changed-files-only artifact can satisfy either phase.
