# IM80 ZERO START SET v001

New Project drop set.

## Runtime
Use `10_RUNTIME/TMP_IM80_v013_IMAGE_RUNTIME_CANDIDATE_v005.zip`.

## Mount
Place these three shelves into the Project mount:
1. `20_MOUNT/000_IC.zip`
2. `20_MOUNT/011_G_v000.zip`
3. `20_MOUNT/012_CA_v000.zip`

Do not create an empty 019 pack.
After boot, `000_IC` must report `ZERO_START_READY / WAIT_FOR_PROJECT_INPUT`.
When project sources arrive, read them before creating bindings or canon.
