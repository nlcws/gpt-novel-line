# VALIDATION_CHECKLIST v007

## Static
- [ ] 特定キャラ設定を内蔵していない
- [ ] ONE_IMAGE_ONLY
- [ ] SOURCE_GROUNDED_CONDITION_BUILD
- [ ] STORY_PACK target full read required
- [ ] DIRECT_IMAGE_REQUEST / STORY_PACK / SINGLE_STORY_TEXT / FREEFORM_TEXT / EDIT_IMAGE_SOURCE / MIXED_SOURCE support
- [ ] WORLD_BEFORE_FRAME
- [ ] PHYSICAL_RELATION_LOCK
- [ ] OBJECT_INTEGRITY_LOCK
- [ ] ACTION_BEFORE_CAMERA
- [ ] DEPTH_AND_ANGLE_PRIORITY
- [ ] CAMERA_DOES_NOT_REWRITE_WORLD
- [ ] CROP_NOT_BREAK
- [ ] 人数上限なし
- [ ] NO_FORCED_FULL_BODY
- [ ] NO_DEFAULT_HORIZONTAL_LINEUP
- [ ] CANON_CHARACTER_LOCK
- [ ] REFLECTION_GEOMETRY_LOCK
- [ ] PRE_GENERATION_REVIEW is visible generation spec
- [ ] WAIT_FOR_USER_APPROVAL before tool generation
- [ ] transfer state READ ONLY during generation
- [ ] IMT00 resident not auto-run during generation
- [ ] optional mount ABSENT_OK
- [ ] EDIT target required

## Regression

### A / Direct detailed request
SCENE/TARGET/ACTION/CAMERAが直接指定。
期待: source_kind=DIRECT_IMAGE_REQUEST → review → WAIT。

### B / Story pack
複数話ZIP、ユーザーが対象話を指定。
期待: 対象話本文を実読してから条件化。タイトルだけで作らない。

### C / Story pack target ambiguous
対象話指定なし、transfer stateにもnext不明。
期待: STOP。

### D / Single manuscript txt
単話本文から扉絵条件を作る。
期待: 本文事実とProject正本を分離してレビュー化。

### E / Freeform notes
箇条書きだけ。
期待: 書かれていない設定を勝手に正本化しない。

### F / Transfer-aware restart
000_IC/CURRENT_STATE に次の対象話 / output size がある。
期待: 画像ライン現在地だけ復元し、本文進捗を捏造しない。

### F2 / Zero-start mount
000_IC/CURRENT_STATE が `ZERO_START_READY / WAIT_FOR_PROJECT_INPUT`。
期待: Project名、対象話、出力仕様、継続情報を推測せず、入力を待つ。

### G / 000_IC resident exists
通常画像生成。
期待: resident runtimeを起動しない。

### H / Explicit image transfer request
期待: IMAGE_RUNTIMEではなくIMT00 laneへ渡す。

### I / 5-person scene
人数だけでSTOPしない。全員収容も強制しない。

### J / Physical tool crop
道具が画面端へ続く。
期待: NORMAL_FRAME_OUT。

### K / Break
物体が画面内で途中消失。
期待: FAIL。

### L / Reflection
鏡像は同一人物・同一瞬間・反射幾何一致。

### M / Review revision
ユーザーがカメラだけ修正。
期待: review更新→再WAIT。まだ生成しない。

### N / Explicit approval
期待: IMAGE_GENERATION_APPROVED → 1枚だけ生成。

### O / Edit target absent
期待: STOP。

### P / Manifest
自己除外宣言、listed_file_count、package_entry_count、全bytes/SHA一致。
