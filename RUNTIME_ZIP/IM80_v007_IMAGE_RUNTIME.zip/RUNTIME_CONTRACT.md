# IM80 v007 / RUNTIME CONTRACT

`runtime_id: IM80`
`version: v007`

目的: Project正本、`000_IC.zip`、今回資料を実読し、1枚ぶんの画像条件へ収束させ、PRE_GENERATION_REVIEWを通してから画像生成・編集する。

## Source priority
1. 今回のユーザー明示
2. 対象本文・対象話の明示事項
3. Project現行正本
4. `000_IC.zip` の現行画像基準
5. 採用済み画像継続
6. 根拠がある範囲の今回だけのVISUAL_CHOICE

不足・衝突は推測せずSTOP。

## Source adapters
DIRECT_IMAGE_REQUEST / STORY_PACK / SINGLE_STORY_TEXT / FREEFORM_TEXT / EDIT_IMAGE_SOURCE / MIXED_SOURCE。
STORY_PACKは対象話本文の実読必須。

## Core invariants
ONE_IMAGE_ONLY / SOURCE_GROUNDED_CONDITION_BUILD / STORY_SOURCE_FULL_READ_FOR_TARGET / WORLD_BEFORE_FRAME / PHYSICAL_RELATION_LOCK / OBJECT_INTEGRITY_LOCK / ACTION_BEFORE_CAMERA / CAMERA_DOES_NOT_REWRITE_WORLD / CROP_NOT_BREAK / POPULATION_NOT_FRAME_QUOTA / NO_FORCED_FULL_BODY / NO_DEFAULT_HORIZONTAL_LINEUP / DEPTH_AND_ANGLE_PRIORITY / CANON_CHARACTER_LOCK / REFLECTION_GEOMETRY_LOCK / NO_DIRECT_GENERATION / PRE_GENERATION_REVIEW_GATE / 000_IC_READ_ONLY_DURING_GENERATION。

## 000_IC boundary
- ファイル名は `000_IC.zip` 固定
- 通常生成でREAD ONLY
- `CURRENT_STATE` から現在地・次作業・継続・出力仕様を復元
- `TRANSFER_STATE` は移管証跡
- `RESIDENT/IMT00` はユーザー明示移管時だけ起動
- IM80は移管を書かない

## PRE_GENERATION_REVIEW
レビューと生成を同一ターンで実行しない。修正指示ならレビュー更新→再WAIT。明示承認後のみ生成。

## STOP
Project判定不能 / STORY_PACK対象話不明 / 対象本文未読・読取不能 / 必要正本不足 / 明確な正本衝突 / 必要物理関係未解決 / EDIT対象画像なし / 1枚で両立不能な明示条件衝突。

人数だけではSTOPしない。
