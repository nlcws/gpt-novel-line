# SOURCE_TO_IMAGE_CONDITIONS

## 0. Purpose

話パック・単話テキスト・自由テキスト・直接指示を、
**1枚の画像生成条件 `IMAGE_CONDITION_SET`** へ変換するための共通工程。

「本文を読んだ」ことと「画像条件を創作した」ことを混同しない。

---

## 1. SOURCE_KIND

### DIRECT_IMAGE_REQUEST
ユーザーがSCENE / TARGET / ACTION / CAMERA等を直接指定する。
指定を最優先し、Project正本との衝突のみ確認する。

### STORY_PACK
複数話を含むZIP・話パック・連載パック。

必須:
1. 対象話を特定する
2. **対象話本文を実読する**
3. 必要なシリーズ継続条件をProject正本から読む
4. タイトルだけ・要約だけ・過去会話だけで画像条件を作らない

対象話が曖昧ならSTOP。

### SINGLE_STORY_TEXT
単話本文・脚本・SS・記事など。
対象テキストを実読し、画像化候補となる場面を抽出する。

### FREEFORM_TEXT
メモ、箇条書き、企画文、場面説明。
書かれている条件だけを事実として扱う。
不足はProject正本で補える範囲だけ補い、それ以外は `UNRESOLVED`。

### EDIT_IMAGE_SOURCE
編集対象画像の実体＋変更指示。
元画像の `PRESERVE` と `CHANGE` を分離する。

### MIXED_SOURCE
複数資料を併用する。
衝突時は優先順位を明示し、勝手に統合しない。

---

## 2. Source Fact Classes

抽出した条件は内部的に次へ分ける。

- `USER_EXPLICIT` : 今回ユーザーが明示
- `SOURCE_EXPLICIT` : 対象本文・話パックに明記
- `PROJECT_CANON` : Project現行正本
- `IMAGE_MOUNT_CANON` : 現行画像マウント基準
- `ADOPTED_VISUAL_CONTINUITY` : 採用済み画像からの継続
- `VISUAL_CHOICE` : 正本を壊さない範囲の今回だけの演出選択
- `UNRESOLVED` : 根拠不足

`VISUAL_CHOICE` を正本事実のように扱わない。

---

## 3. Story/Text -> Condition Build

対象資料から最低限次を抽出する。

- episode / title（存在する場合）
- scene candidate
- target characters / visible people
- world / location / time
- action / immediate moment
- props / equipment
- physical relations
- dialogue / text candidates
- emotional temperature
- explicit visual constraints
- prohibited implications

その後Project正本・画像マウントから:

- character identity
- costume
- body / height relation
- world design
- recurring marks / logos
- output size / aspect
- image-series continuity

を解決する。

---

## 4. Scene Selection from Narrative

本文に複数場面がある場合、勝手に「一番感動的な場面」へ寄せない。

優先:
1. ユーザーが指定した場面
2. 話の核を視覚的に一目で伝える場面
3. 作品の温度・ギャグ構造を壊さない場面
4. 正本設備を無理に再設計しなくて済む場面
5. 1枚で物理的に成立する場面

候補が複数同等なら、レビュー内で採用理由を短く示す。

---

## 5. IMAGE_CONDITION_SET

生成前には最低限:

```text
source_kind
source_basis
scene
target
action
style_lock
world_color
camera
physics
character_lock
text_output_spec
preserve_change
prohibited
aim
unresolved
```

へ収束する。

空欄を埋めるためだけの創作は禁止。
不要項目は省略可。

---

## 6. Output Size

出力サイズ・アスペクトは:
1. 今回ユーザー指定
2. Project画像ルール
3. `000_IC.zip` 内 `000_IC/CURRENT_STATE` の現行出力仕様
4. 画像マウント共通規則

の順で解決する。

過去の別Projectサイズを持ち込まない。

---

## 7. STOP

- STORY_PACKで対象話が特定できない
- 対象本文を読めない
- キャラ識別に必要な正本が不足
- 本文とProject正本が明確に衝突
- 画像化に必要な物理関係が決められない
- 未解決を推測で埋めないと成立しない

STOP時は不足だけ返す。
