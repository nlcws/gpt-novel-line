# START_HERE / IM80 v007

### BOOT-01 REQUEST
NEW_IMAGE / EDIT_IMAGE を判定。EDITは対象画像実体なしならSTOP。

### BOOT-02 SOURCE KIND
DIRECT_IMAGE_REQUEST / STORY_PACK / SINGLE_STORY_TEXT / FREEFORM_TEXT / EDIT_IMAGE_SOURCE / MIXED_SOURCE。

### BOOT-03 000_IC MOUNT
`000_IC.zip` があれば固定マウントとして読む。manifest実体一致を確認し、`000_IC/TRANSFER_STATE/VALIDATION_REPORT.json` がPASSなら `000_IC/CURRENT_STATE` を現在地として採用する。

`project_state: ZERO_START_READY` または `next_state: WAIT_FOR_PROJECT_INPUT` なら、Project名、対象話、出力仕様、継続情報を推測せず、確認済みのProject入力を待つ。

### BOOT-04 PROJECT SOURCES
Project現行正本を実読。過去会話記憶で代用しない。

### BOOT-05 TASK SOURCE READ
STORY_PACKは対象話を特定して対象話本文を実読。SINGLE_STORY_TEXT / FREEFORM_TEXTは対象テキストを実読。DIRECTはユーザー指定をsource factsとして採用。

### BOOT-06 IMAGE REFERENCES
`00_RULES` → キャラ基準 → 衣装・小物 → グループ参考 → 採用済み継続画像。ARCHIVEは通常読まない。resident IMT00は移管要求がない限り起動しない。

### BOOT-07 CONDITION BUILD
SOURCE FACTS → WORLD → PHYSICS → ACTION → LOCKS → CAMERA → CROP。

### BOOT-08 PRE_GENERATION_REVIEW
生成仕様書を提示して `generation_state: WAIT_FOR_USER_APPROVAL`。この時点では生成しない。

### BOOT-09 GENERATE
明示承認後に1枚だけ生成・編集。

### BOOT-10 POST CHECK
本人性、世界、物理、物体完全性、手・道具・設備、CROP/BREAK、反射、指示外追加、文字、ロゴ、出力仕様を確認。確認不能をPASS扱いしない。
