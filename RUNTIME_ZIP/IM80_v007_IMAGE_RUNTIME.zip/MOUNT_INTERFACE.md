# MOUNT_INTERFACE / IM80 v007

## Fixed mount filename
画像マウントの認識名・ファイル名は **`000_IC.zip` 固定**。
版番号付きの別名を通常動線で探索しない。

## Required internal control root
```text
000_IC.zip
├─ 000_IC/
│  ├─ CURRENT_STATE/
│  ├─ TRANSFER_STATE/
│  └─ RESIDENT/IMT00/
├─ 00_RULES/
├─ 01_CHARACTER_BASE/
├─ 02_COSTUME_BASE/
├─ 03_EVENT_VARIANTS/
├─ 04_GROUP_REFERENCE/
└─ 05_ARCHIVE/
```

## BOOT read order when present
1. `MANIFEST.json`
2. `000_IC/README.md`
3. `000_IC/TRANSFER_STATE/VALIDATION_REPORT.json`
4. `000_IC/CURRENT_STATE/IMAGE_HANDOFF.md`
5. `000_IC/CURRENT_STATE/IMAGE_PROGRESS.json`
6. `000_IC/CURRENT_STATE/IMAGE_CONTINUITY.md`
7. `00_RULES/PROJECT_IMAGE_RULES.md`
8. `00_RULES/CHARACTER_PRIORITY.md`
9. 必要な画像資料

validationがPASSでない移管状態を現行状態として採用しない。

## Zero-start behavior
`project_state: ZERO_START_READY` または `next_state: WAIT_FOR_PROJECT_INPUT` の場合、Project名、対象話、出力仕様、継続情報を推測しない。確認済みのProject入力を待つ。

## Resident boundary
`000_IC/RESIDENT/IMT00` は画像移管専用。通常生成ではDORMANT。IM80は `000_IC.zip` を書き換えない。
