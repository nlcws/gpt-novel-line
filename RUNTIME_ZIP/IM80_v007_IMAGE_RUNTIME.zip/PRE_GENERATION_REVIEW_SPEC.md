# PRE_GENERATION_REVIEW_SPEC

## 0. Definition

`PRE_GENERATION_REVIEW` は生成前の確認メモではなく、
**その1枚の生成仕様書**。

ユーザーが読んで「何が、どこで、何をして、どの画角で、何を守って描かれるか」を確認できる粒度まで具体化する。

---

## 1. Standard Order

推奨順:

```text
## PRE_GENERATION_REVIEW

SCENE
SOURCE BASIS          # 話パック・本文由来時に短く
TARGET
ACTION
STYLE LOCK
WORLD / COLOR
CAMERA
PHYSICS
CHARACTER LOCK
TEXT / OUTPUT SPEC    # 必要時
PRESERVE / CHANGE     # 編集時
PROHIBITED
AIM
UNRESOLVED            # あれば

generation_state: WAIT_FOR_USER_APPROVAL
```

全項目を機械的に埋める必要はない。
意味のない項目は省略・統合してよい。

---

## 2. Required Quality

### SCENE
時間・場所・場面を一文で特定。

### TARGET
今回画面へ出す主要人物・必要な背景人物。
画面外の人物は無理に入れない。

### ACTION
**静止ポーズではなく、生成する瞬間に何が起きているか**を書く。

### STYLE LOCK
Project基準絵・画風・避ける再設計を明示。
写実化・別作品化・リアル美人化等の事故源がある場合はここで止める。

### WORLD / COLOR
時間帯、天候、支配色、背景密度、光。
色指定が不要ならWORLDへ統合可。

### CAMERA
カメラが世界のどこにあるか。
高さ・距離・前景・中景・奥・遮蔽・見切れを必要な範囲で書く。

### PHYSICS
今回壊れやすい物理だけを局所LOCKする。
手、道具、軸、重力、風向、反射、設備、接地等。

### CHARACTER LOCK
今回登場する人物について、必要な本人性だけ再確認する。
Runtimeへ恒久キャラ設定を埋め込まない。

### TEXT / OUTPUT SPEC
タイトル、吹き出し、ロゴ、印、完成サイズなど。
文字が不要なら省略。

### PROHIBITED
今回の事故源を具体的に列挙。
汎用禁止事項を無限に転載しない。

### AIM
最後に一文で、**この絵の狙い**を固定する。

---

## 3. WAIT Gate

レビュー提示後は必ず:

`generation_state: WAIT_FOR_USER_APPROVAL`

ユーザー承認前に生成ツールを呼ばない。

修正指示が来た場合:
- 条件を更新
- レビュー再提示
- 再びWAIT

承認後のみ:
`generation_state: IMAGE_GENERATION_APPROVED`

---

## 4. Narrative Source Rule

話パック・本文からレビューを作る場合、
レビューの情報は `SOURCE_TO_IMAGE_CONDITIONS.md` で抽出・解決したものに限る。

本文にない感情・設定・イベントを「絵映え」のために追加しない。
