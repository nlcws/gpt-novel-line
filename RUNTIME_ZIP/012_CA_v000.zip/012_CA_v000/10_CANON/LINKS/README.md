# TEXT CANON LINKS / ZERO START

No authoritative project text canon is bound yet. Add locators only after grounded sources are supplied and actually read.
