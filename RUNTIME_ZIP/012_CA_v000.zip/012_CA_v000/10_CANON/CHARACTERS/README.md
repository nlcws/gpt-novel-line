# CHARACTERS / ZERO START

Intentionally empty. Create character canon directories only after a real character reaches CANONIZATION and receives explicit user acceptance.
