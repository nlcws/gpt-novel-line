# START_HERE / 012_CA v000 ZERO START

Role: empty reusable accepted visual canon shelf.

Empty is valid and expected before project binding/canonization.

Read order:
1. `10_CANON/CURRENT_STATE/CANON_ASSET_INDEX.json`
2. `10_CANON/LINKS/TEXT_CANON_REGISTRY.json`
3. grounded project/user source after it is supplied

Rules:
- normal generation is READ ONLY;
- no character/body/costume fact is invented here;
- ROUGH output is not canon;
- user acceptance is required before promotion;
- finished event art / thumbnails / one-off illustrations stay external;
- temporary event-only source belongs to `019_*`, not this shelf.
