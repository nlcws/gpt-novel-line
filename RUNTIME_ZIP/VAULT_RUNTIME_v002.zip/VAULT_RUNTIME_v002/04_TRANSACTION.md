# VAULT / 04_TRANSACTION

Default update flow:
1. VERIFY current active target.
2. STAGE a whole-target copy.
3. Apply intended changes only inside staging.
4. Build candidate manifest.
5. Run structural closure/hash validation.
6. If profile requires semantic validation, require external semantic evidence bound to the candidate root hash.
7. Preserve previous admitted target as LKG.
8. Publish the whole candidate target.
9. Write active manifest/state last.
10. VERIFY published target.

Any failed gate => STOP. The candidate is not active.
