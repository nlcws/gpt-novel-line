# VAULT / 02_AUTHORITY

There is no unrestricted standing persisted write/export authority.

Protected actions require one of two authority paths:

## A. Explicit user grant
A machine-readable per-target authority grant issued by the USER may authorize:
- SEAL
- STAGE
- COMMIT
- RESTORE
- PACK

The grant must identify the delegate/actor, exact target, and requested operation.

## B. Project standing maintenance key
A governing `PROJECT_MAINTENANCE_AUTHORITY_PROFILE_v003` may name persistent maintenance-key holders.

A listed holder may use the key without a fresh per-task grant only when:
- the operation is permitted by the profile;
- the purpose is one of the profile's maintenance purposes;
- the target is inside the profile's governed Project scope;
- the actor is exactly a listed key holder.

The standing key is for maintenance, transfer, recovery, rebind, and reseal continuity across session/model/account/service/environment changes. It is not ordinary write authority and does not authorize semantic/business/canon changes without user instruction.

Every mutating key use must be audit-recorded.

Read-only VERIFY does not require authority.
VAULT remains actor-neutral: it trusts the supplied governing profile and does not hard-code BL90, DS90, MT00, or any other actor name.
