# VAULT Runtime v002 / 豆金庫

Zero-base independent vault Runtime extracted conceptually from prior robustness work, without dependency on any specific designer/librarian Runtime.

Core loop:
**explicit authority -> verify -> stage whole target -> validate -> publish whole target -> manifest/state last -> verify -> LKG**

Use locally. Do not vault every working file by default.

Authority sources: explicit USER grants or Project standing maintenance keys.
