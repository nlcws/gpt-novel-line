# VAULT / 01_SCOPE

Use VAULT only where high-value integrity justifies the overhead.

Supported target classes:
- FILE_VAULT: one file as atomic target;
- SHELF_VAULT: one directory/shelf as atomic target;
- PORTABLE_VAULT: a sealed target exported with verification evidence.

Default atomic unit is WHOLE_TARGET.
Ordinary high-churn working data should remain outside VAULT unless explicitly selected.
