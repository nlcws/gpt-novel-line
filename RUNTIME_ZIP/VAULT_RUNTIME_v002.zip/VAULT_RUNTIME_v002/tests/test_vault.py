from pathlib import Path
import tempfile,json,hashlib,importlib.util,argparse,subprocess,sys
ROOT=Path(__file__).resolve().parents[1]
SPEC=importlib.util.spec_from_file_location('vaultmod', ROOT/'tools'/'vault.py')
V=importlib.util.module_from_spec(SPEC); SPEC.loader.exec_module(V)

def grant(path,target,ops,delegate='TEST_ACTOR'):
    path.write_text(json.dumps({'schema':'VAULT_AUTHORITY_GRANT_v001','grant_id':'G','issued_by':'USER','delegate':delegate,'target':str(target.resolve()),'operations':ops}),encoding='utf-8')

def profile(path):
    path.write_text(json.dumps({'schema':'PROJECT_MAINTENANCE_AUTHORITY_PROFILE_v003','standing_maintenance_keys':{'enabled':True,'target_scope':'PROFILE_PARENT_RECURSIVE','allowed_purposes':['MAINTENANCE','TRANSFER','RECOVERY','REBIND','RESEAL'],'vault_operations':['SEAL','STAGE','COMMIT','RESTORE','PACK'],'holders':[{'runtime_id':'BL90'},{'runtime_id':'MT00'}]}}),encoding='utf-8')

def ns(**kw): return argparse.Namespace(**kw)

def common(target,grant=None,authority_profile=None,actor=None,purpose=None,state_dir=None,profile=None,semantic_evidence=None):
    return ns(target=str(target),grant=str(grant) if grant else None,authority_profile=str(authority_profile) if authority_profile else None,actor=actor,purpose=purpose,state_dir=str(state_dir) if state_dir else None,profile=str(profile) if profile else None,semantic_evidence=str(semantic_evidence) if semantic_evidence else None)

with tempfile.TemporaryDirectory() as td:
    r=Path(td); t=r/'shelf'; t.mkdir(); (t/'a.txt').write_text('one',encoding='utf-8'); g=r/'grant.json'
    # no authority cannot mutate
    assert V.cmd_seal(common(t))!=0
    # explicit grant remains valid
    grant(g,t,['SEAL','STAGE','COMMIT','RESTORE','PACK'])
    assert V.cmd_seal(common(t,grant=g))==0
    assert V.cmd_verify(ns(target=str(t),state_dir=None))==0
    (t/'a.txt').write_text('tampered',encoding='utf-8'); assert V.cmd_verify(ns(target=str(t),state_dir=None))!=0
    assert V.cmd_restore(ns(target=str(t),generation=1,state_dir=None,grant=str(g),authority_profile=None,actor=None,purpose=None))==0
    assert (t/'a.txt').read_text(encoding='utf-8')=='one'
    a=common(t,grant=g); assert V.cmd_stage(a)==0
    sd=V.state_dir(t.resolve()); st=sd/'STAGING'/'generation_000002'/t.name; (st/'a.txt').write_text('two',encoding='utf-8')
    assert V.cmd_commit(ns(target=str(t),staging=str(st),state_dir=None,grant=str(g),authority_profile=None,actor=None,purpose=None,profile=None,semantic_evidence=None))==0
    assert (t/'a.txt').read_text(encoding='utf-8')=='two'
    (t/'extra.txt').write_text('x',encoding='utf-8'); assert V.cmd_verify(ns(target=str(t),state_dir=None))!=0
    assert V.cmd_restore(ns(target=str(t),generation=2,state_dir=None,grant=str(g),authority_profile=None,actor=None,purpose=None))==0

    # standing key survives without fresh per-task grant
    k=r/'PROJECT_MAINTENANCE_AUTHORITY_PROFILE_v003.json'; profile(k)
    t2=r/'controlled'; t2.mkdir(); (t2/'x.txt').write_text('v1',encoding='utf-8')
    assert V.cmd_seal(common(t2,authority_profile=k,actor='BL90',purpose='MAINTENANCE'))==0
    assert V.cmd_stage(common(t2,authority_profile=k,actor='BL90',purpose='MAINTENANCE'))==0
    sd2=V.state_dir(t2.resolve()); st2=sd2/'STAGING'/'generation_000002'/t2.name; (st2/'x.txt').write_text('v2',encoding='utf-8')
    assert V.cmd_commit(ns(target=str(t2),staging=str(st2),state_dir=None,grant=None,authority_profile=str(k),actor='BL90',purpose='MAINTENANCE',profile=None,semantic_evidence=None))==0
    audit=sd2/'AUTHORITY_AUDIT.jsonl'; assert audit.exists() and 'PROJECT_STANDING_MAINTENANCE_KEY' in audit.read_text(encoding='utf-8')
    # unlisted actor / wrong purpose rejected
    assert V.cmd_stage(common(t2,authority_profile=k,actor='OTHER',purpose='MAINTENANCE'))!=0
    assert V.cmd_stage(common(t2,authority_profile=k,actor='BL90',purpose='ORDINARY_WRITE'))!=0
    # outside target rejected
    with tempfile.TemporaryDirectory() as od:
        out=Path(od)/'outside'; out.mkdir(); (out/'x').write_text('z',encoding='utf-8')
        assert V.cmd_seal(common(out,authority_profile=k,actor='BL90',purpose='MAINTENANCE'))!=0
    # deterministic pack via standing MT00 key
    p1=r/'p1.zip'; p2=r/'p2.zip'
    assert V.cmd_pack(ns(target=str(t2),output=str(p1),state_dir=None,grant=None,authority_profile=str(k),actor='MT00',purpose='TRANSFER'))==0
    assert V.cmd_pack(ns(target=str(t2),output=str(p2),state_dir=None,grant=None,authority_profile=str(k),actor='MT00',purpose='TRANSFER'))==0
    assert p1.read_bytes()==p2.read_bytes()

v=subprocess.run([sys.executable,str(ROOT/'tools'/'validate_vault_runtime.py')],capture_output=True,text=True,timeout=8)
assert v.returncode==0, v.stdout+v.stderr
print('PASS_VAULT_TESTS_V002')
