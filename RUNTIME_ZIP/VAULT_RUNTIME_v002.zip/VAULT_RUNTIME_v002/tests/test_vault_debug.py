from pathlib import Path
import subprocess,tempfile,json,sys,hashlib
ROOT=Path(__file__).resolve().parents[1]; TOOL=ROOT/'tools'/'vault.py'
def run(*a): return subprocess.run([sys.executable,str(TOOL),*map(str,a)],capture_output=True,text=True,timeout=8)
def grant(path,target,ops,delegate='TEST_ACTOR'):
    path.write_text(json.dumps({'schema':'VAULT_AUTHORITY_GRANT_v001','grant_id':'G','issued_by':'USER','delegate':delegate,'target':str(target.resolve()),'operations':ops}),encoding='utf-8')
def profile(path):
    path.write_text(json.dumps({'schema':'PROJECT_MAINTENANCE_AUTHORITY_PROFILE_v003','standing_maintenance_keys':{'enabled':True,'target_scope':'PROFILE_PARENT_RECURSIVE','allowed_purposes':['MAINTENANCE','TRANSFER','RECOVERY','REBIND','RESEAL'],'vault_operations':['SEAL','STAGE','COMMIT','RESTORE','PACK'],'holders':[{'runtime_id':'BL90'},{'runtime_id':'MT00'}]}}),encoding='utf-8')
with tempfile.TemporaryDirectory() as td:
    r=Path(td); t=r/'shelf'; t.mkdir(); (t/'a.txt').write_text('one',encoding='utf-8'); g=r/'grant.json'
    print('MARK0', flush=True)
    # no authority cannot mutate
    x=run('seal',t); assert x.returncode!=0
    print('MARK1', flush=True)
    # explicit grant path remains valid
    grant(g,t,['SEAL','STAGE','COMMIT','RESTORE','PACK'])
    x=run('seal',t,'--grant',g); assert x.returncode==0 and 'PASS_SEAL' in x.stdout
    assert run('verify',t).returncode==0
    (t/'a.txt').write_text('tampered',encoding='utf-8'); assert run('verify',t).returncode!=0
    assert run('restore',t,1,'--grant',g).returncode==0 and (t/'a.txt').read_text()=='one'
    st=Path(run('stage',t,'--grant',g).stdout.strip()); (st/'a.txt').write_text('two',encoding='utf-8')
    assert run('commit',t,st,'--grant',g).returncode==0 and (t/'a.txt').read_text()=='two'
    (t/'extra.txt').write_text('x',encoding='utf-8'); assert run('verify',t).returncode!=0
    assert run('restore',t,2,'--grant',g).returncode==0
    print('MARK2', flush=True)
    # standing key survives without fresh per-task grant
    k=r/'PROJECT_MAINTENANCE_AUTHORITY_PROFILE_v003.json'; profile(k)
    t2=r/'controlled'; t2.mkdir(); (t2/'x.txt').write_text('v1',encoding='utf-8')
    x=run('seal',t2,'--authority-profile',k,'--actor','BL90','--purpose','MAINTENANCE'); assert x.returncode==0, x.stdout+x.stderr
    st2=Path(run('stage',t2,'--authority-profile',k,'--actor','BL90','--purpose','MAINTENANCE').stdout.strip()); (st2/'x.txt').write_text('v2',encoding='utf-8')
    assert run('commit',t2,st2,'--authority-profile',k,'--actor','BL90','--purpose','MAINTENANCE').returncode==0
    audit=t2.parent/(t2.name+'.vault_state')/'AUTHORITY_AUDIT.jsonl'; assert audit.exists() and 'PROJECT_STANDING_MAINTENANCE_KEY' in audit.read_text(encoding='utf-8')
    print('MARK3', flush=True)
    # unlisted actor rejected
    assert run('stage',t2,'--authority-profile',k,'--actor','OTHER','--purpose','MAINTENANCE').returncode!=0
    print('MARK4', flush=True)
    # wrong purpose rejected
    assert run('stage',t2,'--authority-profile',k,'--actor','BL90','--purpose','ORDINARY_WRITE').returncode!=0
    print('MARK5', flush=True)
    # target outside profile parent rejected
    with tempfile.TemporaryDirectory() as od:
        out=Path(od)/'outside'; out.mkdir(); (out/'x').write_text('z',encoding='utf-8')
        assert run('seal',out,'--authority-profile',k,'--actor','BL90','--purpose','MAINTENANCE').returncode!=0
    print('MARK6', flush=True)
    # wrong target explicit grant rejected
    bad=r/'bad.json'; print('BEFORE_GRANT',flush=True); grant(bad,r/'other',['STAGE']); print('AFTER_GRANT',flush=True); zz=run('stage',t2,'--grant',bad); print('AFTER_RUN',zz.returncode,zz.stdout,zz.stderr,flush=True); assert zz.returncode!=0
    print('MARK7', flush=True)
    # deterministic portable pack using standing key
    p1=r/'p1.zip'; p2=r/'p2.zip'; assert run('pack',t2,p1,'--authority-profile',k,'--actor','MT00','--purpose','TRANSFER').returncode==0; assert run('pack',t2,p2,'--authority-profile',k,'--actor','MT00','--purpose','TRANSFER').returncode==0; assert p1.read_bytes()==p2.read_bytes()
print('MARK8', flush=True)
v=subprocess.run([sys.executable,str(ROOT/'tools'/'validate_vault_runtime.py')],capture_output=True,text=True,timeout=8); assert v.returncode==0, v.stdout+v.stderr
print('PASS_VAULT_TESTS_V002')
