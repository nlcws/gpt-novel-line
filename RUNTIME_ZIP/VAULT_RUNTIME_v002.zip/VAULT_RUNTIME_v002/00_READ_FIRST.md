# VAULT RUNTIME / 00_READ_FIRST
VERSION: v002
STATUS: RELEASE / ZERO-BASE
DISPLAY_NAME: 豆金庫

VAULT is an independent high-value artifact protection Runtime.
It is not a librarian, designer, Project controller, or domain specialist.
It protects a declared target by explicit authority, staged whole-target transactions, manifest closure, optional semantic evidence, and Last Known Good recovery.

VAULT has no standing writer.
Mutating/export actions require explicit user-delegated authority for the target and operation.
The user may delegate to any Project-approved actor; VAULT does not hard-code any actor, role, Project, model, or service identity.
