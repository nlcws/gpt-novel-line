#!/usr/bin/env python3
import hashlib,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    m=json.loads((ROOT/'MANIFEST.json').read_text(encoding='utf-8')); exp={x['path']:x for x in m['files']}
    act={p.relative_to(ROOT).as_posix():p for p in ROOT.rglob('*') if p.is_file() and p.name!='MANIFEST.json' and '__pycache__' not in p.parts and p.suffix!='.pyc'}
    if set(exp)!=set(act): print('STOP[MANIFEST_CLOSURE]'); return 2
    for r,p in act.items():
        if p.stat().st_size!=exp[r]['bytes'] or sha(p)!=exp[r]['sha256']: print('STOP[MANIFEST_HASH] '+r); return 2
    print('PASS_VAULT_RUNTIME'); return 0
if __name__=='__main__': raise SystemExit(main())
