#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, json, os, shutil, zipfile
from pathlib import Path
FIXED_DT=(2020,1,1,0,0,0)
MANIFEST_SCHEMA='VAULT_TARGET_MANIFEST_v001'; STATE_SCHEMA='VAULT_STATE_v001'

def jload(p): return json.loads(Path(p).read_text(encoding='utf-8'))
def jdump(p,o):
    p=Path(p); p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(o,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
def fsha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for c in iter(lambda:f.read(1024*1024),b''): h.update(c)
    return h.hexdigest()
def bsha(b): return hashlib.sha256(b).hexdigest()
def state_dir(t): return t.parent/(t.name+'.vault_state')
def files(t):
    if t.is_file(): return [(t.name,t)]
    if not t.is_dir(): raise FileNotFoundError(t)
    return [(p.relative_to(t).as_posix(),p) for p in sorted(t.rglob('*')) if p.is_file()]
def manifest(t,gen):
    es=[{'path':r,'bytes':p.stat().st_size,'sha256':fsha(p)} for r,p in files(t)]
    body={'schema':MANIFEST_SCHEMA,'generation':gen,'target_name':t.name,'target_type':'FILE' if t.is_file() else 'DIRECTORY','files':es}
    canon=json.dumps(body,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
    body['root_sha256']=bsha(canon); return body
def verify_m(t,m):
    cur=manifest(t,int(m['generation'])); return cur==m,cur
def copy(src,dst):
    if dst.exists(): shutil.rmtree(dst) if dst.is_dir() else dst.unlink()
    if src.is_dir(): shutil.copytree(src,dst)
    else: dst.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(src,dst)
def stop(code,msg=''): print(f'STOP[{code}]'+((' '+msg) if msg else '')); return 2

def explicit_grant_ok(grant_path,target,op):
    if not grant_path: return False,'GRANT_REQUIRED'
    try:g=jload(grant_path)
    except Exception:return False,'GRANT_INVALID_JSON'
    if g.get('schema')!='VAULT_AUTHORITY_GRANT_v001': return False,'GRANT_SCHEMA'
    if g.get('issued_by')!='USER': return False,'GRANT_ISSUER'
    try:gt=str(Path(g.get('target','')).resolve())
    except Exception:return False,'GRANT_TARGET'
    if gt!=str(target.resolve()): return False,'GRANT_TARGET'
    if op not in g.get('operations',[]): return False,'GRANT_OPERATION'
    if not g.get('delegate'): return False,'GRANT_DELEGATE'
    return True,g


def _within(child,parent):
    try:
        child=Path(child).resolve(); parent=Path(parent).resolve(); child.relative_to(parent); return True
    except Exception:return False

def standing_key_ok(profile_path,actor,purpose,target,op):
    if not profile_path: return False,'GRANT_REQUIRED'
    try:p=jload(profile_path)
    except Exception:return False,'AUTH_PROFILE_INVALID_JSON'
    if p.get('schema')!='PROJECT_MAINTENANCE_AUTHORITY_PROFILE_v003': return False,'AUTH_PROFILE_SCHEMA'
    sk=p.get('standing_maintenance_keys',{})
    if not sk.get('enabled'): return False,'STANDING_KEY_DISABLED'
    holders={x.get('runtime_id') for x in sk.get('holders',[]) if x.get('runtime_id')}
    if not actor or actor not in holders: return False,'STANDING_KEY_ACTOR'
    if not purpose or purpose not in sk.get('allowed_purposes',[]): return False,'STANDING_KEY_PURPOSE'
    if op not in sk.get('vault_operations',[]): return False,'STANDING_KEY_OPERATION'
    scope=sk.get('target_scope')
    if scope!='PROFILE_PARENT_RECURSIVE': return False,'STANDING_KEY_SCOPE_POLICY'
    root=Path(profile_path).resolve().parent
    if not _within(target,root): return False,'STANDING_KEY_TARGET'
    return True,{'schema':'VAULT_STANDING_KEY_USE_v002','delegate':actor,'purpose':purpose,'target':str(target.resolve()),'operations':[op],'_authority_source':'PROJECT_STANDING_MAINTENANCE_KEY','_authority_profile':str(Path(profile_path).resolve())}

def audit_use(sd,grant,target,op,before_root=None,after_root=None):
    if not grant:return
    rec={'actor':grant.get('delegate'),'target':str(Path(target).resolve()),'purpose':grant.get('purpose') or 'EXPLICIT_GRANT','operation':op,'authority_source':grant.get('_authority_source','USER_EXPLICIT_GRANT'),'before_root_sha256':before_root,'after_root_sha256':after_root}
    p=Path(sd)/'AUTHORITY_AUDIT.jsonl'; p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('a',encoding='utf-8',newline='\n') as f:f.write(json.dumps(rec,ensure_ascii=False,sort_keys=True)+'\n')

def require_grant(a,t,op):
    
    gp=getattr(a,'grant',None)
    if gp:
        ok,d=explicit_grant_ok(gp,t,op)
        if not ok: return None,stop(d)
        d=dict(d); d['_authority_source']='USER_EXPLICIT_GRANT'; return d,None
    pp=getattr(a,'authority_profile',None)
    actor=getattr(a,'actor',None); purpose=getattr(a,'purpose',None)
    ok,d=standing_key_ok(pp,actor,purpose,t,op)
    if not ok: return None,stop(d)
    return d,None

def semantic_ok(profile_path,evidence_path,candidate):
    if not profile_path: return True,None
    p=jload(profile_path)
    gate=p.get('semantic_gate','STRUCTURAL_ONLY')
    if gate=='STRUCTURAL_ONLY': return True,None
    if gate!='EXTERNAL_REQUIRED': return False,'SEMANTIC_GATE_UNKNOWN'
    if not evidence_path: return False,'SEMANTIC_EVIDENCE_REQUIRED'
    e=jload(evidence_path)
    if e.get('result')!='PASS': return False,'SEMANTIC_RESULT'
    if e.get('target_root_sha256')!=candidate['root_sha256']: return False,'SEMANTIC_ROOT_MISMATCH'
    return True,None

def cmd_seal(a):
    t=Path(a.target).resolve(); g,err=require_grant(a,t,'SEAL')
    if err:return err
    sd=Path(a.state_dir).resolve() if a.state_dir else state_dir(t); sd.mkdir(parents=True,exist_ok=True)
    old=jload(sd/'STATE.json') if (sd/'STATE.json').exists() else {}; gen=int(old.get('generation',0))+1
    m=manifest(t,gen); ok,code=semantic_ok(a.profile,a.semantic_evidence,m)
    if not ok:return stop(code)
    lkg=sd/'LKG'/f'generation_{gen:06d}'/t.name; copy(t,lkg)
    jdump(sd/'ACTIVE_MANIFEST.json',m)
    jdump(sd/'STATE.json',{'schema':STATE_SCHEMA,'state':'SEALED','generation':gen,'target':str(t),'root_sha256':m['root_sha256'],'last_delegate':g['delegate']})
    ok,_=verify_m(t,m); audit_use(sd,g,t,'SEAL',old.get('root_sha256'),m.get('root_sha256')); print('PASS_SEAL' if ok else 'STOP[SEAL_VERIFY]'); return 0 if ok else 2

def cmd_verify(a):
    t=Path(a.target).resolve(); sd=Path(a.state_dir).resolve() if a.state_dir else state_dir(t); mp=sd/'ACTIVE_MANIFEST.json'
    if not mp.exists(): return stop('NO_ACTIVE_MANIFEST')
    m=jload(mp); ok,cur=verify_m(t,m)
    print(('PASS_VERIFY ' if ok else 'STOP[VERIFY] ')+json.dumps({'expected_root':m.get('root_sha256'),'actual_root':cur.get('root_sha256')},sort_keys=True))
    return 0 if ok else 2

def cmd_stage(a):
    t=Path(a.target).resolve(); g,err=require_grant(a,t,'STAGE')
    if err:return err
    sd=Path(a.state_dir).resolve() if a.state_dir else state_dir(t)
    if not (sd/'STATE.json').exists(): return stop('NOT_SEALED')
    active=jload(sd/'ACTIVE_MANIFEST.json'); ok,_=verify_m(t,active)
    if not ok:return stop('CURRENT_NOT_SEALED')
    gen=int(jload(sd/'STATE.json')['generation'])+1; dst=sd/'STAGING'/f'generation_{gen:06d}'/t.name; copy(t,dst)
    audit_use(sd,g,t,'STAGE',active.get('root_sha256'),active.get('root_sha256')); print(str(dst)); return 0

def cmd_commit(a):
    t=Path(a.target).resolve(); g,err=require_grant(a,t,'COMMIT')
    if err:return err
    st=Path(a.staging).resolve(); sd=Path(a.state_dir).resolve() if a.state_dir else state_dir(t)
    if not (sd/'ACTIVE_MANIFEST.json').exists(): return stop('NOT_SEALED')
    active=jload(sd/'ACTIVE_MANIFEST.json'); ok,_=verify_m(t,active)
    if not ok:return stop('CURRENT_NOT_SEALED')
    gen=int(jload(sd/'STATE.json')['generation'])+1; cand=manifest(st,gen)
    sok,scode=semantic_ok(a.profile,a.semantic_evidence,cand)
    if not sok:return stop(scode)
    prevgen=int(jload(sd/'STATE.json')['generation']); prev=sd/'LKG'/f'generation_{prevgen:06d}'/t.name
    if not prev.exists(): copy(t,prev)
    tmp=t.parent/(t.name+'.vault_publish_tmp'); backup=t.parent/(t.name+'.vault_old_tmp')
    for x in (tmp,backup):
        if x.exists(): shutil.rmtree(x) if x.is_dir() else x.unlink()
    copy(st,tmp); os.replace(t,backup)
    try: os.replace(tmp,t)
    except Exception:
        os.replace(backup,t); raise
    shutil.rmtree(backup) if backup.is_dir() else backup.unlink()
    jdump(sd/'ACTIVE_MANIFEST.json',cand)
    newlkg=sd/'LKG'/f'generation_{gen:06d}'/t.name; copy(t,newlkg)
    jdump(sd/'STATE.json',{'schema':STATE_SCHEMA,'state':'SEALED','generation':gen,'target':str(t),'root_sha256':cand['root_sha256'],'last_delegate':g['delegate']})
    ok,_=verify_m(t,cand); audit_use(sd,g,t,'COMMIT',active.get('root_sha256'),cand.get('root_sha256')); print('PASS_COMMIT' if ok else 'STOP[COMMIT_VERIFY]'); return 0 if ok else 2

def cmd_restore(a):
    t=Path(a.target).resolve(); g,err=require_grant(a,t,'RESTORE')
    if err:return err
    sd=Path(a.state_dir).resolve() if a.state_dir else state_dir(t); gen=int(a.generation); src=sd/'LKG'/f'generation_{gen:06d}'/t.name
    if not src.exists(): return stop('LKG_NOT_FOUND')
    copy(src,t); m=manifest(t,gen); jdump(sd/'ACTIVE_MANIFEST.json',m); jdump(sd/'STATE.json',{'schema':STATE_SCHEMA,'state':'SEALED','generation':gen,'target':str(t),'root_sha256':m['root_sha256'],'last_delegate':g['delegate']})
    ok,_=verify_m(t,m); audit_use(sd,g,t,'RESTORE',None,m.get('root_sha256')); print('PASS_RESTORE' if ok else 'STOP[RESTORE_VERIFY]'); return 0 if ok else 2

def safe(r):
    p=Path(r); return not p.is_absolute() and '..' not in p.parts

def cmd_pack(a):
    t=Path(a.target).resolve(); g,err=require_grant(a,t,'PACK')
    if err:return err
    sd=Path(a.state_dir).resolve() if a.state_dir else state_dir(t); active=jload(sd/'ACTIVE_MANIFEST.json'); ok,_=verify_m(t,active)
    if not ok:return stop('TARGET_NOT_SEALED')
    out=Path(a.output).resolve(); out.parent.mkdir(parents=True,exist_ok=True)
    entries=[(f'DATA/{r}',p) for r,p in files(t)]+[('VAULT_EVIDENCE/ACTIVE_MANIFEST.json',sd/'ACTIVE_MANIFEST.json'),('VAULT_EVIDENCE/STATE.json',sd/'STATE.json')]
    with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for arc,p in entries:
            if not safe(arc): return stop('UNSAFE_ARCHIVE_PATH')
            i=zipfile.ZipInfo(arc,FIXED_DT); i.compress_type=zipfile.ZIP_DEFLATED; i.external_attr=0o644<<16; z.writestr(i,p.read_bytes())
    audit_use(sd,g,t,'PACK',active.get('root_sha256'),active.get('root_sha256')); print('PASS_PACK '+str(out)); return 0

def add_common(p,grant=True):
    p.add_argument('target'); p.add_argument('--state-dir');
    if grant:
        p.add_argument('--grant')
        p.add_argument('--authority-profile')
        p.add_argument('--actor')
        p.add_argument('--purpose')

def main():
    ap=argparse.ArgumentParser(); sp=ap.add_subparsers(dest='cmd',required=True)
    p=sp.add_parser('seal'); add_common(p); p.add_argument('--profile'); p.add_argument('--semantic-evidence')
    p=sp.add_parser('verify'); add_common(p,False)
    p=sp.add_parser('stage'); add_common(p)
    p=sp.add_parser('commit'); p.add_argument('target'); p.add_argument('staging'); p.add_argument('--state-dir'); p.add_argument('--grant'); p.add_argument('--authority-profile'); p.add_argument('--actor'); p.add_argument('--purpose'); p.add_argument('--profile'); p.add_argument('--semantic-evidence')
    p=sp.add_parser('restore'); p.add_argument('target'); p.add_argument('generation',type=int); p.add_argument('--state-dir'); p.add_argument('--grant'); p.add_argument('--authority-profile'); p.add_argument('--actor'); p.add_argument('--purpose')
    p=sp.add_parser('pack'); p.add_argument('target'); p.add_argument('output'); p.add_argument('--state-dir'); p.add_argument('--grant'); p.add_argument('--authority-profile'); p.add_argument('--actor'); p.add_argument('--purpose')
    a=ap.parse_args(); return {'seal':cmd_seal,'verify':cmd_verify,'stage':cmd_stage,'commit':cmd_commit,'restore':cmd_restore,'pack':cmd_pack}[a.cmd](a)
if __name__=='__main__': raise SystemExit(main())
