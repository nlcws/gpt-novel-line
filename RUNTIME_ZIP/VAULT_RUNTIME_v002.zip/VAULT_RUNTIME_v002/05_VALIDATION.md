# VAULT / 05_VALIDATION

Structural validation:
- exact file closure;
- byte size;
- SHA-256 per file;
- deterministic root manifest hash;
- safe portable archive paths.

Semantic validation:
VAULT does not invent domain semantics.
A profile may choose:
- STRUCTURAL_ONLY; or
- EXTERNAL_REQUIRED.

For EXTERNAL_REQUIRED, the provided semantic evidence must state PASS and bind to the exact candidate root SHA-256. This permits Project-specific validators without coupling VAULT to a domain.
