# VAULT / 07_PORTABILITY

VAULT logic is model/service neutral.
It relies on ordinary files, JSON, SHA-256, and whole-target copies.

A host/service adapter may be needed where the environment cannot directly read/write files, run validation code, or preserve exact bytes.
Such an adapter changes transport/execution only; it must not weaken the authority, candidate, closure, semantic-evidence, or LKG rules.
