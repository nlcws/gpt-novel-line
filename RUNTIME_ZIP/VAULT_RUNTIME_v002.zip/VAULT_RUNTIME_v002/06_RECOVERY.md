# VAULT / 06_RECOVERY

Each admitted generation stores an exact whole-target Last Known Good copy.
RESTORE requires explicit delegated authority.
Recovery restores one admitted generation as a whole target, rewrites active evidence, then verifies the restored bytes.

Do not reconstruct a broken state by mixing files from different generations.
