# VAULT / 03_STATE_MACHINE

Target states:
- UNSEALED: no admitted active manifest.
- SEALED: target exactly matches admitted active manifest.
- CANDIDATE: staged whole-target candidate exists but is not active.
- FAILED: attempted validation/transaction failed; failed candidate never becomes active.

A candidate becomes active only after the required structural and semantic gates pass and the whole target is published.
Partial update is never an admitted state.
