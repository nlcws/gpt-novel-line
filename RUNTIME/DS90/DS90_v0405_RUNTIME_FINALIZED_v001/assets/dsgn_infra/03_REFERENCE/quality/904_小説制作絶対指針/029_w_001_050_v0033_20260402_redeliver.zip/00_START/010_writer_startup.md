# 010_writer_startup.md

この束は、寺箱 001〜050 の執筆専用入口です。

## この束の役割
- 執筆さんは、この束だけを見る
- 022 / 023 へ探検しない
- 前提不足があれば停止する
- 不足は、この束側を補修して解決する

## 初期帯の方向
- 001〜050 は、寺箱の家の顔を馴染ませる帯
- 世界の奥や外周の異常を開く帯ではない
- 怪異は、家の生活の奥に背景のように置く
- 置いたら説明せず、生活へ戻る

## 05_LINK の扱い
- 05_LINK は将来運用用の準備ファイルです
- 001〜050 の執筆では必須参照ではありません
- 必要時のみ補助的に見てよく、本文起動の前提にはしません

## 起動用
- 新チャットの起動文が必要な時は 00_START/009_writer_launch_prompt.md を使う
- このファイルは束内の基本方針確認用


## 台詞確認
- 台詞が多い回は 03_CHARACTER/112_core_cast_dialogue_phrasebook.md を確認する
- 短い会話は、注釈を足す前に地の文で支える
- 呼称に迷った時は 03_CHARACTER/113_core_cast_addressing_map.md を確認する
- 出力前は 02_RULE/071_dialogue_two_step_review.md で二段階確認する
- 話レイヤーは 02_RULE/072_story_layer_variable_template.md を基準に各話で差し替える
- 全話の基本設計は 04_MASTER/147_story_layer_design_001_050.md を参照する

## 話レイヤー
- 各話で 02_RULE/072_story_layer_variable_template.md を差し替える
- 正式採用メモは 04_MASTER/148_story_layer_adoption_note_20260402.md
- 地の文は見えている仕事だけをする


- 話レイヤー確認: `04_MASTER/149_story_layer_map_001_050.md`
