# 010_writer_startup.md

## 起動順
1. `00_START/011_reading_order.md`
2. `01_STATE/030_current_state_001_050.md`
3. `01_STATE/035_open_level_001_050.md`
4. `01_STATE/040_active_names_windows.md`
5. `02_RULE/050_header_rule.md`
6. `02_RULE/055_not_yet_open_001_050.md`
7. `02_RULE/056_direction_001_050.md`
8. `02_RULE/057_tone_priority_001_050.md`
9. `02_RULE/058_prohibited_expressions_001_050.md`
10. `03_CHARACTER/100_core_cast_overview.md` 以降
11. 当該 `10_WRITER_READY/2xx_writer_ready_xxx.md`
