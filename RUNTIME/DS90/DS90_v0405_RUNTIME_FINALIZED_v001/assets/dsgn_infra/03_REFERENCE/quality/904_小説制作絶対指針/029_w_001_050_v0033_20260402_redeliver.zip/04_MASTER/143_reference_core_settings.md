# 143_reference_core_settings.md

参照用の固定資料。
