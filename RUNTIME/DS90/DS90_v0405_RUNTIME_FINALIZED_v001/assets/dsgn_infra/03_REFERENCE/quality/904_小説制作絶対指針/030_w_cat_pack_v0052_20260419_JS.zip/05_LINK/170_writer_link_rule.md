# 170_writer_link_rule.md

05_LINK は補助棚。
001〜050 では必須参照にしない。
