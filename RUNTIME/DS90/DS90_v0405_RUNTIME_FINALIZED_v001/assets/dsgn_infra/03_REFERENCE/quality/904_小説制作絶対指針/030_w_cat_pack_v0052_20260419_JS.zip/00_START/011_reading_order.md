# 011_reading_order.md

- まず状態と開通を読む
- 次にルールを読む
- 次にキャラと店の固定を読む
- 最後に当該話の writer_ready を読む
- 迷ったら `10_WRITER_READY` を優先し、それでも不足なら停止
- 語彙揺れが出たら `04_MASTER/148_reference_term_lexicon_light.md` を読む
