# 000_bundle_readme.md

この束は、寺箱 001〜050 用の direct-writer bundle です。

## 役割
- 執筆さんが本文を書くための正面入口
- 差分運用をしないフル版束
- 001〜050 を「家の顔を馴染ませる帯」として安定運用するための資料束

## 原則
- 執筆さんはこの束だけを見る
- 022 / 023 へ探検しない
- 不足があれば本文は停止し、束側を補修する

## 起動
- 新チャット起動時は 00_START/009_writer_launch_prompt.md をそのまま使ってよい
- 仕様はこの束内で完結する

- 台詞が多い回や連続会話の確認は 03_CHARACTER/112_core_cast_dialogue_phrasebook.md
- 短い会話は、注釈を増やす前に地の文で支える
- 呼称に迷った時は 03_CHARACTER/113_core_cast_addressing_map.md
- 出力前の二段階確認は 02_RULE/071_dialogue_two_step_review.md
- 話レイヤーは 02_RULE/072_story_layer_variable_template.md を基準に各話で差し替える
- 全話の基本設計は 04_MASTER/147_story_layer_design_001_050.md を参照する

## 話レイヤー正式採用
- 話レイヤーは 02_RULE/072_story_layer_variable_template.md を各話で差し替えて使う
- 正式採用メモは 04_MASTER/148_story_layer_adoption_note_20260402.md


- 話レイヤー確認: `04_MASTER/149_story_layer_map_001_050.md`
