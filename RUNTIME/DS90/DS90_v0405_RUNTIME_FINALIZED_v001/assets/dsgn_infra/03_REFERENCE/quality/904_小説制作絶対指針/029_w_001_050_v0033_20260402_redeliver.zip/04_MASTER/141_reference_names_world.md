# 141_reference_names_world.md

参照用の固定資料。
