# 180_future_link_plan_051_plus.md

51 以降で本格リンク化するための準備メモ。
