# 011_reading_order.md

## 起動時に使う
- 新チャット起動時は 00_START/009_writer_launch_prompt.md をそのまま使ってよい


## 初回だけ読む順
1. 010_writer_startup.md
2. 02_RULE/056_direction_001_050.md
3. 02_RULE/055_not_yet_open_001_050.md
4. 01_STATE/030_current_state_001_050.md
5. 03_CHARACTER/100_core_cast_overview.md
6. 03_CHARACTER/110_core_cast_voice.md
7. 03_CHARACTER/111_core_cast_speech_drift_prevention.md
8. 台詞が多い回は 03_CHARACTER/112_core_cast_dialogue_phrasebook.md
9. 短い会話は、注釈を増やす前に地の文で支える
10. 呼称に迷った時は 03_CHARACTER/113_core_cast_addressing_map.md
11. 04_MASTER/148_story_layer_adoption_note_20260402.md
12. 出力前は 02_RULE/071_dialogue_two_step_review.md

## 毎話で見る順
1. 対象話の 10_WRITER_READY
2. 01_STATE/020_card_index_001_050.md
3. 01_STATE/030_current_state_001_050.md
4. 必要なら 01_STATE/040_active_names_windows.md
5. 台詞や連続会話に迷いが出たら 03_CHARACTER/111_core_cast_speech_drift_prevention.md
6. 連続会話や言い回しに迷ったら 03_CHARACTER/112_core_cast_dialogue_phrasebook.md
7. 短い会話は、注釈を増やす前に地の文で支える
8. 呼称に迷った時は 03_CHARACTER/113_core_cast_addressing_map.md
9. 出力前は 02_RULE/071_dialogue_two_step_review.md
10. 必要なら 03_CHARACTER/190_episode_operation_table_001_050.md
11. 04_MASTER/148_story_layer_adoption_note_20260402.md
12. 薄い回の補修時だけ 04_MASTER/146_reference_repair_memo_001_050.md
- 話レイヤーは 02_RULE/072_story_layer_variable_template.md を基準に各話で差し替える
- 全話の基本設計は 04_MASTER/147_story_layer_design_001_050.md を参照する


- 話レイヤー確認: `04_MASTER/149_story_layer_map_001_050.md`
