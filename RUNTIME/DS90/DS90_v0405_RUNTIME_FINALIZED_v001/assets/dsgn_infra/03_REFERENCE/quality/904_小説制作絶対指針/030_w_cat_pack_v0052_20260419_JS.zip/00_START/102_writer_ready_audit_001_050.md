# writer_ready 監査メモ

- このZIPには `10_WRITER_READY/201_writer_ready_001.md` から `10_WRITER_READY/250_writer_ready_050.md` までの 50話ぶんが入っています。
- 追加で `10_WRITER_READY/200_writer_ready_template.md` が1本入っています。
- 合計: writer_ready系 51ファイル
