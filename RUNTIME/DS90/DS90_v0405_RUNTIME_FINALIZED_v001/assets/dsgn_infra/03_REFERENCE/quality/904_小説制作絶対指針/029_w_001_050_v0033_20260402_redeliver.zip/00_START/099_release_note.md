# 099_release_note.md

v0019
- 実装用ファイル構成を束へ反映
- 00_START / 01_STATE / 02_RULE / 03_CHARACTER を先行実装
- 10_WRITER_READY は空ひな型を配置
- 03_CHARACTER/190_episode_operation_table_001_050.md を実データで反映
- 10_WRITER_READY/201〜250 を実データで反映
- 危険回 023 / 030 / 031 / 036 / 041 / 043 / 046 / 049 / 050 を個別補強

v0024
- 04_MASTER/146_reference_repair_memo_001_050.md を追加
- 優先補修対象 005 / 006 / 007 / 011 / 014 / 017 / 020 / 021 / 024 / 029 / 032 / 037 / 038 / 042 / 048 に個別補強メモを反映
- 共通3点補修（冒頭 / 中盤 / 締め）と停止線を束へ反映

v0025
- 03_CHARACTER/111_core_cast_speech_drift_prevention.md を追加
- 台詞の発話主迷子と口調ズレ防止の確認メモを束へ反映
- 00_START/011_reading_order.md に声確認導線を追加



v0026
- 00_START/009_writer_launch_prompt.md を追加
- 029 単独で執筆チャットを起動できる固定文を束へ反映
- 00_START/000_bundle_readme.md / 010_writer_startup.md / 011_reading_order.md に起動導線を追加


## v0027 / 2026-04-02
- 03_CHARACTER/112_core_cast_dialogue_phrasebook.md を追加
- 台詞確認導線を 00_START に追加


## v0028 / 2026-04-02
- 03_CHARACTER/112_core_cast_dialogue_phrasebook.md の湊項目を更新
- 湊は家族間では一人称なし、友達場面など必要時のみ出す運用へ固定

## v0029 / 2026-04-02
- 03_CHARACTER/113_core_cast_addressing_map.md を追加
- 02_RULE/071_dialogue_two_step_review.md を追加
- 呼称確認と二段階自己検閲の導線を 00_START に追加
- 03_CHARACTER/112_core_cast_dialogue_phrasebook.md に呼称確認の参照を追記

## v0030 / 2026-04-02
- 02_RULE/071_dialogue_two_step_review.md を更新
- 短い会話は、注釈を足す前に地の文で支える運用を追加
- 「説明係」など運用語を作中台詞へ入れない固定を追加
- 03_CHARACTER/112_core_cast_dialogue_phrasebook.md を更新
- 00_START の起動・読む順に地の文支え運用を追記
- v0031: 話レイヤー可変テンプレを正式採用。主／副／地の文語彙は各話可変。001〜050の基本設計メモを追加。

## v0032 / 2026-04-02
- 04_MASTER/148_story_layer_adoption_note_20260402.md を追加
- 話レイヤー方式の正式採用点を可変運用前提で明文化
- 02_RULE/072_story_layer_variable_template.md を更新
- 04_MASTER/147_story_layer_design_001_050.md を更新
- 地の文は見えていることを言い直しすぎない運用を追記


## v0033 / 2026-04-02
- 001〜050 の各 `10_WRITER_READY` に話レイヤーを差し込み
- `04_MASTER/149_story_layer_map_001_050.md` を追加
- 起動 / 読む順に話レイヤー確認導線を追加
