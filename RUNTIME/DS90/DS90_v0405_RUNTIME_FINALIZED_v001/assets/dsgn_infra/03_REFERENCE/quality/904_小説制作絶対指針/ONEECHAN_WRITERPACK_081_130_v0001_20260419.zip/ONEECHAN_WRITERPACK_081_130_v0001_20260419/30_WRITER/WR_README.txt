執筆さん用メモ（081〜130 専用）

1) 00_README/PROJECT_INSTRUCTIONS.txt を最初に読む
2) 10_SYSTEM/このGPTは小説本文の執筆専用です。.txt を読む
3) 30_WRITER/000_INDEX_081_130.txt で対象話数を引く
4) 30_WRITER/CARDS/CARD_XXX.txt を読む
5) 必要なら 20_DESIGN の台帳を補助参照する
6) 迷ったら：小善意暴走 → 順番で鎮火 → 生活へ着地（飯！湯！）

この束は本文正本ではありません。
本文正本は Dropbox の /0300_SIS_PROJECT/_INDEX.txt から辿る既存本文です。
この束は 081〜130 の執筆投入用カード束です。
