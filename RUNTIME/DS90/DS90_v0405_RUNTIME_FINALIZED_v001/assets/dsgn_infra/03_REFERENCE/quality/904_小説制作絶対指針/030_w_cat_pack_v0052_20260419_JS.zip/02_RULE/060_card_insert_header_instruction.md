# 060_card_insert_header_instruction.md

各話個別指示文では、本文ヘッダルールを参照で示す。
ヘッダ実文そのものを毎回長く再掲しない。
