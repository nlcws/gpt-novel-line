# 145_reference_world_memo_light.md

参照用の固定資料。
