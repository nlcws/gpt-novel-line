# EDITOR_sample_shelf_for_design_v1

この資料は、編集さんが別アカウントで設計さんへ「厚みの基準」を提示するためのサンプル棚である。

ユーザーに同じ量の資料を作らせるための資料ではない。
編集さんが作品条件として直接使う資料でもない。
設計さんが薄いカードを正規V2カードと誤認しないように、実物見本・構成見本・比較見本を取り出すための索引である。

## 0. 最重要

この棚は、作品条件源ではない。

ALLOW:
- 設計さんへ「この密度まで見る」と提示する
- プロジェクト構築の見本を出す
- 疑似GPTs設計さんの初回投入形を示す
- 実働パックの構成密度を示す
- V2カードと旧カードの差を説明する
- 野良戻しや比較検証を、設計さんへ戻す材料として説明する

DENY:
- サンプル作品の人物名・地名・設定をユーザー作品へ混ぜる
- サンプル本文をユーザー作品の本文条件にする
- 旧カードを現行基準として扱う
- 比較ログ全文を正規入力源にする
- 設計さんの揉み直しを省略する
- この棚を執筆担当へ直接渡す

---

## 1. 取り出し判断

ユーザーが「プロジェクト化したい」と言った時:
- `GPTs_外出しマウントセット_整理版.zip`
- `初期同梱おまけ.zip`
- `疑似GPTs設計さん_初回投げ込みパック_v1_2.zip`
を、プロジェクト構築と初回投入の見本として使う。

ユーザーが「設計さんに何を渡せばいい？」と言った時:
- 作品側引継ぎテンプレ
- 初回起動文
- 入力源別受け渡し設計
- V2前整理
を提示する。

ユーザーが「V2カードってどのくらい厚い？」と言った時:
- `比較検証.zip` のV2カードサンプル
- `030_w_cat_pack_v0058_20260503_JS.zip` の writer_ready / card / state 群
を、厚み基準として示す。

ユーザーが「なんでV2が必要？」と言った時:
- `比較検証.zip` の旧カード/V2/本文比較を使い、
  V2で本文量、身体導線、場所運用、反応差、戻し先が増えることを説明する。

ユーザーが「設計さんが薄くなる」と言った時:
- この棚から、実働パックの構成、V2カードの項目、比較検証の差分を示して、
  「正規V2はこの密度まで見る」と提示する。

---

## 2. サンプル棚の入れ物

### 2-1. GPTs_外出しマウントセット_整理版.zip

用途:
プロジェクト起動、長期運用、入口説明、定型文の見本。

設計さんへ示す時の意味:
「プロジェクトには、最初に読む資料、起動ガイド、プロジェクト指示、長期運用マニュアル、定型文が分かれている」

含まれる主なファイル:
- `GPTs_外出しマウントセット_整理版/00_まず読む.md` (1,015 bytes)
- `GPTs_外出しマウントセット_整理版/README.md` (423 bytes)
- `GPTs_外出しマウントセット_整理版/00_まず読む/00_README_マウントセット.md` (1,328 bytes)
- `GPTs_外出しマウントセット_整理版/00_まず読む/01_マウント索引.md` (952 bytes)
- `GPTs_外出しマウントセット_整理版/01_起動/10_プロジェクト起動ガイド_初心者向け.md` (2,391 bytes)
- `GPTs_外出しマウントセット_整理版/01_起動/11_プロジェクト指示スターター版.md` (1,286 bytes)
- `GPTs_外出しマウントセット_整理版/02_運用/20_長期運用マニュアル.md` (1,861 bytes)
- `GPTs_外出しマウントセット_整理版/03_定型文/30_定型文テンプレ集.md` (2,447 bytes)

取り出す時の言い方:
「これはあなたの作品にそのまま使う資料ではありません。プロジェクト構築で、入口・起動・運用・定型文をどう分けるかの見本です。」

---

### 2-2. 初期同梱おまけ.zip

用途:
初期同梱資料、共通運用雛形、話レイヤー、見本束、便利補助の例。

設計さんへ示す時の意味:
「プロジェクトに最初から入れる資料は、本文だけではなく、共通運用、話レイヤー、見本、必要補助を分けて置く」

主なファイル:
- `初期同梱おまけ/あったら便利/インデックス一括更新/run-index.cmd` (266 bytes)
- `初期同梱おまけ/あったら便利/インデックス一括更新/update-index-all.ps1` (1,288 bytes)
- `初期同梱おまけ/あったら便利/ガチャ素材パック一式_v0009.zip` (98,751 bytes)
- `初期同梱おまけ/新規プロジェクト流し込み用 共通運用雛型 V1/新規プロジェクト流し込み用 共通運用雛型 V1.pdf` (600,828 bytes)
- `初期同梱おまけ/新規プロジェクト流し込み用 共通運用雛型 V1/新規プロジェクト流し込み用_共通運用雛型_v_1.md` (32,565 bytes)
- `初期同梱おまけ/見本束/0001_風の通る日.txt` (17,163 bytes)
- `初期同梱おまけ/見本束/030_見本.zip` (331,445 bytes)
- `初期同梱おまけ/見本束/081 白い息の苦情.txt` (13,638 bytes)
- `初期同梱おまけ/見本束/082 戻しすぎた夏.txt` (14,779 bytes)
- `初期同梱おまけ/話レイヤー再定義版_マルチ運用.md` (13,324 bytes)
- `初期同梱おまけ/運用txt整理版_設計参考レポート.md` (8,650 bytes)

取り出す時の言い方:
「初期同梱は、作品条件そのものではなく、設計さんが迷わないための土台です。あなたの作品では、ここに作品側引継ぎと作品資料を足します。」

---

### 2-3. 疑似GPTs設計さん_初回投げ込みパック_v1_2.zip

用途:
プロジェクト内に、作品専属の設計担当として動く入口を作る見本。

設計さんへ示す時の意味:
「作品側引継ぎ、共通起動文、初回起動文、不足停止、入力源別受け渡し、口頭条件昇格を一式で持たせる」

主なファイル:
- `00_最初に読む/00_README_最初に読む.md` (2,919 bytes)
- `00_最初に読む/01_投入手順.md` (840 bytes)
- `00_最初に読む/02_同梱物一覧.md` (889 bytes)
- `01_固定資料/作品側引継ぎテンプレート_v1_1.md` (9,082 bytes)
- `01_固定資料/作品側引継ぎテンプレート_v1_1.txt` (9,082 bytes)
- `01_固定資料/疑似GPTs設計さん_v1_2_確定版.md` (22,036 bytes)
- `01_固定資料/疑似GPTs設計さん共通起動文.zip` (47,529,156 bytes)
- `02_作品ごとに追加するもの/00_ここに作品側引継ぎを埋めて別途追加.md` (821 bytes)
- `02_作品ごとに追加するもの/01_ここに作品マウントZIPを別途追加.md` (783 bytes)
- `03_起動文/01_初回起動文.md` (1,079 bytes)
- `03_起動文/02_不足停止時の見方.md` (631 bytes)
- `04_運用メモ/01_入力源別受け渡し設計.md` (1,202 bytes)
- `04_運用メモ/02_ガチャ素材運用README.md` (1,172 bytes)
- `04_運用メモ/03_口頭条件の昇格ルール.md` (808 bytes)
- `05_任意補助/cat_card_template_sample_v2.zip` (79,687 bytes)
- `05_任意補助/ガチャ素材パック一式_v0009.zip` (98,751 bytes)

取り出す時の言い方:
「これは設計さんを起動するための見本です。そのまま投入するのではなく、作品側引継ぎを対象作品用に埋めてから使います。」

---

### 2-4. 030_w_cat_pack_v0058_20260503_JS.zip

用途:
実働パックの密度見本。
完成済み、または実働可能に近いパックがどのくらい資料を持つかを見るためのもの。

設計さんへ示す時の意味:
「正規の実働パックは、本文カードだけではなく、開始資料、状態、ルール、キャラ、用語、リンク、writer_ready、接続資料を持つ」

代表構成:
- `00_START/` 起動、読み順、停止条件、更新方針、リリースノート
- `01_STATE/` 現在状態、カード索引、継続要素
- `02_RULE/` ヘッダ、禁止、方向、トーン、話レイヤー変数
- `03_CHARACTER/` 主要人物、猫性、口調、反応、関係、回転テンプレ
- `04_MASTER/` 世界、関係、設定、トーン、用語
- `10_WRITER_READY/` 各話ready、本文化直前カード

主なファイル抜粋:
- `00_START/000_bundle_readme.md` (1,127 bytes)
- `00_START/009_writer_launch_prompt.md` (266 bytes)
- `00_START/010_writer_startup.md` (507 bytes)
- `00_START/011_reading_order.md` (337 bytes)
- `00_START/012_stop_condition.md` (323 bytes)
- `00_START/013_bundle_update_policy.md` (310 bytes)
- `00_START/014_test_scope_001_010.md` (425 bytes)
- `00_START/098_story_layer_note_v0006.md` (684 bytes)
- `00_START/099_release_note.md` (9,180 bytes)
- `00_START/100_writer_ready_audit_20260412.md` (646 bytes)
- `00_START/101_writer_ready_manifest_001_050.md` (1,798 bytes)
- `00_START/102_writer_ready_audit_001_050.md` (3,157 bytes)
- `00_START/103_current_status_20260419.md` (1,642 bytes)
- `00_START/103_writer_ready_fulltext_repair_20260425.md` (1,727 bytes)
- `00_START/104_writer_ready_injection_standard_20260425.md` (1,133 bytes)
- `00_START/105_writer_ready_format_unification_20260426.md` (1,199 bytes)
- `01_STATE/020_card_index_001_050.md` (1,542 bytes)
- `01_STATE/030_current_state_001_050.md` (524 bytes)
- `01_STATE/035_open_level_001_050.md` (994 bytes)
- `01_STATE/040_active_names_windows.md` (335 bytes)
- `01_STATE/045_continuing_elements_001_050.md` (463 bytes)
- `02_RULE/050_header_rule.md` (255 bytes)
- `02_RULE/055_not_yet_open_001_050.md` (349 bytes)
- `02_RULE/056_direction_001_050.md` (298 bytes)
- `02_RULE/057_tone_priority_001_050.md` (322 bytes)
- `02_RULE/058_prohibited_expressions_001_050.md` (359 bytes)
- `02_RULE/060_card_insert_header_instruction.md` (178 bytes)
- `02_RULE/070_writer_bundle_template_note.md` (224 bytes)
- `02_RULE/071_dialogue_two_step_review.md` (1,360 bytes)
- `02_RULE/072_story_layer_variable_template.md` (707 bytes)
- `03_CHARACTER/100_core_cast_overview.md` (1,394 bytes)
- `03_CHARACTER/109_core_cast_gender_anchor.md` (532 bytes)
- `03_CHARACTER/110_core_cast_voice.md` (849 bytes)
- `03_CHARACTER/111_core_cast_speech_drift_prevention.md` (1,018 bytes)
- `03_CHARACTER/112_core_cast_dialogue_phrasebook.md` (683 bytes)
- `03_CHARACTER/113_core_cast_addressing_map.md` (816 bytes)
- `03_CHARACTER/114_core_cast_cat_body_and_leakage.md` (23,686 bytes)
- `03_CHARACTER/115_real_cat_distance_map.md` (2,481 bytes)
- `03_CHARACTER/116_real_cat_calling_map.md` (1,976 bytes)
- `03_CHARACTER/117_real_cat_origin_map.md` (1,694 bytes)
- `03_CHARACTER/118_real_cat_speech_map.md` (1,606 bytes)
- `03_CHARACTER/119_real_cat_pov_control.md` (790 bytes)
- `03_CHARACTER/120_core_cast_reaction.md` (2,154 bytes)
- `03_CHARACTER/120_town_cats_map.md` (3,440 bytes)
- `03_CHARACTER/121_core_cast_catness_prose_guide.md` (24,853 bytes)
- `03_CHARACTER/122_town_catmatou_map_light.md` (1,149 bytes)
- `03_CHARACTER/122_town_cats_map_light.md` (1,276 bytes)
- `03_CHARACTER/123_town_catmatou_map_light.md` (1,138 bytes)
- `03_CHARACTER/124_cat_density_examples.md` (463 bytes)
- `03_CHARACTER/130_core_cast_forbidden.md` (1,356 bytes)
- `03_CHARACTER/140_core_cast_depth_and_unopened.md` (363 bytes)
- `03_CHARACTER/150_outer_windows_overview.md` (780 bytes)
- `03_CHARACTER/160_relationship_interaction_table.md` (3,722 bytes)
- `03_CHARACTER/170_rotation_templates.md` (1,219 bytes)
- `03_CHARACTER/180_episode_band_targets_5block.md` (2,308 bytes)
- `03_CHARACTER/190_episode_operation_table_001_050.md` (12,258 bytes)
- `03_CHARACTER/191_episode_win_table_001_010.md` (2,535 bytes)
- `03_CHARACTER/192_episode_priority_map_001_050.md` (1,788 bytes)
- `04_MASTER/141_reference_names_world.md` (279 bytes)
- `04_MASTER/142_reference_relation_map_temple.md` (258 bytes)
- `04_MASTER/143_reference_core_settings.md` (27,010 bytes)
- `04_MASTER/144_reference_tone_and_constraints.md` (1,372 bytes)
- `04_MASTER/145_reference_world_memo_light.md` (1,342 bytes)
- `04_MASTER/146_reference_repair_memo_001_050.md` (547 bytes)
- `04_MASTER/147_story_layer_design_001_050.md` (5,725 bytes)
- `04_MASTER/148_reference_term_lexicon_light.md` (2,658 bytes)
- `05_LINK/150_link_plan_dropbox.md` (132 bytes)
- `05_LINK/160_episode_text_links_001_050.md` (100 bytes)
- `05_LINK/170_writer_link_rule.md` (95 bytes)
- `05_LINK/180_future_link_plan_051_plus.md` (98 bytes)
- `10_WRITER_READY/200_writer_ready_template.md` (1,090 bytes)
- `10_WRITER_READY/201_writer_ready_001.md` (15,505 bytes)
- `10_WRITER_READY/202_writer_ready_002.md` (29,637 bytes)
- `10_WRITER_READY/203_writer_ready_003.md` (28,220 bytes)
- `10_WRITER_READY/204_writer_ready_004.md` (28,023 bytes)
- `10_WRITER_READY/205_writer_ready_005.md` (27,632 bytes)
- `10_WRITER_READY/206_writer_ready_006.md` (26,149 bytes)
- `10_WRITER_READY/207_writer_ready_007.md` (27,224 bytes)
- `10_WRITER_READY/208_writer_ready_008.md` (25,983 bytes)
- `10_WRITER_READY/209_writer_ready_009.md` (25,731 bytes)

取り出す時の言い方:
「これは猫作品の設定を使うためではありません。実働パックの厚みと分割の見本です。あなたの作品でも、最低限どの層を分けるかを設計さんへ示すために使います。」

---

### 2-5. 比較検証.zip

用途:
旧カード、V2カード、野良ちゃん、マルチ、NOM、パック専用の比較見本。
V2化によって何が改善したかを説明するためのもの。

設計さんへ示す時の意味:
「V2は項目を増やすだけではなく、本文担当が拾いやすい走行路へ再配置するためのもの」

含まれるファイル:
- `比較検証/# 【話カード v2：走行レーン型】猫１話.txt` (13,334 bytes)
- `比較検証/# 【話カード v2：走行レーン型】猫４９話.txt` (14,836 bytes)
- `比較検証/【話カードV2運用方針】.txt` (1,641 bytes)
- `比較検証/パックNOMフルマウント猫１話V2.txt` (34,168 bytes)
- `比較検証/パックNOMフルマウント猫１話現行執筆パック.txt` (23,449 bytes)
- `比較検証/パックNOMフルマウント猫４９話V2.txt` (33,830 bytes)
- `比較検証/パックNOMフルマウント猫４９話現行執筆パック.txt` (28,849 bytes)
- `比較検証/パック猫１話V2.txt` (29,266 bytes)
- `比較検証/パック猫１話現行執筆パック.txt` (33,163 bytes)
- `比較検証/パック猫４９話V2.txt` (30,343 bytes)
- `比較検証/パック猫４９話現行執筆パック.txt` (32,455 bytes)
- `比較検証/マルチNOM猫１話V2.txt` (29,637 bytes)
- `比較検証/マルチNOM猫４９話V2.txt` (35,350 bytes)
- `比較検証/マルチ猫１話V2.txt` (26,339 bytes)
- `比較検証/マルチ猫４９話V2.txt` (44,651 bytes)
- `比較検証/現行執筆パック話カード猫１話.md` (17,529 bytes)
- `比較検証/現行執筆パック話カード猫４９話.md` (17,451 bytes)
- `比較検証/話カード v2：走行レーン型 サンプル.txt` (13,899 bytes)
- `比較検証/話カード v2：走行レーン型.txt` (4,582 bytes)
- `比較検証/野良ちゃん猫１話V2.txt` (18,510 bytes)
- `比較検証/野良ちゃん猫１話現行執筆パック.txt` (16,493 bytes)
- `比較検証/野良ちゃん猫４９話V2.txt` (30,321 bytes)
- `比較検証/野良ちゃん猫４９話現行執筆パック.txt` (21,650 bytes)

取り出す時の言い方:
「これは正規本文条件ではなく、比較検証です。設計さんへ、旧カードとV2でどの要素が痩せるか、何を増やすべきかを見せるために使います。」

---

## 3. 設計さんへ提示する厚み基準

### 3-1. 薄いカード

薄いカードの例:
- 核だけある
- 必須順がない
- 禁止線がない
- 場所と小物が飾り
- 反応差がない
- 戻し先がない
- 熱量層がない
- 作品別専用項目がない

この状態で執筆へ渡すと、本文担当は説明で埋めるか、無難な5k前後へ畳む危険が高い。

### 3-2. 正規V2カード

正規V2カードには最低限以下が必要。

- 今回の核
- 今回の走行レーン
- 固定層
- 熱量層
- 必須順
- 接続条件
- 禁止線
- 痩せやすい箇所
- 今回前に出す人
- 今回使う場所
- 戻し先
- 作品別 / 話別専用項目
- 本文担当が迷う箇所
- 停止条件

### 3-3. 実働パックの厚み

実働パックは、単話カードだけでは足りない。

必要な層:
- 起動資料
- 読み順
- 停止条件
- 全体前提
- 現在状態
- 継続要素
- 禁止事項
- トーン
- 話レイヤー変数
- キャラ口調
- 関係表
- 世界観軽量資料
- 用語
- writer_ready
- 当該話カード
- 接続資料
- 本文後LOG反映候補

編集さんは、ユーザーにこれを全部作らせる必要はない。
ただし、設計さんへ「こういう層がある」と提示できる必要がある。

---

## 4. 設計さんへ見せる提示文テンプレ

### 4-1. 厚み基準提示

設計さんへ：

この作品では、V2カードを正規カードとして扱います。
V2カードは要約ではなく、本文へ変換可能な施工図です。

参考棚として、以下を見てください。

- 疑似GPTs設計さん初回投げ込みパック
- 実働パック見本
- 比較検証.zip 内のV2カード
- 旧カードとV2本文比較

目的は、サンプル設定を流用することではありません。
カード密度、固定層、熱量層、作品別専用項目、戻し先の厚みを確認することです。

この作品用に置き換えて、第1話から第3話のV2カードを作ってください。
薄いカードは執筆へ回さないでください。

### 4-2. プロジェクト構築提示

設計さんへ：

プロジェクト資料は、以下の層に分けてください。

1. 最初に読む資料
2. 作品側引継ぎ
3. 固定条件
4. 禁止線
5. 主要人物
6. 関係
7. 場所
8. 用語
9. 話レイヤー / 文体条件
10. V2カード
11. 接続資料
12. 本文後LOG反映候補

初回は全部を完成させる必要はありません。
ただし、本文担当へ渡す話だけは、固定層と熱量層を落とさないでください。

### 4-3. 比較検証提示

設計さんへ：

比較検証では、旧カードよりV2カードの方が、以下を本文へ出しやすくなりました。

- 身体導線
- 場所運用
- 小物の意味変化
- 人物の反応差
- 閉じの戻し先
- 本文量を押し上げる熱源
- 禁止線
- 痩せやすい箇所

V2化は増築ではなく再配置です。
既存カードに項目を足すだけではなく、本文担当が拾いやすい構造へ並べ替えてください。

---

## 5. 編集さんが取り出す時の短い合図

ユーザーがこう言ったら、編集さんは以下を取り出す。

「プロジェクト化したい」
→ 外出しマウントセット、初期同梱、疑似GPTs設計さん初回投げ込みを見本棚として使う。

「設計さんに渡すもの作って」
→ 作品側引継ぎ、初回起動文、V2前整理、設計さんへの厚み基準提示文を出す。

「カード薄くない？」
→ 比較検証と実働パック見本を使い、固定層・熱量層・作品別専用項目の不足を見る。

「このまま執筆へ渡していい？」
→ V2成立条件、入力源成立、停止条件を確認し、必要なら検証さんへ回す。

「別アカウントで回したい」
→ サンプル棚を、設計さんへ提示する厚み基準として持たせる。

---

## 6. 最終固定

このサンプル棚は、編集さんが設計さんへ提示する厚み基準である。
ユーザーに同じ厚みの資料を作らせるためではない。
編集さんが作品条件として使うためでもない。

別アカウントでは履歴も共有済み資料もない。
だから、設計さんが薄いカードを正規カードと誤認しないよう、編集さんがこの棚から基準を取り出す。

編集さんは、サンプル棚を取り出し、
対象作品用の入口メモ、
作品側引継ぎ、
初回起動文、
V2前整理、
設計さんへの依頼文へ変換して渡す。
